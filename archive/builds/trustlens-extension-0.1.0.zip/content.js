// trustlens-extension/content.js
console.log("TrustLens Content Script Running");

// Import overlay component script
const overlayScript = document.createElement('script');
overlayScript.src = chrome.runtime.getURL('overlay-component.js');
overlayScript.onload = function() {
  console.log("TrustLens Overlay Component loaded");
};
document.head.appendChild(overlayScript);

// Import futuristic font
const fontImport = document.createElement('link');
fontImport.href = 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600&display=swap';
fontImport.rel = 'stylesheet';
document.head.appendChild(fontImport);

// Enhanced CSS for futuristic visual indicators
const overlayStyles = `
  .trustlens-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    opacity: 0.4;
    transition: all 0.3s ease;
    z-index: 1000;
    backdrop-filter: blur(2px);
    border: 2px solid;
    box-shadow: 0 0 15px;
  }
  
  .trustlens-overlay.high-trust {
    border-color: #00ff9d;
    box-shadow: 0 0 15px #00ff9d80;
    background: linear-gradient(45deg, #00000080, #00302080);
  }
  
  .trustlens-overlay.medium-trust {
    border-color: #ffdd00;
    box-shadow: 0 0 15px #ffdd0080;
    background: linear-gradient(45deg, #00000080, #302a0080);
  }
  
  .trustlens-overlay.low-trust {
    border-color: #ff2d55;
    box-shadow: 0 0 15px #ff2d5580;
    background: linear-gradient(45deg, #00000080, #300a1080);
  }
  
  .trustlens-container {
    position: relative;
    display: inline-block;
  }
  
  .trustlens-container:hover .trustlens-overlay {
    opacity: 0.6;
  }
  
  .trustlens-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 5px 10px;
    border-radius: 20px;
    color: white;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    font-size: 14px;
    z-index: 1001;
    pointer-events: none;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid;
    box-shadow: 0 0 10px;
    backdrop-filter: blur(5px);
    transition: all 0.3s ease;
    text-shadow: 0 0 5px currentColor;
  }
  
  .trustlens-badge.high-trust {
    background-color: rgba(0, 40, 20, 0.7);
    border-color: #00ff9d;
    box-shadow: 0 0 10px #00ff9d80;
  }
  
  .trustlens-badge.medium-trust {
    background-color: rgba(40, 40, 0, 0.7);
    border-color: #ffdd00;
    box-shadow: 0 0 10px #ffdd0080;
  }
  
  .trustlens-badge.low-trust {
    background-color: rgba(40, 0, 10, 0.7);
    border-color: #ff2d55;
    box-shadow: 0 0 10px #ff2d5580;
    animation: pulse 2s infinite;
  }
  
  @keyframes pulse {
    0% {
      opacity: 0.8;
      transform: scale(1);
    }
    50% {
      opacity: 1;
      transform: scale(1.05);
    }
    100% {
      opacity: 0.8;
      transform: scale(1);
    }
  }
  
  .trustlens-detail-panel {
    position: absolute;
    top: 45px;
    right: 10px;
    width: 200px;
    background-color: rgba(10, 10, 20, 0.9);
    border-radius: 10px;
    padding: 10px;
    color: white;
    font-family: 'Rajdhani', sans-serif;
    z-index: 1002;
    backdrop-filter: blur(10px);
    border: 1px solid #ffffff30;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
    pointer-events: none;
  }
  
  .trustlens-badge:hover + .trustlens-detail-panel,
  .trustlens-detail-panel:hover {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
  }
  
  .trustlens-detail-panel h3 {
    margin: 0 0 10px 0;
    font-size: 16px;
    text-align: center;
    color: white;
  }
  
  .trust-meter {
    height: 6px;
    background-color: rgba(255, 255, 255, 0.2);
    border-radius: 3px;
    margin-bottom: 10px;
    overflow: hidden;
  }
  
  .meter-fill {
    height: 100%;
    transition: width 0.5s ease;
  }
  
  .high-trust .meter-fill {
    background-color: #00ff9d;
    box-shadow: 0 0 10px #00ff9d;
  }
  
  .medium-trust .meter-fill {
    background-color: #ffdd00;
    box-shadow: 0 0 10px #ffdd00;
  }
  
  .low-trust .meter-fill {
    background-color: #ff2d55;
    box-shadow: 0 0 10px #ff2d55;
  }
  
  .trust-source {
    font-size: 12px;
    text-align: center;
    opacity: 0.8;
  }
  
  .trustlens-processed {
    /* Marker class for processed images */
  }
`;

// Add styles to the document
function addStyles() {
  const styleEl = document.createElement('style');
  styleEl.textContent = overlayStyles;
  document.head.appendChild(styleEl);
}

// Function to determine trust class based on score
function getTrustClass(score) {
  if (score > 0.7) {
    return 'high-trust';
  } else if (score >= 0.4) {
    return 'medium-trust';
  } else {
    return 'low-trust';
  }
}

// Function to create and apply overlay to an image
function applyOverlay(img, trustScore, message, imageHashes) {
  // Create container if the image isn't already wrapped
  let container = img.parentElement;
  if (!container.classList.contains('trustlens-container')) {
    container = document.createElement('div');
    container.className = 'trustlens-container';
    img.parentNode.insertBefore(container, img);
    container.appendChild(img);
  }
  
  // Get trust class based on score
  const trustClass = getTrustClass(trustScore);
  
  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = `trustlens-overlay ${trustClass}`;
  
  // Create badge with score percentage
  const badge = document.createElement('div');
  badge.className = `trustlens-badge ${trustClass}`;
  badge.textContent = `${Math.round(trustScore * 100)}%`;
  
  // Create detail panel
  const detailPanel = document.createElement('div');
  detailPanel.className = `trustlens-detail-panel ${trustClass}`;
  let hashesHtml = '';
  if (imageHashes) {
    hashesHtml = `
    <div class="trust-hashes" style="font-size: 10px; margin-top: 8px; overflow: hidden; text-overflow: ellipsis;">
      <div title="${imageHashes.phash}">PHash: ${imageHashes.phash.substring(0, 8)}...</div>
      <div title="${imageHashes.sha256}">SHA256: ${imageHashes.sha256.substring(0, 8)}...</div>
    </div>`;
  }

  detailPanel.innerHTML = `
    <h3>Trust Analysis</h3>
    <div class="trust-meter">
      <div class="meter-fill" style="width: ${trustScore * 100}%"></div>
    </div>
    <div class="trust-source">
      ${message || (trustScore > 0.7 ? 'Verified content' : (trustScore >= 0.4 ? 'Uncertain content' : 'Suspicious content'))}
    </div>
    ${hashesHtml}
  `;
  
  // Add overlay, badge, and detail panel to container
  container.appendChild(overlay);
  container.appendChild(badge);
  container.appendChild(detailPanel);
  
  // Mark the image as processed
  img.classList.add('trustlens-processed');
}

// Function to process a single image
function processImage(img, index) {
  // Skip if already processed
  if (img.classList.contains('trustlens-processed') || img.classList.contains('tl-processed-new')) {
    return;
  }
  
  // Skip small images (icons, etc.)
  if (img.width < 50 || img.height < 50) {
    return;
  }
  
  console.log(`Processing image ${index + 1}:`, img.src);
  
  // Extract VCs from the page if not already done
  if (!window.extractedVCs) {
    window.extractedVCs = { metadataVCs: [], imageVCs: [] };
    if (window.trustlensVCExtractor) {
      window.extractedVCs = window.trustlensVCExtractor.extractAllVCs();
      console.log("Extracted VCs:", window.extractedVCs);
    }
  }
  
  // Find VC for this specific image if available
  let imageVC = null;
  
  // First check data-vc attribute directly
  imageVC = img.dataset.vc || img.getAttribute('data-vc');
  
  // If not found, check if we have a VC from the extractor
  if (!imageVC && window.extractedVCs.imageVCs) {
    window.extractedVCs.imageVCs.forEach(vc => {
      if (vc.src === img.src) {
        imageVC = vc.jwt;
      }
    });
  }
  
  // If no specific VC for this image, use page-level VCs
  if (!imageVC && window.extractedVCs.metadataVCs && window.extractedVCs.metadataVCs.length > 0) {
    imageVC = window.extractedVCs.metadataVCs[0];
  }
  
  // Generate a unique ID for this image
  const imgId = `img_${Date.now()}_${index}`;
  
  // Apply the new lightweight overlay in pending state
  if (window.TrustLensOverlay) {
    window.TrustLensOverlay.applyNewOverlay(img, null);
  } else {
    // Fall back to the original overlay if the new component isn't loaded yet
    console.log("TrustLens Overlay Component not loaded yet, using legacy overlay");
  }
  
  // Set a timeout to apply a default overlay if no response is received
  setTimeout(() => {
    // Check if the image has been processed already with a trust score
    if (!img.classList.contains('trustlens-processed') &&
        (!img.parentElement || !img.parentElement.querySelector('.tl-good, .tl-warn, .tl-bad'))) {
      console.log(`Timeout reached for image ${index + 1}. Applying default overlay.`);
      
      if (window.TrustLensOverlay) {
        window.TrustLensOverlay.updateOverlay(img, 0.5, "Analysis timeout - check extension configuration");
      } else {
        applyOverlay(img, 0.5, "Analysis timeout - check extension configuration", null);
      }
    }
  }, 5000); // 5 second timeout
  
  // Request analysis from background script
  chrome.runtime.sendMessage({
    cmd: "analyzeImage",
    id: imgId,
    src: img.src,
    vc: imageVC
  });
  
  return img;
}

// Function to detect images and request analysis
function detectAndAnalyzeImages() {
  const images = document.querySelectorAll("img:not(.trustlens-processed)");
  console.log("Detected images count:", images.length);
  
  // Set the detectedCount variable on the window object for testing
  window.detectedCount = images.length;
  
  // Extract VCs from the page
  window.extractedVCs = { metadataVCs: [], imageVCs: [] };
  if (window.trustlensVCExtractor) {
    window.extractedVCs = window.trustlensVCExtractor.extractAllVCs();
    console.log("Extracted VCs:", window.extractedVCs);
  }
  
  // Process each image
  images.forEach((img, index) => processImage(img, index));
  
  // Return the count for validation
  return images.length;
}

// Store image hash information for later lookup
const processedImageHashes = new Map();

// Listen for results from background script
chrome.runtime.onMessage.addListener((message) => {
  if (message.cmd === "imageResult") {
    // Find the image by ID
    const imgId = message.id;
    const imgIndex = parseInt(imgId.split('_')[2]);
    const images = document.querySelectorAll("img");
    
    if (imgIndex < images.length) {
      const img = images[imgIndex];
      console.log(`Applying overlay to image ${imgIndex + 1} with trust score:`, message.trustScore);
      
      // Store the hash information for this image if available
      if (message.imageHashes && message.imageHashes.sha256) {
        processedImageHashes.set(message.imageHashes.sha256, img);
      }
      
      // Use the new overlay component if available
      if (window.TrustLensOverlay && img.parentElement && img.parentElement.classList.contains('tl-wrapper')) {
        window.TrustLensOverlay.updateOverlay(img, message.trustScore, message.message);
      } else {
        // Fall back to the original overlay
        applyOverlay(img, message.trustScore, message.message, message.imageHashes);
      }
    }
  } else if (message.cmd === "updateImageTrust") {
    // This message comes from batch verification completion
    const { sha256, trustScore, message: trustMessage } = message;
    
    // Check if we have an image with this hash
    const img = processedImageHashes.get(sha256);
    if (img) {
      console.log(`Updating overlay for image with hash ${sha256.substring(0, 8)}... to trust score:`, trustScore);
      
      // Check if using new overlay
      if (window.TrustLensOverlay && img.parentElement && img.parentElement.classList.contains('tl-wrapper')) {
        window.TrustLensOverlay.updateOverlay(img, trustScore, trustMessage || "Updated via batch verification");
      } else {
        // Using original overlay
        const container = img.parentElement;
        if (container && container.classList.contains('trustlens-container')) {
          // Remove existing overlay elements
          const existingOverlay = container.querySelector('.trustlens-overlay');
          const existingBadge = container.querySelector('.trustlens-badge');
          const existingPanel = container.querySelector('.trustlens-detail-panel');
          
          if (existingOverlay) existingOverlay.remove();
          if (existingBadge) existingBadge.remove();
          if (existingPanel) existingPanel.remove();
          
          // Apply new overlay with updated trust score
          applyOverlay(img, trustScore, trustMessage || "Updated via batch verification", { sha256 });
        }
      }
    }
  } else if (message.cmd === "configError") {
    console.error("TrustLens configuration error:", message.message);
  }
});

// Add styles to the document
addStyles();

// Run detection immediately and log results
const detectedCount = detectAndAnalyzeImages();

// Expose the processImage function for the dynamic content handler
window.trustlensProcessImage = processImage;

// Add validation for test page (optional)
if (window.location.href.includes("test-page.html")) {
  const expectedImageCount = 4; // Number of images on the test page
  if (detectedCount === expectedImageCount) {
    console.log("✅ Image detection test passed!");
    
    // For test page, apply mock overlays with different trust scores
    const images = document.querySelectorAll("img");
    if (images.length >= 4) {
      // Apply different trust scores for testing visual indicators
      setTimeout(() => {
        applyOverlay(images[0], 0.9, "High trust score (90%)", null);
        applyOverlay(images[1], 0.6, "Medium trust score (60%)", null);
        applyOverlay(images[2], 0.3, "Low trust score (30%)", null);
        applyOverlay(images[3], 0.0, "Zero trust score (0%)", null);
        console.log("✅ Applied test overlays with different trust scores");
      }, 500);
    }
  } else {
    console.error("❌ Image detection test failed! Expected:", expectedImageCount, "Got:", detectedCount);
  }
}

// Add validation for VC test page
if (window.location.href.includes("test-vc-embedded.html")) {
  console.log("VC Test Page detected. Run testPassiveVCVerification() to test VC extraction.");
  
  // For test page, apply mock overlays with different trust scores
  const images = document.querySelectorAll("img");
  if (images.length > 0) {
    // Apply different trust scores based on data-vc attributes
    setTimeout(() => {
      images.forEach((img, index) => {
        // Default trust score
        let trustScore = 0.5;
        let message = "Default trust score (50%)";
        
        // Check if image has data-vc attribute
        if (img.dataset.vc || img.getAttribute('data-vc')) {
          // Extract trust score from VC if possible
          try {
            const vcData = img.getAttribute('data-vc');
            // For demo purposes, use simple pattern matching
            if (vcData.includes("trustScore\":0.95")) {
              trustScore = 0.95;
              message = "High trust score from VC (95%)";
            } else if (vcData.includes("trustScore\":0.85")) {
              trustScore = 0.85;
              message = "High trust score from VC (85%)";
            } else if (vcData.includes("trustScore\":0.6")) {
              trustScore = 0.6;
              message = "Medium trust score from VC (60%)";
            } else if (vcData.includes("trustScore\":0.2")) {
              trustScore = 0.2;
              message = "Low trust score from VC (20%)";
            }
          } catch (error) {
            console.error("Error parsing VC:", error);
          }
        }
        
        applyOverlay(img, trustScore, message, null);
      });
      console.log("✅ Applied test overlays based on VCs");
    }, 500);
  }
}