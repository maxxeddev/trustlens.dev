// TrustLens Popup Script

// Function to determine trust class based on score
function getTrustClass(score) {
  if (score > 0.7) {
    return 'high-trust';
  } else if (score >= 0.4) {
    return 'medium-trust';
  } else {
    return 'low-trust';
  }
}

// Function to format timestamp
function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Function to truncate URL
function truncateUrl(url, maxLength = 40) {
  if (url.length <= maxLength) return url;
  return url.substring(0, maxLength) + '...';
}

// Function to render results
function renderResults(logEntries) {
  console.log("Rendering results with", logEntries.length, "entries");
  
  const resultsBody = document.getElementById('resultsBody');
  const imageCountElement = document.getElementById('imageCount');
  const loadingElement = document.getElementById('loading');
  const noResultsElement = document.getElementById('noResults');
  
  try {
    // Update image count
    imageCountElement.textContent = logEntries.length;
    
    // Hide loading indicator
    loadingElement.style.display = 'none';
    
    // Clear previous results
    resultsBody.innerHTML = '';
    
    // Check if there are any results
    if (logEntries.length === 0) {
      console.log("No entries to render");
      noResultsElement.style.display = 'block';
      return;
    }
    
    noResultsElement.style.display = 'none';
    
    // Render each log entry as a card
    logEntries.forEach((entry, index) => {
      console.log(`Rendering entry ${index}:`, entry.src);
      
      try {
        // Get trust score from either trust or trustScore property
        const trustScore = entry.trustScore !== undefined ? entry.trustScore :
                          entry.trust !== undefined ? entry.trust : 0;
        console.log(`Entry ${index} trust score:`, trustScore);
        
        const trustClass = getTrustClass(trustScore);
        const hasVC = entry.vc ? true : false;
        const hasHashes = entry.imageHashes ? true : false;
        const hasLabels = entry.labels && entry.labels.length > 0;
        const hasSignals = entry.signals && Object.keys(entry.signals).length > 0;
    
    // Create card element
    const card = document.createElement('div');
    card.className = `cyber-card ${trustClass}`;
    card.dataset.trustScore = trustScore;
    card.dataset.hasVc = hasVC;
    card.dataset.hasHashes = hasHashes;
    
    // Create card header
    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header';
    
    const timestamp = document.createElement('div');
    timestamp.className = 'timestamp';
    timestamp.textContent = formatTimestamp(entry.timestamp);
    
    const trustBadge = document.createElement('div');
    trustBadge.className = `trust-badge ${trustClass}`;
    trustBadge.textContent = `${Math.round(trustScore * 100)}%`;
    
    cardHeader.appendChild(timestamp);
    cardHeader.appendChild(trustBadge);
    
    // Create card content
    const cardContent = document.createElement('div');
    cardContent.className = 'card-content';
    
    // Image preview
    const imagePreview = document.createElement('img');
    imagePreview.className = 'image-preview';
    imagePreview.src = entry.src;
    imagePreview.alt = 'Image preview';
    
    // Content details
    const contentDetails = document.createElement('div');
    contentDetails.className = 'content-details';
    
    const imageSrc = document.createElement('div');
    imageSrc.className = 'image-src';
    imageSrc.textContent = truncateUrl(entry.src);
    imageSrc.title = entry.src;
    
    const status = document.createElement('div');
    status.className = 'status';
    
    // Add badges
    if (hasVC) {
      const vcBadge = document.createElement('span');
      vcBadge.className = 'badge badge-vc';
      vcBadge.textContent = 'VC';
      status.appendChild(vcBadge);
    }
    
    const aiBadge = document.createElement('span');
    aiBadge.className = 'badge badge-ai';
    aiBadge.textContent = 'AI';
    status.appendChild(aiBadge);
    
    // Add status message
    const statusText = document.createElement('span');
    statusText.textContent = entry.message || getTrustMessage(trustScore);
    status.appendChild(statusText);
    
    // Add issuer info if available
    if (hasVC && entry.issuer) {
      const issuer = document.createElement('div');
      issuer.className = 'issuer';
      issuer.innerHTML = `Verified by: <strong>${entry.issuer}</strong>`;
      contentDetails.appendChild(issuer);
    }
    
    contentDetails.appendChild(imageSrc);
    contentDetails.appendChild(status);
    
    cardContent.appendChild(imagePreview);
    cardContent.appendChild(contentDetails);
    
    // Create card actions
    const cardActions = document.createElement('div');
    cardActions.className = 'card-actions';
    
    // Add upvote/downvote buttons (for demo)
    const upvoteBtn = document.createElement('button');
    upvoteBtn.className = 'cyber-button';
    upvoteBtn.innerHTML = `<span class="icon">▲</span><span class="count">${Math.floor(Math.random() * 20)}</span>`;
    upvoteBtn.title = 'Upvote this analysis';
    
    const downvoteBtn = document.createElement('button');
    downvoteBtn.className = 'cyber-button';
    downvoteBtn.innerHTML = `<span class="icon">▼</span><span class="count">${Math.floor(Math.random() * 5)}</span>`;
    downvoteBtn.title = 'Downvote this analysis';
    
    const commentBtn = document.createElement('button');
    commentBtn.className = 'cyber-button';
    commentBtn.innerHTML = `<span class="icon">💬</span><span class="count">${Math.floor(Math.random() * 10)}</span>`;
    commentBtn.title = 'View comments';
    
    // Add details button
    const detailsBtn = document.createElement('button');
    detailsBtn.className = 'details-btn';
    detailsBtn.textContent = 'Details';
    detailsBtn.dataset.index = index;
    detailsBtn.addEventListener('click', toggleDetails);
    
    cardActions.appendChild(upvoteBtn);
    cardActions.appendChild(downvoteBtn);
    cardActions.appendChild(commentBtn);
    cardActions.appendChild(detailsBtn);
    
    // Create details content (hidden by default)
    const detailsContent = document.createElement('div');
    detailsContent.className = 'details-content';
    detailsContent.id = `details-${index}`;
    
    // Add trust meter
    const trustMeterSection = document.createElement('div');
    trustMeterSection.className = 'details-section';
    
    const trustMeterTitle = document.createElement('h4');
    trustMeterTitle.textContent = 'Trust Analysis';
    
    const trustMeter = document.createElement('div');
    trustMeter.className = 'trust-meter';
    
    const meterFill = document.createElement('div');
    meterFill.className = `meter-fill ${trustClass}`;
    meterFill.style.width = `${trustScore * 100}%`;
    
    trustMeter.appendChild(meterFill);
    trustMeterSection.appendChild(trustMeterTitle);
    trustMeterSection.appendChild(trustMeter);
    
    // Add AI detection details
    const aiSection = document.createElement('div');
    aiSection.className = 'details-section';
    
    const aiTitle = document.createElement('h4');
    aiTitle.textContent = 'AI Detection Results';
    
    const aiDetails = document.createElement('div');
    aiDetails.className = 'details-items';
    
    // Add some mock AI detection results
    const aiScores = [
      { label: 'Generated Image', value: (Math.random() * 0.5 + 0.5).toFixed(2) },
      { label: 'Manipulated Photo', value: (Math.random() * 0.3 + 0.2).toFixed(2) },
      { label: 'Authentic Photo', value: (Math.random() * 0.3).toFixed(2) }
    ];
    
    aiScores.forEach(score => {
      const item = document.createElement('div');
      item.className = 'details-item';
      
      const label = document.createElement('span');
      label.className = 'details-label';
      label.textContent = score.label;
      
      const value = document.createElement('span');
      value.className = 'details-value';
      value.textContent = score.value;
      
      item.appendChild(label);
      item.appendChild(value);
      aiDetails.appendChild(item);
    });
    
    aiSection.appendChild(aiTitle);
    aiSection.appendChild(aiDetails);
    
    // Add Labels section if available
    if (hasLabels) {
      const labelsSection = document.createElement('div');
      labelsSection.className = 'details-section';
      
      const labelsTitle = document.createElement('h4');
      labelsTitle.textContent = 'Image Labels';
      
      const labelsDetails = document.createElement('div');
      labelsDetails.className = 'details-items';
      
      // Add labels
      entry.labels.forEach(label => {
        const item = document.createElement('div');
        item.className = 'details-item';
        
        const labelText = document.createElement('span');
        labelText.className = 'details-label';
        labelText.textContent = label;
        
        item.appendChild(labelText);
        labelsDetails.appendChild(item);
      });
      
      labelsSection.appendChild(labelsTitle);
      labelsSection.appendChild(labelsDetails);
      detailsContent.appendChild(labelsSection);
    }
    
    // Add Signals section if available
    if (hasSignals) {
      const signalsSection = document.createElement('div');
      signalsSection.className = 'details-section';
      
      const signalsTitle = document.createElement('h4');
      signalsTitle.textContent = 'Trust Signals';
      
      const signalsDetails = document.createElement('div');
      signalsDetails.className = 'details-items';
      
      // Add signals
      Object.entries(entry.signals).forEach(([key, value]) => {
        const item = document.createElement('div');
        item.className = 'details-item';
        
        const signalLabel = document.createElement('span');
        signalLabel.className = 'details-label';
        signalLabel.textContent = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        
        const signalValue = document.createElement('span');
        signalValue.className = 'details-value';
        
        // Format the value based on type
        if (typeof value === 'boolean') {
          signalValue.textContent = value ? '✓' : '✗';
          signalValue.className += value ? ' signal-positive' : ' signal-negative';
        } else if (value === null) {
          signalValue.textContent = 'None';
        } else if (typeof value === 'object') {
          signalValue.textContent = Object.entries(value)
            .map(([k, v]) => `${k}: ${v}`)
            .join(', ');
        } else {
          signalValue.textContent = value.toString();
        }
        
        item.appendChild(signalLabel);
        item.appendChild(signalValue);
        signalsDetails.appendChild(item);
      });
      
      signalsSection.appendChild(signalsTitle);
      signalsSection.appendChild(signalsDetails);
      detailsContent.appendChild(signalsSection);
    }
    
    // Add Image Hashes section if available
    if (hasHashes) {
      const hashesSection = document.createElement('div');
      hashesSection.className = 'details-section';
      
      const hashesTitle = document.createElement('h4');
      hashesTitle.textContent = 'Image Hashes';
      
      const hashesDetails = document.createElement('div');
      hashesDetails.className = 'details-items';
      
      // Add hash details
      const hashInfo = [
        {
          label: 'Perceptual Hash',
          value: entry.imageHashes?.phash || 'Not available',
          tooltip: 'Perceptual hash identifies visually similar images even after modifications'
        },
        {
          label: 'SHA-256',
          value: entry.imageHashes?.sha256 || 'Not available',
          tooltip: 'Cryptographic hash uniquely identifies this exact image file'
        }
      ];
      
      hashInfo.forEach(info => {
        const item = document.createElement('div');
        item.className = 'details-item hash-item';
        
        const label = document.createElement('span');
        label.className = 'details-label';
        label.textContent = info.label;
        label.title = info.tooltip;
        
        const value = document.createElement('div');
        value.className = 'details-value hash-value';
        
        // Create hash display with copy button
        const hashText = document.createElement('span');
        hashText.className = 'hash-text';
        hashText.textContent = info.value.length > 16 ?
          `${info.value.substring(0, 8)}...${info.value.substring(info.value.length - 8)}` :
          info.value;
        hashText.title = info.value;
        
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-btn';
        copyBtn.innerHTML = '📋';
        copyBtn.title = 'Copy to clipboard';
        copyBtn.dataset.hash = info.value;
        copyBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          navigator.clipboard.writeText(this.dataset.hash)
            .then(() => {
              this.innerHTML = '✓';
              setTimeout(() => { this.innerHTML = '📋'; }, 1500);
            })
            .catch(err => console.error('Failed to copy: ', err));
        });
        
        value.appendChild(hashText);
        value.appendChild(copyBtn);
        
        item.appendChild(label);
        item.appendChild(value);
        hashesDetails.appendChild(item);
      });
      
      hashesSection.appendChild(hashesTitle);
      hashesSection.appendChild(hashesDetails);
      detailsContent.appendChild(hashesSection);
    }
    
    // Add VC details if available
    if (hasVC) {
      const vcSection = document.createElement('div');
      vcSection.className = 'details-section';
      
      const vcTitle = document.createElement('h4');
      vcTitle.textContent = 'Verifiable Credential';
      
      const vcDetails = document.createElement('div');
      vcDetails.className = 'details-items';
      
      // Add VC details
      const vcInfo = [
        { label: 'Issuer', value: entry.issuer || 'did:cheqd:testnet:123456' },
        { label: 'Issued Date', value: new Date().toLocaleDateString() },
        { label: 'Credential ID', value: `vc-${Math.random().toString(36).substring(2, 10)}` }
      ];
      
      vcInfo.forEach(info => {
        const item = document.createElement('div');
        item.className = 'details-item';
        
        const label = document.createElement('span');
        label.className = 'details-label';
        label.textContent = info.label;
        
        const value = document.createElement('span');
        value.className = 'details-value';
        value.textContent = info.value;
        
        item.appendChild(label);
        item.appendChild(value);
        vcDetails.appendChild(item);
      });
      
      vcSection.appendChild(vcTitle);
      vcSection.appendChild(vcDetails);
      detailsContent.appendChild(vcSection);
    }
    
    detailsContent.appendChild(trustMeterSection);
    detailsContent.appendChild(aiSection);
    
    // Assemble the card
    card.appendChild(cardHeader);
    card.appendChild(cardContent);
    card.appendChild(cardActions);
    card.appendChild(detailsContent);
    
    // Add the card to the results
    resultsBody.appendChild(card);
    } catch (entryError) {
      console.error(`Error rendering entry ${index}:`, entryError);
      console.log(`Problematic entry:`, JSON.stringify(entry).substring(0, 200));
    }
    });
  } catch (error) {
    console.error("Error in renderResults:", error);
    loadingElement.style.display = 'none';
    noResultsElement.style.display = 'block';
    noResultsElement.textContent = 'Error rendering results: ' + error.message;
  }
}

// Function to toggle details view
function toggleDetails(event) {
  const index = event.target.dataset.index;
  const detailsContent = document.getElementById(`details-${index}`);
  
  if (detailsContent.classList.contains('active')) {
    detailsContent.classList.remove('active');
    event.target.textContent = 'Details';
  } else {
    detailsContent.classList.add('active');
    event.target.textContent = 'Hide Details';
  }
}

// Function to get trust message based on score
function getTrustMessage(score) {
  if (score > 0.7) {
    return 'High confidence in authenticity';
  } else if (score >= 0.4) {
    return 'Medium confidence in authenticity';
  } else {
    return 'Low confidence in authenticity';
  }
}

// Function to filter results
function filterResults() {
  const filterValue = document.getElementById('filterSelect').value;
  const cards = document.querySelectorAll('.cyber-card');
  let visibleCount = 0;
  
  cards.forEach(card => {
    const trustScore = parseFloat(card.dataset.trustScore);
    const hasVc = card.dataset.hasVc === 'true';
    
    let visible = false;
    
    switch (filterValue) {
      case 'high':
        visible = trustScore > 0.7;
        break;
      case 'medium':
        visible = trustScore >= 0.4 && trustScore <= 0.7;
        break;
      case 'low':
        visible = trustScore < 0.4;
        break;
      case 'vc':
        visible = hasVc;
        break;
      default:
        visible = true;
    }
    
    card.style.display = visible ? 'block' : 'none';
    if (visible) visibleCount++;
  });
  
  // Show/hide no results message
  document.getElementById('noResults').style.display = visibleCount === 0 ? 'block' : 'none';
}

// Function to refresh results
function refreshResults() {
  document.getElementById('loading').style.display = 'block';
  document.getElementById('resultsBody').innerHTML = '';
  document.getElementById('noResults').style.display = 'none';
  
  console.log("Refreshing results from chrome.storage.local...");
  console.log("Current time:", new Date().toISOString());
  
  // Check if we're in a test environment where chrome API might not be fully available
  if (!chrome || !chrome.storage || !chrome.storage.local) {
    console.log("Chrome storage API not available, loading mock data instead");
    loadMockData();
    return;
  }
  
  // Check if chrome.tabs exists (it might not in test environments)
  if (chrome.tabs && typeof chrome.tabs.query === 'function') {
    // Get the active tab
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      console.log("Active tab query completed:", tabs ? tabs.length : 0, "tabs found");
      processStorageData(tabs);
    });
  } else {
    console.log("chrome.tabs.query not available, proceeding without tab filtering");
    processStorageData(null);
  }
  
  function processStorageData(tabs) {
    try {
      // Read directly from chrome.storage.local instead of using messaging
      chrome.storage.local.get(['scanned'], function(result) {
        console.log("Retrieved data from storage:", result);
        console.log("Storage has scanned data:", !!result.scanned);
        console.log("Scanned is array:", Array.isArray(result.scanned));
        console.log("Scanned length:", result.scanned ? result.scanned.length : 0);
        
        // Debug: Log the first item in scanned if it exists
        if (result.scanned && result.scanned.length > 0) {
          console.log("First scanned item:", JSON.stringify(result.scanned[0]).substring(0, 200) + "...");
        }
        
        if (result.scanned && Array.isArray(result.scanned) && result.scanned.length > 0) {
          // Filter entries for the current tab if tabId is available
          let logEntries = result.scanned;
          console.log("Initial entries count:", logEntries.length);
          
          if (tabs && tabs.length > 0) {
            const currentTabId = tabs[0].id;
            console.log("Current tab ID:", currentTabId);
            // Optional: Filter by tab ID if your data structure includes tabId
            // logEntries = logEntries.filter(entry => entry.tabId === currentTabId);
          }
          
          // Filter out invalid entries
          const validEntries = logEntries.filter(entry => entry && typeof entry === 'object' && entry.src);
          console.log("Valid entries after filtering:", validEntries.length);
          console.log("Filtered out:", logEntries.length - validEntries.length, "invalid entries");
          
          // Debug: Log any invalid entries
          if (validEntries.length < logEntries.length) {
            const invalidEntries = logEntries.filter(entry => !(entry && typeof entry === 'object' && entry.src));
            console.log("Invalid entries:", invalidEntries);
          }
          
          logEntries = validEntries;
          
          if (logEntries.length === 0) {
            console.log("No valid entries after filtering");
            document.getElementById('loading').style.display = 'none';
            document.getElementById('noResults').style.display = 'block';
            return;
          }
          
          // Ensure each entry has required properties
          logEntries = logEntries.map(entry => {
            // Make a copy to avoid modifying the original data in storage
            const processedEntry = {...entry};
            
            // Debug: Log the entry being processed
            console.log("Processing entry:", processedEntry.src);
            
            // Ensure timestamp exists
            if (!processedEntry.timestamp) {
              console.log("Adding missing timestamp");
              processedEntry.timestamp = Date.now();
            }
            
            // Ensure trust/trustScore exists
            if (processedEntry.trust === undefined && processedEntry.trustScore === undefined) {
              console.log("Adding missing trust score");
              processedEntry.trustScore = 0.5; // Default to medium trust if not specified
            } else {
              // Use trust if trustScore is not available
              if (processedEntry.trust !== undefined && processedEntry.trustScore === undefined) {
                processedEntry.trustScore = processedEntry.trust;
                console.log("Using trust value for trustScore:", processedEntry.trustScore);
              }
            }
            
            // Map processedVcs to vc property if needed
            if (!processedEntry.vc && processedEntry.processedVcs && processedEntry.processedVcs.length > 0) {
              console.log("Setting vc flag from processedVcs");
              processedEntry.vc = true;
              
              // If there's issuer information in processedVcs, use it
              const verifiedVc = processedEntry.processedVcs.find(vc => vc.verified && vc.issuerTrusted);
              if (verifiedVc) {
                console.log("Found verified VC with issuer:", verifiedVc.issuer);
                processedEntry.issuer = verifiedVc.issuer;
              }
            }
            
            return processedEntry;
          });
          
          console.log("Processed entries:", logEntries.length);
          console.log("First processed entry:", logEntries[0]);
          
          // Call renderResults with the processed entries
          renderResults(logEntries);
          filterResults();
        } else {
          console.log("No data found in storage or data is invalid");
          
          // Check if we should retry
          if (!window.refreshAttempts) {
            window.refreshAttempts = 1;
            console.log("First attempt failed, retrying in 1 second...");
            setTimeout(refreshResults, 1000);
          } else if (window.refreshAttempts < 3) {
            window.refreshAttempts++;
            console.log(`Attempt ${window.refreshAttempts} failed, retrying in 1 second...`);
            setTimeout(refreshResults, 1000);
          } else {
            console.log("All retry attempts failed");
            document.getElementById('loading').style.display = 'none';
            document.getElementById('noResults').style.display = 'block';
            
            // For debugging: Try loading mock data if all retries fail
            console.log("Loading mock data for debugging...");
            loadMockData();
          }
        }
      });
    } catch (error) {
      console.error("Error in refreshResults:", error);
      document.getElementById('loading').style.display = 'none';
      document.getElementById('noResults').style.display = 'block';
      document.getElementById('noResults').textContent = 'Error loading results: ' + error.message;
    }
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
  console.log("DOM content loaded, initializing popup...");
  
  // Initialize filter
  document.getElementById('filterSelect').addEventListener('change', filterResults);
  
  // Initialize refresh button
  document.getElementById('refreshBtn').addEventListener('click', function() {
    console.log("Refresh button clicked");
    // Reset refresh attempts counter
    window.refreshAttempts = 0;
    refreshResults();
  });
  
  // Add debug button for testing
  const debugBtn = document.createElement('button');
  debugBtn.textContent = "Load Test Data";
  debugBtn.className = "refresh-btn";
  debugBtn.style.marginLeft = "10px";
  debugBtn.addEventListener('click', function() {
    console.log("Debug button clicked, loading mock data");
    loadMockData();
  });
  document.querySelector('.controls').appendChild(debugBtn);
  
  // Initial load
  console.log("Performing initial load...");
  refreshResults();
  
  // Add some animation to the header
  const header = document.querySelector('.cyber-header h1');
  header.innerHTML = header.textContent.split('').map(char => 
    `<span style="animation: glow 1.5s ${Math.random()}s infinite alternate;">${char}</span>`
  ).join('');
  
  // Add animation style
  const style = document.createElement('style');
  style.textContent = `
    @keyframes glow {
      0% {
        text-shadow: 0 0 5px rgba(0, 255, 157, 0.5);
      }
      100% {
        text-shadow: 0 0 15px rgba(0, 255, 157, 0.8), 0 0 20px rgba(0, 255, 157, 0.5);
      }
    }
    
    .hash-item {
      margin-bottom: 8px;
    }
    
    .hash-value {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-family: monospace;
      background: rgba(0, 0, 0, 0.2);
      padding: 2px 5px;
      border-radius: 3px;
      max-width: 100%;
      overflow: hidden;
    }
    
    .hash-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .copy-btn {
      background: none;
      border: none;
      color: #00ff9d;
      cursor: pointer;
      font-size: 12px;
      padding: 2px 5px;
      margin-left: 5px;
      border-radius: 3px;
      transition: all 0.2s ease;
    }
    
    .copy-btn:hover {
      background: rgba(0, 255, 157, 0.2);
    }
    
    .signal-positive {
      color: #00ff9d;
      font-weight: bold;
    }
    
    .signal-negative {
      color: #ff5a5a;
      font-weight: bold;
    }
  `;
  document.head.appendChild(style);
});

// Mock data for testing
function loadMockData() {
  const mockEntries = [
    {
      src: "https://via.placeholder.com/300?text=High+Trust+Image",
      trustScore: 0.95,
      message: "High trust score from VC (95%)",
      timestamp: Date.now() - 60000,
      vc: true,
      issuer: "did:cheqd:testnet:abc123",
      imageHashes: {
        phash: "f8e0c0f0f0e0c0f0",
        sha256: "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"
      }
    },
    {
      src: "https://via.placeholder.com/300?text=Medium+Trust+Image",
      trustScore: 0.6,
      message: "Medium trust score from VC (60%)",
      timestamp: Date.now() - 120000,
      vc: true,
      issuer: "did:cheqd:testnet:def456"
    },
    {
      src: "https://via.placeholder.com/300?text=Low+Trust+Image",
      trustScore: 0.2,
      message: "Low trust score from VC (20%)",
      timestamp: Date.now() - 180000,
      vc: true,
      issuer: "did:cheqd:testnet:ghi789"
    },
    {
      src: "https://via.placeholder.com/300?text=AI+Detected+Image",
      trustScore: 0.1,
      message: "AI-generated image detected",
      timestamp: Date.now() - 240000,
      vc: false
    }
  ];
  
  console.log("Loading mock data...");
  
  // Check if chrome.storage is available
  if (chrome && chrome.storage && chrome.storage.local) {
    console.log("Saving mock data to storage...");
    
    // Store mock data in chrome.storage.local
    chrome.storage.local.set({ scanned: mockEntries }, function() {
      console.log("✅ Mock data saved to storage");
      
      // Verify data was saved correctly
      chrome.storage.local.get(['scanned'], function(result) {
        console.log("Verification - retrieved from storage:", result);
        if (result.scanned && result.scanned.length === mockEntries.length) {
          console.log("✅ Storage verification successful - mock data was saved correctly");
        } else {
          console.error("❌ Storage verification failed - mock data was not saved correctly");
        }
        
        // Reset refresh attempts counter
        window.refreshAttempts = 0;
        
        // Refresh the UI to load data from storage
        refreshResults();
      });
    });
  } else {
    console.log("Chrome storage not available, rendering mock data directly");
    
    // Render mock data directly
    renderResults(mockEntries);
    
    // Reset refresh attempts counter
    window.refreshAttempts = 0;
  }
}

// For testing purposes, uncomment to use mock data
// setTimeout(loadMockData, 1000);