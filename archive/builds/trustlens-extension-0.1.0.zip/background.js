/* MV3 service-worker */
import * as jose from './node_modules/jose/dist/browser/index.js'; // Adjust path if needed after install
import Ajv from './node_modules/ajv/dist/ajv.min.js'; // Adjust path if needed after install
import * as CacheManager from './cache-manager.js'; // Import the cache manager module

/* Constants removed - fetch from storage */

// Basic Cache for fetched schemas to avoid re-fetching
const schemaCache = new Map();
const ajv = new Ajv(); // Initialize AJV

// Initialize the cache manager when the service worker starts
CacheManager.initCacheManager().catch(error => {
  console.error('Failed to initialize cache manager:', error);
});

async function fetchBlob(url) {
  const r = await fetch(url);
  return await r.blob();
}
// Modified to accept token
async function hfDetect(model, blob, hfApiToken) {
  if (!hfApiToken) {
    console.error("Hugging Face API token not found in storage.");
    return Promise.reject("Missing HF API Token");
  }
  return fetch(`https://api-inference.huggingface.co/models/${model}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${hfApiToken}`,
      "Content-Type": "application/octet-stream"
    },
    body: blob
  }).then(r => r.json());
}
// Modified to accept DID
async function resolveDID(cheqdIssuerDid) {
  if (!cheqdIssuerDid || cheqdIssuerDid === "did:cheqd:testnet:PASTE_YOUR_DID") {
     console.error("Cheqd Issuer DID not found or not configured in storage.");
     return Promise.resolve(null); // Resolve with null if DID is missing/default
  }
  return fetch(`https://resolver.cheqd.net/1.0/identifiers/${cheqdIssuerDid}`)
         .then(r => (r.ok ? r.json() : null))
         .catch(() => null);
}

// Trust Registry implementation
const TRUST_REGISTRY_API = "https://api.trust-registry.example/check?did="; // Replace with actual registry when available

// In-memory cache for trust registry results to reduce API calls
const trustRegistryCache = new Map();
// Cache expiration time in milliseconds (1 hour)
const CACHE_EXPIRATION = 60 * 60 * 1000;

// List of trusted DIDs for offline/fallback validation
// In a production environment, this would be regularly updated from a secure source
const TRUSTED_DIDS = [
  "did:cheqd:testnet:zF7rhDBfUt9d1gJPjx7s1JXfUY7oVWkY",
  "did:cheqd:mainnet:zF7rhDBfUt9d1gJPjx7s1JXfUY7oVWkY",
  // Add other trusted DIDs here
];

/**
 * Checks if an issuer DID is trusted by the Trust Registry
 * Implements a multi-layered approach:
 * 1. Check in-memory cache first
 * 2. Try online registry API if available
 * 3. Fall back to local trusted DIDs list if offline
 *
 * @param {string} issuerDid - The DID of the issuer to check
 * @returns {Promise<boolean>} - Whether the issuer is trusted
 */
async function checkTrustRegistry(issuerDid) {
  if (!issuerDid) {
    console.warn("Cannot check trust registry: No issuer DID provided");
    return false;
  }
  
  console.log(`Checking trust registry for issuer: ${issuerDid}`);
  
  // 1. Check cache first
  const cachedResult = trustRegistryCache.get(issuerDid);
  if (cachedResult && (Date.now() - cachedResult.timestamp < CACHE_EXPIRATION)) {
    console.log(`Using cached trust registry result for ${issuerDid}: ${cachedResult.trusted}`);
    return cachedResult.trusted;
  }
  
  // 2. Try online registry API
  try {
    console.log(`Querying trust registry API for ${issuerDid}`);
    const response = await fetch(`${TRUST_REGISTRY_API}${encodeURIComponent(issuerDid)}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      },
      // Short timeout to quickly fall back if API is unavailable
      signal: AbortSignal.timeout(5000)
    });
    
    if (response.ok) {
      const result = await response.json();
      const isTrusted = result?.isTrusted === true;
      
      // Cache the result
      trustRegistryCache.set(issuerDid, {
        trusted: isTrusted,
        timestamp: Date.now()
      });
      
      console.log(`Trust registry API result for ${issuerDid}: ${isTrusted}`);
      return isTrusted;
    } else {
      console.warn(`Trust registry API check failed for ${issuerDid}: Status ${response.status}`);
      // Fall through to local check
    }
  } catch (error) {
    console.warn(`Error accessing trust registry API: ${error.message}`);
    // Fall through to local check
  }
  
  // 3. Fall back to local trusted DIDs list
  console.log(`Falling back to local trusted DIDs list for ${issuerDid}`);
  const isLocallyTrusted = TRUSTED_DIDS.includes(issuerDid);
  
  // Cache the local result too, but with shorter expiration
  trustRegistryCache.set(issuerDid, {
    trusted: isLocallyTrusted,
    timestamp: Date.now() - (CACHE_EXPIRATION / 2) // Expire twice as fast for local results
  });
  
  console.log(`Local trust check result for ${issuerDid}: ${isLocallyTrusted}`);
  return isLocallyTrusted;
}

/**
 * Checks if an issuer is accredited for a specific credential type
 *
 * @param {string} issuerDid - The DID of the issuer to check
 * @param {string} credentialType - The type of credential to check accreditation for
 * @returns {Promise<boolean>} - Whether the issuer is accredited for this credential type
 */
async function isAccredited(issuerDid, credentialType = "ImageTrustCredential") {
  if (!issuerDid) return false;
  
  // First check if the issuer is trusted at all
  const isTrusted = await checkTrustRegistry(issuerDid);
  if (!isTrusted) return false;
  
  // For now, we'll assume all trusted issuers are accredited for all credential types
  // In a production system, this would check specific accreditation for the credential type
  
  // TODO: Implement more granular accreditation checks when the registry API supports it
  return true;
}

// Function to request VC from a single authority
async function requestVcFromAuthority(authorityUrl, imageSrc, imageHashes) {
  try {
    // Prepare request payload with all available identifiers
    const payload = {
      imageSrc: imageSrc // Always include the source URL for reference
    };
    
    // Add image hashes if available
    if (imageHashes) {
      if (imageHashes.phash) payload.phash = imageHashes.phash;
      if (imageHashes.sha256) payload.sha256 = imageHashes.sha256;
    }
    
    console.log(`Requesting VC from ${authorityUrl} with identifiers:`,
      Object.keys(payload).filter(k => k !== 'imageSrc').join(', '));
    
    const response = await fetch(authorityUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      console.warn(`Failed to get VC from ${authorityUrl}: Status ${response.status}`);
      return null;
    }

    const result = await response.json();
    // Assuming the authority returns { jwt: "..." }
    if (result?.jwt && jose.decodeJwt(result.jwt)) { // Basic check
      console.log(`Received valid JWT from ${authorityUrl}`);
      return result.jwt;
    } else {
      console.warn(`Invalid VC response from ${authorityUrl}`);
      return null;
    }
  } catch (error) {
    console.error(`Error requesting VC from ${authorityUrl}:`, error);
    return null;
  }
}


// Function to verify VC JWT signature (includes Trust Registry check)
async function verifyVcSignature(jwt) {
  if (!jwt) return { verifiedPayload: null, isTrustedIssuer: false, error: "No JWT provided" }; // Return consistent object
  let issuerDid = null; // Keep track of issuer DID
  let payload = null; // Declare outside try block for access in catch

  try {
    // Decode header/payload first to get issuer
    const protectedHeader = jose.decodeProtectedHeader(jwt);
    const { alg, kid } = protectedHeader;
    payload = jose.decodeJwt(jwt);
    issuerDid = payload.iss; // Assign here

    if (!issuerDid) {
      console.error("VC verification failed: Issuer (iss) missing in JWT payload.");
      return { verifiedPayload: null, isTrustedIssuer: false, error: "Missing issuer" };
    }

    // Log the verification attempt
    console.log(`Verifying VC from issuer: ${issuerDid} with algorithm: ${alg}`);
    
    // Check if the JWT has expired
    if (payload.exp) {
      const expirationTime = new Date(payload.exp * 1000);
      const now = new Date();
      if (now > expirationTime) {
        console.warn(`VC verification failed: JWT has expired on ${expirationTime.toISOString()}`);
        return { verifiedPayload: payload, isTrustedIssuer: false, error: "JWT expired" };
      }
    }

    // *** Trust Registry Check ***
    const isTrustedIssuer = await checkTrustRegistry(issuerDid);
    if (!isTrustedIssuer) {
        console.warn(`VC verification failed: Issuer ${issuerDid} is not listed or trusted in the Trust Registry.`);
        // Return payload but mark issuer as untrusted
        return { verifiedPayload: payload, isTrustedIssuer: false, error: "Issuer not trusted" };
    }
    console.log(`Issuer ${issuerDid} is trusted by the Trust Registry.`);

    // --- Signature Verification ---

    // 1. Resolve the issuer's DID document
    console.log(`Resolving DID document for ${issuerDid}...`);
    const didDocument = await resolveDID(issuerDid);
    if (!didDocument?.didDocument) {
      console.error(`VC signature check failed: Could not resolve DID document for issuer ${issuerDid}`);
      return { verifiedPayload: payload, isTrustedIssuer: true, error: "DID resolution failed" };
    }
    console.log(`DID document resolved successfully for ${issuerDid}`);

    // 2. Find the verification method (public key)
    let verificationMethod;
    
    // First try to find by kid if provided
    if (kid) {
      console.log(`Looking for verification method with id: ${kid}`);
      verificationMethod = didDocument.didDocument.verificationMethod?.find(vm => vm.id === kid);
      if (verificationMethod) {
        console.log(`Found verification method by id: ${kid}`);
      }
    }
    
    // If not found by kid, try to find by type based on algorithm
    if (!verificationMethod) {
      console.log(`Verification method not found by id, searching by type...`);
      
      // Map algorithm to likely key types
      const keyTypesByAlg = {
        'EdDSA': ['Ed25519VerificationKey2020', 'Ed25519VerificationKey2018'],
        'ES256K': ['EcdsaSecp256k1VerificationKey2019', 'JsonWebKey2020'],
        'ES256': ['JsonWebKey2020', 'P-256'],
        'RS256': ['RsaVerificationKey2018', 'JsonWebKey2020']
      };
      
      const preferredTypes = keyTypesByAlg[alg] || ['JsonWebKey2020', 'Ed25519VerificationKey2020'];
      
      // Try to find a verification method with one of the preferred types
      for (const keyType of preferredTypes) {
        verificationMethod = didDocument.didDocument.verificationMethod?.find(vm => vm.type === keyType);
        if (verificationMethod) {
          console.log(`Found verification method by type: ${keyType}`);
          break;
        }
      }
      
      // If still not found, try any verification method
      if (!verificationMethod && didDocument.didDocument.verificationMethod?.length > 0) {
        verificationMethod = didDocument.didDocument.verificationMethod[0];
        console.log(`Using first available verification method: ${verificationMethod.id}`);
      }
    }

    if (!verificationMethod) {
      console.error(`VC signature check failed: No suitable verification method found in DID document for ${issuerDid}`);
      return { verifiedPayload: payload, isTrustedIssuer: true, error: "No verification method found" };
    }

    // 3. Import the public key
    console.log(`Importing public key from verification method: ${verificationMethod.id}`);
    let publicKey;
    
    try {
      if (verificationMethod.publicKeyJwk) {
        console.log(`Using publicKeyJwk format`);
        publicKey = await jose.importJWK(verificationMethod.publicKeyJwk, alg);
      } else if (verificationMethod.publicKeyMultibase) {
        console.log(`Using publicKeyMultibase format: ${verificationMethod.publicKeyMultibase.substring(0, 5)}...`);
        // Assuming base58btc (z prefix) for Ed25519 keys as per cheqd examples
        if (verificationMethod.publicKeyMultibase.startsWith('z')) {
          const pubKeyBytes = jose.base58btc.decode(verificationMethod.publicKeyMultibase.substring(1));
          // Convert to JWK format for Ed25519
          const jwk = {
            kty: 'OKP',
            crv: 'Ed25519',
            x: jose.base64url.encode(pubKeyBytes)
          };
          console.log(`Converted multibase to JWK: ${JSON.stringify(jwk)}`);
          publicKey = await jose.importJWK(jwk, alg);
        } else {
          throw new Error(`Unsupported publicKeyMultibase format: ${verificationMethod.publicKeyMultibase.substring(0, 5)}...`);
        }
      } else if (verificationMethod.publicKeyBase58) {
        console.log(`Using publicKeyBase58 format`);
        // Convert base58 to bytes
        const pubKeyBytes = jose.base58btc.decode(verificationMethod.publicKeyBase58);
        // Convert to JWK format
        const jwk = {
          kty: 'OKP',
          crv: 'Ed25519',
          x: jose.base64url.encode(pubKeyBytes)
        };
        publicKey = await jose.importJWK(jwk, alg);
      } else {
        throw new Error(`No recognized public key format found in verification method`);
      }
    } catch (keyError) {
      console.error(`Error importing public key:`, keyError);
      return { verifiedPayload: payload, isTrustedIssuer: true, error: `Key import failed: ${keyError.message}` };
    }

    // 4. Verify the JWT
    console.log(`Verifying JWT signature with algorithm: ${alg}`);
    const { payload: verifiedSignaturePayload } = await jose.jwtVerify(jwt, publicKey, {
      algorithms: [alg]
    });

    console.log("✅ VC Signature Verified Successfully for issuer:", issuerDid);

    // --- Schema Validation ---
    const schemaUrl = verifiedSignaturePayload.credentialSchema?.id;
    if (schemaUrl) {
      console.log(`Schema URL found: ${schemaUrl}. Fetching and validating...`);
      const schema = await fetchSchema(schemaUrl);
      if (schema) {
        const validate = ajv.compile(schema);
        const isValid = validate(verifiedSignaturePayload.credentialSubject);
        if (!isValid) {
          console.error("VC Schema validation failed:", validate.errors);
          return { verifiedPayload: verifiedSignaturePayload, isTrustedIssuer: true, error: `Schema validation failed: ${ajv.errorsText(validate.errors)}` };
        }
        console.log("✅ VC Schema validation successful.");
      } else {
        // Schema fetch failed - should this invalidate the VC? Optional.
        console.warn(`Could not fetch or validate schema from ${schemaUrl}. Proceeding without schema validation.`);
      }
    } else {
      console.log("No schema URL found in VC. Skipping schema validation.");
    }

    // If all checks passed
    return { verifiedPayload: verifiedSignaturePayload, isTrustedIssuer: true, error: null };

  } catch (error) {
    console.error(`VC verification failed for issuer ${issuerDid || 'unknown'}:`, error);
    // Ensure payload is decoded if possible before returning error
    if (!payload && jwt) {
      try {
        payload = jose.decodeJwt(jwt);
      } catch (decodeError) {
        console.error("Failed to decode JWT payload:", decodeError);
      }
    }
    return { verifiedPayload: payload, isTrustedIssuer: false, error: error.message };
  }
}


// Enhanced score function to handle multiple valid VCs with weighted voting
function score(deepfake, ai, didDoc, validTrustedVcs) { // Takes an array of verified payloads
  let s = 0;
  let message = "Score based on AI detection";
  const validVcCount = validTrustedVcs?.length || 0;

  if (validVcCount > 0) {
    // Aggregate scores from multiple valid VCs using weighted voting
    let totalVcScore = 0;
    let totalWeight = 0;
    let scoredVcCount = 0;
    let issuers = new Set(); // Keep track of unique trusted issuers
    let verificationMethods = new Set(); // Track different verification methods
    
    // First pass: collect metadata about the VCs
    validTrustedVcs.forEach(payload => {
      issuers.add(payload.iss);
      if (payload.credentialSubject?.verificationMethod) {
        verificationMethods.add(payload.credentialSubject.verificationMethod);
      }
    });
    
    // Second pass: calculate weighted scores
    validTrustedVcs.forEach(payload => {
      const vcScore = payload.credentialSubject?.trustScore;
      if (typeof vcScore === 'number') {
        // Calculate weight based on various factors
        let weight = 1.0; // Base weight
        
        // Factor 1: Recency of verification (if available)
        if (payload.credentialSubject?.verificationDate) {
          const verificationDate = new Date(payload.credentialSubject.verificationDate);
          const now = new Date();
          const ageInHours = (now - verificationDate) / (1000 * 60 * 60);
          // Newer verifications get higher weight (max 1.5x for very recent, min 0.5x for old)
          const recencyFactor = Math.max(0.5, Math.min(1.5, 2.0 - (ageInHours / 24)));
          weight *= recencyFactor;
        }
        
        // Factor 2: Issuer diversity bonus
        // If we have multiple issuers, give a slight bonus to ensure diversity of sources
        if (issuers.size > 1) {
          // Small bonus for each unique issuer (diminishing returns)
          weight *= (1 + (0.1 / issuers.size));
        }
        
        // Factor 3: Verification method diversity
        // If the VC specifies a verification method, give weight to diverse methods
        if (payload.credentialSubject?.verificationMethod && verificationMethods.size > 1) {
          weight *= (1 + (0.05 / verificationMethods.size));
        }
        
        // Apply the weighted score
        totalVcScore += vcScore * weight;
        totalWeight += weight;
        scoredVcCount++;
        
        console.log(`VC from ${payload.iss} with score ${vcScore} and weight ${weight.toFixed(2)}`);
      }
    });

    if (scoredVcCount > 0) {
      s = totalVcScore / totalWeight; // Weighted average
      message = `Score based on weighted average of ${scoredVcCount} verified credential(s) from ${issuers.size} trusted issuer(s).`;
      
      // Add detail about verification methods if available
      if (verificationMethods.size > 0) {
        message += ` Methods: ${Array.from(verificationMethods).join(', ')}.`;
      }
    } else {
      // Valid VCs found, but none had a numeric trustScore
      s = 0.85; // Assign high confidence based on presence of verified VCs
      message = `${validVcCount} verified credential(s) found from ${issuers.size} trusted issuer(s).`;
    }

  } else {
     // Fallback to AI scoring if no valid trusted VCs were found/processed
     // (This part handles cases where VCs were present but failed verification or issuer was untrusted)
     if (deepfake?.[0]?.label === "Real") s += 0.5 * deepfake[0].score;
     if (ai?.[0]?.label === "Real")      s += 0.3 * ai[0].score;
     if (didDoc)                         s += 0.2;
     message = s > 0 ? "Score based on AI detection" : "No reliable trust indicators found";
  }

  return { score: Math.min(1, Math.max(0, s)), message }; // Return score and message
}


chrome.runtime.onMessage.addListener(async (msg, sender) => {
  if (msg.cmd === "analyzeImage") {
    let finalTrustScore = 0;
    let finalScoreMessage = "Analysis failed or no trust indicators found.";
    let processedVcs = []; // Store results of all processed VCs (passive + active)
    let labels = []; // Store labels from the server response
    let signals = {}; // Store signals from the server response

    try {
      // Fetch config from storage first
      const config = await chrome.storage.local.get([
          'hfApiToken',
          'cheqdIssuerDid',
          'detectionAuthorities' // Add authorities list
        ]);
      const { hfApiToken, cheqdIssuerDid, detectionAuthorities } = config;

      // Check for configuration
      if (!hfApiToken) {
        console.warn("TrustLens configuration (API Token) missing in storage.");
        // Instead of sending an error and stopping, provide a default trust score
        chrome.tabs.sendMessage(sender.tab.id, {
          cmd: "imageResult",
          id: msg.id,
          trustScore: 0.5, // Default neutral trust score
          message: "Configuration incomplete. Please set API Token in options."
        });
        
        // Log this in storage for tracking
        chrome.storage.local.get({ scanned: [] }, data => {
          const logEntry = {
            src: msg.src,
            trust: 0.5,
            message: "Configuration incomplete",
            configMissing: true
          };
          data.scanned.push(logEntry);
          if (data.scanned.length > 50) {
            data.scanned = data.scanned.slice(-50);
          }
          chrome.storage.local.set({ scanned: data.scanned });
        });
        
        return;
      }

      // --- Image Hashing with Cache Check ---
      console.log("Processing image:", msg.src);
      let imageHashes = null;
      let cachedResult = null;
      
      try {
        // Fetch blob for AI/Hashing if needed
        const blob = await fetchBlob(msg.src);
        
        // Compute image hashes using the WebWorker
        console.log("Computing image hashes using WebWorker...");
        imageHashes = await CacheManager.hashImage(blob);
        console.log("Image hashes computed successfully:", imageHashes);
        
        // Check if this image is in the session cache
        if (imageHashes && imageHashes.sha256) {
          cachedResult = await CacheManager.getCachedImage(imageHashes.sha256);
          
          if (cachedResult) {
            console.log("Image found in session cache:", cachedResult);
            
            // If we have a cached trust score, we can use it directly
            if (typeof cachedResult.trustScore === 'number') {
              console.log("Using cached trust score:", cachedResult.trustScore);
              finalTrustScore = cachedResult.trustScore;
              finalScoreMessage = "Score from session cache";
              
              // Extract labels and signals if available
              if (cachedResult.labels && Array.isArray(cachedResult.labels)) {
                labels = cachedResult.labels;
                if (labels.length > 0) {
                  finalScoreMessage += `: ${labels.join(', ')}`;
                }
              }
              
              if (cachedResult.signals) {
                signals = cachedResult.signals;
              }
            }
          } else {
            // Store basic info in cache and queue for verification
            await CacheManager.cacheImage({
              sha256: imageHashes.sha256,
              phash: imageHashes.phash,
              url: msg.src
            });
            
            // Queue for batch verification
            CacheManager.queueForVerification({
              sha256: imageHashes.sha256,
              phash: imageHashes.phash,
              url: msg.src
            });
          }
        }
      } catch (error) {
        console.error("Error processing image:", error);
      }

      // --- Passive VC Check ---
      if (msg.vc) {
        console.log("Passive VC found, verifying...");
        const passiveResult = await verifyVcSignature(msg.vc);
        processedVcs.push({ source: 'passive', jwt: msg.vc, ...passiveResult });
      }

      // --- Active VC Request (Run if authorities configured) ---
      const activeVcRequests = [];
      if (Array.isArray(detectionAuthorities) && detectionAuthorities.length > 0) {
          console.log("Attempting active proof requests with image hashes...");
          detectionAuthorities.forEach(authorityUrl => {
              activeVcRequests.push(
                  requestVcFromAuthority(authorityUrl, msg.src, imageHashes)
                      .then(jwt => {
                          if (jwt) {
                              console.log(`Received active VC from ${authorityUrl}, verifying...`);
                              return verifyVcSignature(jwt).then(result => ({ source: 'active', jwt, authorityUrl, ...result }));
                          }
                          return null; // No VC received from this authority
                      })
              );
          });
      }

      // Wait for all active requests and verifications to complete
      const activeResults = (await Promise.all(activeVcRequests)).filter(r => r !== null);
      processedVcs = processedVcs.concat(activeResults);

      // Filter for valid VCs from trusted issuers
      const validTrustedVcs = processedVcs
          .filter(vc => vc.verifiedPayload && vc.isTrustedIssuer)
          .map(vc => vc.verifiedPayload); // Extract only the payloads

      if (validTrustedVcs.length > 0) {
          console.log(`Found ${validTrustedVcs.length} valid VC(s) from trusted issuer(s).`);
      } else {
          console.log("No valid VCs from trusted issuers found after passive/active checks.");
      }


      // --- AI Detection & DID Resolution (Run regardless for now) ---
      const [deep, ai, did] = await Promise.all([
        hfDetect("prithivMLmods/Deep-Fake-Detector-Model", blob, hfApiToken).catch(e => { console.error("HF Deepfake Detect Error:", e); return null; }),
        hfDetect("Smogy/SMOGY-Ai-images-detector",         blob, hfApiToken).catch(e => { console.error("HF AI Detect Error:", e); return null; }),
        resolveDID(cheqdIssuerDid).catch(e => { console.error("DID Resolve Error:", e); return null; }) // Use configured DID for now
      ]);

      // --- Calculate Final Score ---
      // Pass the array of valid, trusted VC payloads to the score function
      const scoreResult = score(deep, ai, did, validTrustedVcs);
      finalTrustScore = scoreResult.score;
      finalScoreMessage = scoreResult.message;

       // Add details about encountered VCs (even invalid ones) to the message for clarity?
       const failedVcs = processedVcs.filter(vc => !vc.verifiedPayload || !vc.isTrustedIssuer);
       if (failedVcs.length > 0 && validTrustedVcs.length === 0) {
           // If only invalid VCs were found, mention it
           const firstError = failedVcs[0].error || (failedVcs[0].isTrustedIssuer === false ? "Issuer not trusted" : "Verification failed");
           finalScoreMessage += ` (${failedVcs.length} other credential(s) found but failed verification/trust check: ${firstError})`;
       }


      // --- Logging ---
      chrome.storage.local.get({ scanned: [] }, data => {
         // Log summary and details of processed VCs
        const logEntry = {
          src: msg.src,
          trust: finalTrustScore,
          message: finalScoreMessage,
          imageHashes: imageHashes, // Include image hashes in the log entry
          labels: labels, // Include labels from the server response
          signals: signals, // Include signals from the server response
          processedVcs: processedVcs.map(vc => ({ // Log details about each VC attempt
              source: vc.source,
              issuer: vc.verifiedPayload?.iss || jose.decodeJwt(vc.jwt)?.iss || 'Unknown',
              verified: !!vc.verifiedPayload && !vc.error,
              issuerTrusted: vc.isTrustedIssuer,
              error: vc.error,
              authorityUrl: vc.authorityUrl // Log which authority it came from if active
          })),
          aiDeepfake: deep,
          aiArt: ai
        };
        data.scanned.push(logEntry);
        if (data.scanned.length > 50) {
            data.scanned = data.scanned.slice(-50);
        }
        chrome.storage.local.set({ scanned: data.scanned });
      });

      // --- Send Result ---
      chrome.tabs.sendMessage(sender.tab.id, {
        cmd: "imageResult",
        id: msg.id,
        trustScore: finalTrustScore,
        message: finalScoreMessage,
        imageHashes: imageHashes, // Include image hashes in the response
        labels: labels, // Include labels from the server response
        signals: signals // Include signals from the server response
      });

    } catch (e) {
      console.error("Unhandled error during image analysis:", e);
       // Send generic error back
       chrome.tabs.sendMessage(sender?.tab?.id, {
         cmd: "imageResult",
         id: msg.id,
         trustScore: 0,
         message: `Unexpected analysis error: ${e.message}`
       }).catch(sendError => console.error("Failed to send error message to tab:", sendError)); // Catch errors sending message
    }
  }
});

// Listen for imageVerified events from the cache manager
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.cmd === 'imageVerified') {
    console.log(`Image verified from batch: ${message.sha256.substring(0, 8)}... with score: ${message.trustScore}`);
    
    // Find tabs that might be displaying this image
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        // Send update to all tabs - the content script will check if this hash matches any images
        chrome.tabs.sendMessage(tab.id, {
          cmd: "updateImageTrust",
          sha256: message.sha256,
          trustScore: message.trustScore,
          message: "Verified via batch processing"
        }).catch(error => {
          // Ignore errors - tab might not have the content script running
        });
      });
    });
  }
});