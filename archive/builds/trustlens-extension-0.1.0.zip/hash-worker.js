// hash-worker.js - WebWorker for off-main-thread image hash computation
// This worker handles image hash computation to avoid blocking the main thread

// Import the blockhash library
importScripts('./optimized-blockhash.js');

/**
 * Maximum dimension for image downsampling to improve performance
 */
const MAX_DIMENSION = 256;

/**
 * Downsamples an image to improve performance
 * @param {ImageBitmap} img - Source image bitmap
 * @returns {OffscreenCanvas} Canvas with the downsampled image
 */
function downsampleImage(img) {
  let width = img.width;
  let height = img.height;
  
  // Downsample large images for better performance
  if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
    if (width > height) {
      height = Math.round(height * (MAX_DIMENSION / width));
      width = MAX_DIMENSION;
    } else {
      width = Math.round(width * (MAX_DIMENSION / height));
      height = MAX_DIMENSION;
    }
  }
  
  const canvas = new OffscreenCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Use better quality downsampling
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, width, height);
  
  return canvas;
}

/**
 * Computes a perceptual hash (blockhash) for an image
 * @param {ImageBitmap} img - Image bitmap
 * @returns {string} The perceptual hash string
 */
function computePerceptualHash(img) {
  const canvas = downsampleImage(img);
  
  try {
    // Use 64-bit blockhash (8 bits per row/column)
    const hash = blockhash.blockhashData(canvas, 8);
    return hash;
  } catch (error) {
    throw new Error(`Failed to compute perceptual hash: ${error}`);
  }
}

/**
 * Computes a SHA-256 hash for an array buffer
 * @param {ArrayBuffer} buffer - Image data as array buffer
 * @returns {string} The SHA-256 hash as a hex string
 */
async function computeSha256(buffer) {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  
  // Convert the hash to a hex string
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return hashHex;
}

/**
 * Main worker message handler
 */
self.onmessage = async function(e) {
  const { id, imageData, type } = e.data;
  
  try {
    const startTime = performance.now();
    
    // Create ImageBitmap from the transferred data
    let imgBitmap;
    let arrayBuffer;
    
    if (type === 'blob') {
      // If we received a blob
      const blob = e.data.blob;
      imgBitmap = await createImageBitmap(blob);
      arrayBuffer = await blob.arrayBuffer();
    } else if (type === 'buffer') {
      // If we received an array buffer directly
      arrayBuffer = e.data.buffer;
      const blob = new Blob([arrayBuffer]);
      imgBitmap = await createImageBitmap(blob);
    } else {
      throw new Error('Unsupported image data type');
    }
    
    // Compute both hashes in parallel
    const [phash, sha256] = await Promise.all([
      computePerceptualHash(imgBitmap),
      computeSha256(arrayBuffer)
    ]);
    
    const endTime = performance.now();
    
    // Send the result back to the main thread
    self.postMessage({
      id,
      result: {
        phash,
        sha256
      },
      timeMs: endTime - startTime,
      error: null
    });
    
    // Clean up
    imgBitmap.close();
    
  } catch (error) {
    // Send error back to main thread
    self.postMessage({
      id,
      result: null,
      error: error.message
    });
  }
};

// Notify that the worker is ready
self.postMessage({ status: 'ready' });