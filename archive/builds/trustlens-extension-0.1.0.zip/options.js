// Saves options to chrome.storage.local.
function saveOptions() {
  const hfApiToken = document.getElementById('hfApiToken').value;
  const cheqdIssuerDid = document.getElementById('cheqdIssuerDid').value;
  // Split authorities by newline, trim whitespace, and filter out empty lines
  const authoritiesText = document.getElementById('detectionAuthorities').value;
  const detectionAuthorities = authoritiesText
                                .split('\n')
                                .map(line => line.trim())
                                .filter(line => line.length > 0);

  chrome.storage.local.set({
    hfApiToken: hfApiToken,
    cheqdIssuerDid: cheqdIssuerDid,
    detectionAuthorities: detectionAuthorities
  }, function() {
    // Update status to let user know options were saved.
    const status = document.getElementById('status');
    status.textContent = 'Options saved.';
    setTimeout(function() {
      status.textContent = '';
    }, 1500);
  });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
  // Use default values if not set
  chrome.storage.local.get({
    hfApiToken: '',
    cheqdIssuerDid: '',
    detectionAuthorities: [] // Default to empty array
  }, function(items) {
    document.getElementById('hfApiToken').value = items.hfApiToken;
    document.getElementById('cheqdIssuerDid').value = items.cheqdIssuerDid;
    // Join the array back into a newline-separated string for the textarea
    document.getElementById('detectionAuthorities').value = items.detectionAuthorities.join('\n');
  });
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);