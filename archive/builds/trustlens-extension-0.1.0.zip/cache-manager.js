/**
 * TrustLens Cache Manager
 * 
 * This module provides:
 * 1. WebWorker management for off-main-thread image hash computation
 * 2. Session cache using chrome.storage.session
 * 3. Request batching with debounce mechanism
 * 4. Duplicate request suppression
 */

// Cache keys
const CACHE_PREFIX = 'trustlens:';
const BATCH_QUEUE_KEY = 'batch_queue';

// Batch processing configuration
const BATCH_SIZE = 8;
const BATCH_DELAY_MS = 250;

// WebWorker for image hash computation
let hashWorker = null;
let workerReady = false;
let pendingHashRequests = new Map();
let requestIdCounter = 0;

// Batch processing state
let batchTimer = null;
let batchQueue = [];
let processingBatch = false;

/**
 * Initialize the cache manager
 * @returns {Promise<void>}
 */
export async function initCacheManager() {
  console.log('Initializing TrustLens Cache Manager');
  
  // Initialize the WebWorker
  initHashWorker();
  
  // Load any existing batch queue from session storage
  try {
    const result = await chrome.storage.session.get(BATCH_QUEUE_KEY);
    if (result[BATCH_QUEUE_KEY]) {
      batchQueue = result[BATCH_QUEUE_KEY];
      console.log(`Restored ${batchQueue.length} items from previous batch queue`);
    }
  } catch (error) {
    console.error('Error loading batch queue from session storage:', error);
  }
}

/**
 * Initialize the hash worker
 */
function initHashWorker() {
  if (hashWorker) {
    hashWorker.terminate();
  }
  
  hashWorker = new Worker(chrome.runtime.getURL('hash-worker.js'));
  
  hashWorker.onmessage = (e) => {
    if (e.data.status === 'ready') {
      workerReady = true;
      console.log('Hash worker is ready');
      return;
    }
    
    const { id, result, error } = e.data;
    const pendingRequest = pendingHashRequests.get(id);
    
    if (pendingRequest) {
      pendingHashRequests.delete(id);
      
      if (error) {
        pendingRequest.reject(new Error(error));
      } else {
        pendingRequest.resolve(result);
      }
    }
  };
  
  hashWorker.onerror = (error) => {
    console.error('Hash worker error:', error);
    workerReady = false;
    
    // Reject all pending requests
    for (const [id, request] of pendingHashRequests.entries()) {
      request.reject(new Error('Hash worker error'));
    }
    pendingHashRequests.clear();
    
    // Try to reinitialize the worker after a delay
    setTimeout(() => initHashWorker(), 5000);
  };
}

/**
 * Compute image hashes using the WebWorker
 * @param {Blob|string} input - Image blob or URL
 * @returns {Promise<{phash: string, sha256: string}>}
 */
export async function hashImage(input) {
  // If input is a URL, fetch it first
  let imageBlob;
  if (typeof input === 'string') {
    const response = await fetch(input, { mode: 'cors' });
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${response.status} ${response.statusText}`);
    }
    imageBlob = await response.blob();
  } else {
    imageBlob = input;
  }
  
  // Check if the worker is ready
  if (!workerReady) {
    throw new Error('Hash worker is not ready');
  }
  
  // Create a unique ID for this request
  const requestId = ++requestIdCounter;
  
  // Create a promise that will be resolved when the worker responds
  const promise = new Promise((resolve, reject) => {
    pendingHashRequests.set(requestId, { resolve, reject });
  });
  
  // Send the image data to the worker
  hashWorker.postMessage({
    id: requestId,
    blob: imageBlob,
    type: 'blob'
  }, [imageBlob]);
  
  // Return the promise
  return promise;
}

/**
 * Check if an image hash is in the session cache
 * @param {string} sha256 - SHA-256 hash of the image
 * @returns {Promise<boolean>}
 */
export async function isInCache(sha256) {
  if (!sha256) return false;
  
  try {
    const key = `${CACHE_PREFIX}${sha256}`;
    const result = await chrome.storage.session.get(key);
    return !!result[key];
  } catch (error) {
    console.error('Error checking session cache:', error);
    return false;
  }
}

/**
 * Get cached image data by SHA-256 hash
 * @param {string} sha256 - SHA-256 hash of the image
 * @returns {Promise<{phash: string, sha256: string, url: string, trustScore: number}|null>}
 */
export async function getCachedImage(sha256) {
  if (!sha256) return null;
  
  try {
    const key = `${CACHE_PREFIX}${sha256}`;
    const result = await chrome.storage.session.get(key);
    return result[key] || null;
  } catch (error) {
    console.error('Error getting from session cache:', error);
    return null;
  }
}

/**
 * Store image data in the session cache
 * @param {Object} imageData - Image data to store
 * @param {string} imageData.sha256 - SHA-256 hash of the image
 * @param {string} imageData.phash - Perceptual hash of the image
 * @param {string} imageData.url - URL of the image
 * @param {number} [imageData.trustScore] - Trust score of the image
 * @returns {Promise<void>}
 */
export async function cacheImage(imageData) {
  if (!imageData || !imageData.sha256) return;
  
  try {
    const key = `${CACHE_PREFIX}${imageData.sha256}`;
    await chrome.storage.session.set({ [key]: imageData });
  } catch (error) {
    console.error('Error storing in session cache:', error);
  }
}

/**
 * Queue an image for server verification
 * @param {Object} imageData - Image data to verify
 * @param {string} imageData.sha256 - SHA-256 hash of the image
 * @param {string} imageData.phash - Perceptual hash of the image
 * @param {string} imageData.url - URL of the image
 * @returns {Promise<void>}
 */
export async function queueForVerification(imageData) {
  if (!imageData || !imageData.sha256) return;
  
  // Check if this image is already in the cache
  const isCached = await isInCache(imageData.sha256);
  if (isCached) {
    console.log(`Image ${imageData.sha256.substring(0, 8)}... already in cache, skipping verification`);
    return;
  }
  
  // Check if this image is already in the queue
  const isDuplicate = batchQueue.some(item => item.sha256 === imageData.sha256);
  if (isDuplicate) {
    console.log(`Image ${imageData.sha256.substring(0, 8)}... already in queue, skipping duplicate`);
    return;
  }
  
  // Add to queue
  batchQueue.push(imageData);
  console.log(`Added image ${imageData.sha256.substring(0, 8)}... to verification queue (${batchQueue.length} items)`);
  
  // Save the updated queue to session storage
  try {
    await chrome.storage.session.set({ [BATCH_QUEUE_KEY]: batchQueue });
  } catch (error) {
    console.error('Error saving batch queue to session storage:', error);
  }
  
  // Schedule batch processing
  scheduleBatchProcessing();
}

/**
 * Schedule batch processing with debounce
 */
function scheduleBatchProcessing() {
  // Clear any existing timer
  if (batchTimer) {
    clearTimeout(batchTimer);
  }
  
  // If we have enough items or are already processing, process immediately
  if (batchQueue.length >= BATCH_SIZE || processingBatch) {
    processBatch();
  } else {
    // Otherwise, set a timer
    batchTimer = setTimeout(() => processBatch(), BATCH_DELAY_MS);
  }
}

/**
 * Process a batch of image verification requests
 * @returns {Promise<void>}
 */
async function processBatch() {
  // If already processing or queue is empty, do nothing
  if (processingBatch || batchQueue.length === 0) {
    return;
  }
  
  processingBatch = true;
  
  try {
    // Get the server URL from storage
    const { verificationServer } = await chrome.storage.local.get('verificationServer');
    // Use the new v1/check endpoint
    const serverUrl = verificationServer ?
      `${verificationServer}/v1/check` :
      'http://localhost:3000/v1/check';
    
    // Take items from the queue (up to BATCH_SIZE)
    const batchItems = batchQueue.splice(0, BATCH_SIZE);
    console.log(`Processing batch of ${batchItems.length} items`);
    
    // Save the updated queue to session storage
    await chrome.storage.session.set({ [BATCH_QUEUE_KEY]: batchQueue });
    
    // Send the batch to the server using the new format
    const response = await fetch(serverUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        items: batchItems.map(item => ({
          phash: item.phash,
          sha256: item.sha256,
          src: item.url // Use src instead of url to match the new API
        }))
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with status ${response.status}`);
    }
    
    const responseData = await response.json();
    
    // Process the results - handle both JWT and direct results
    const results = responseData.results || [];
    const jwt = responseData.jwt; // Store JWT if needed for verification
    
    // Process the results
    if (Array.isArray(results)) {
      for (const result of results) {
        // Cache the result with the new format
        await cacheImage({
          sha256: result.sha256,
          phash: result.phash,
          url: result.src || '', // Map src back to url for internal consistency
          trustScore: result.score, // Map score to trustScore
          labels: result.labels || [],
          signals: result.signals || {},
          lastUpdated: result.lastUpdated,
          jwt: jwt, // Store the JWT for verification if needed
          verifiedAt: Date.now()
        });
        
        // Dispatch an event to notify that this image has been verified
        chrome.runtime.sendMessage({
          cmd: 'imageVerified',
          sha256: result.sha256,
          trustScore: result.score,
          labels: result.labels,
          signals: result.signals
        });
      }
      
      console.log(`Successfully processed and cached ${results.length} images`);
    }
  } catch (error) {
    console.error('Error processing batch:', error);
    
    // Put the items back in the queue for retry
    // batchQueue = [...batchItems, ...batchQueue];
    // await chrome.storage.session.set({ [BATCH_QUEUE_KEY]: batchQueue });
  } finally {
    processingBatch = false;
    
    // If there are more items in the queue, schedule another batch
    if (batchQueue.length > 0) {
      scheduleBatchProcessing();
    }
  }
}

/**
 * Clear the session cache
 * @returns {Promise<void>}
 */
export async function clearCache() {
  try {
    // Get all keys with our prefix
    const keys = await chrome.storage.session.get();
    const keysToRemove = Object.keys(keys).filter(key => key.startsWith(CACHE_PREFIX));
    
    if (keysToRemove.length > 0) {
      await chrome.storage.session.remove(keysToRemove);
      console.log(`Cleared ${keysToRemove.length} items from session cache`);
    }
  } catch (error) {
    console.error('Error clearing session cache:', error);
  }
}