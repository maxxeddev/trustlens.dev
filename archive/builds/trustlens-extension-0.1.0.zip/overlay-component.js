// trustlens-extension/overlay-component.js
console.log("TrustLens Overlay Component Loaded");

// Import futuristic font
const fontImport = document.createElement('link');
fontImport.href = 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600&display=swap';
fontImport.rel = 'stylesheet';
document.head.appendChild(fontImport);

// Tailwind-like utility CSS for the new overlay component
const overlayStyles = `
  /* Base wrapper for positioning */
  .tl-wrapper {
    position: relative;
    display: inline-block;
  }

  /* Pill indicator styles */
  .tl-pill {
    position: absolute;
    top: -8px;
    right: -8px;
    padding: 2px 8px;
    border-radius: 9999px;
    font-size: 10px;
    font-weight: 600;
    font-family: 'Rajdhani', sans-serif;
    color: white;
    background-color: #475569; /* slate-700 */
    opacity: 0.8;
    transition: transform 0.2s ease;
    border: none;
    cursor: pointer;
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  /* Hover effect for pill */
  .tl-wrapper:hover .tl-pill {
    transform: scale(1.08);
  }

  /* Quick action icon */
  .tl-icon {
    position: absolute;
    top: 4px;
    right: 4px;
    display: none;
    background-color: rgba(0, 0, 0, 0.6);
    border-radius: 50%;
    padding: 4px;
    cursor: pointer;
    z-index: 1001;
    transition: opacity 0.2s ease;
  }

  /* Show icon on hover */
  .tl-wrapper:hover .tl-icon {
    display: flex;
  }

  /* Trust status colors */
  .tl-pending {
    background-color: #475569; /* slate-700 */
  }

  .tl-good {
    background-color: #10b981; /* emerald-500 (neon green) */
  }

  .tl-warn {
    background-color: #f59e0b; /* amber-500 */
  }

  .tl-bad {
    background-color: #ef4444; /* red-500 */
  }

  /* Hidden utility class */
  .hidden {
    display: none;
  }

  /* Spinner animation for pending state */
  .tl-spinner {
    width: 10px;
    height: 10px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: white;
    animation: tl-spin 1s linear infinite;
  }

  @keyframes tl-spin {
    to {
      transform: rotate(360deg);
    }
  }
`;

// Add styles to the document
function addOverlayStyles() {
  const styleEl = document.createElement('style');
  styleEl.textContent = overlayStyles;
  document.head.appendChild(styleEl);
}

// Function to determine trust class based on score
function getTrustClass(score) {
  if (score === null || score === undefined) {
    return 'tl-pending';
  } else if (score > 0.7) {
    return 'tl-good';
  } else if (score >= 0.4) {
    return 'tl-warn';
  } else {
    return 'tl-bad';
  }
}

// Function to create and apply the new overlay to an image
function applyNewOverlay(img, trustScore, imageHash) {
  // Skip if already processed with new overlay
  if (img.parentElement && img.parentElement.classList.contains('tl-wrapper')) {
    return;
  }

  // Create wrapper
  const wrapper = document.createElement('div');
  wrapper.className = 'tl-wrapper';
  
  // Insert wrapper before image and move image inside
  img.parentNode.insertBefore(wrapper, img);
  wrapper.appendChild(img);
  
  // Get trust class based on score
  const trustClass = getTrustClass(trustScore);
  
  // Create pill button
  const pill = document.createElement('button');
  pill.className = `tl-pill ${trustClass}`;
  
  // Set pill content based on trust status
  if (trustClass === 'tl-pending') {
    const spinner = document.createElement('div');
    spinner.className = 'tl-spinner';
    pill.appendChild(spinner);
    pill.appendChild(document.createTextNode('Analyzing'));
  } else {
    pill.textContent = `${Math.round(trustScore * 100)}%`;
  }
  
  // Create quick-action icon
  const icon = document.createElement('div');
  icon.className = 'tl-icon hidden';
  icon.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
  </svg>`;
  
  // Add click handlers
  pill.addEventListener('click', () => {
    if (imageHash) {
      chrome.runtime.sendMessage({
        cmd: "openDrawer",
        hash: imageHash
      });
    }
  });
  
  icon.addEventListener('click', () => {
    if (imageHash) {
      chrome.runtime.sendMessage({
        cmd: "openDrawer",
        hash: imageHash
      });
    }
  });
  
  // Add elements to wrapper
  wrapper.appendChild(pill);
  wrapper.appendChild(icon);
  
  // Mark the image as processed with new overlay
  img.classList.add('tl-processed-new');
}

// Function to update an existing overlay with new trust score
function updateOverlay(img, trustScore, message) {
  // Find the wrapper
  const wrapper = img.closest('.tl-wrapper');
  if (!wrapper) return;
  
  // Find the pill
  const pill = wrapper.querySelector('.tl-pill');
  if (!pill) return;
  
  // Update trust class
  const trustClass = getTrustClass(trustScore);
  pill.className = `tl-pill ${trustClass}`;
  
  // Update content
  pill.innerHTML = '';
  pill.textContent = `${Math.round(trustScore * 100)}%`;
}

// Add styles to the document
addOverlayStyles();

// Export functions for use in content.js
window.TrustLensOverlay = {
  applyNewOverlay,
  updateOverlay,
  getTrustClass
};