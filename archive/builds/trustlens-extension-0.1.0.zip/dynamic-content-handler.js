/**
 * TrustLens Dynamic Content Handler
 * Monitors DOM changes to detect and analyze dynamically loaded images
 */

// Configuration
const config = {
  // Minimum time between processing batches (in ms)
  processingInterval: 500,
  
  // Maximum number of images to process in a single batch
  batchSize: 10,
  
  // Prioritize images in viewport
  prioritizeViewport: true,
  
  // Debug mode
  debug: false
};

// Processing queue for new images
let processingQueue = [];

// Flag to indicate if processing is currently active
let isProcessing = false;

// Last processing timestamp
let lastProcessingTime = 0;

// Initialize MutationObserver to watch for DOM changes
function initDynamicContentHandler() {
  console.log("TrustLens Dynamic Content Handler initialized");
  
  // Create an observer instance
  const observer = new MutationObserver((mutations) => {
    // Process mutations to find new images
    mutations.forEach((mutation) => {
      // Handle added nodes
      if (mutation.addedNodes && mutation.addedNodes.length > 0) {
        handleAddedNodes(mutation.addedNodes);
      }
      
      // Handle attribute changes on existing images
      if (mutation.type === 'attributes' && 
          mutation.target.tagName === 'IMG' && 
          (mutation.attributeName === 'src' || mutation.attributeName === 'srcset')) {
        handleImageAttributeChange(mutation.target);
      }
    });
    
    // Process the queue if we have new images
    if (processingQueue.length > 0) {
      processQueueIfReady();
    }
  });
  
  // Configuration for the observer
  const observerConfig = {
    childList: true,     // Watch for added/removed nodes
    attributes: true,    // Watch for attribute changes
    attributeFilter: ['src', 'srcset'], // Only care about src/srcset changes
    subtree: true,       // Watch the entire subtree
    characterData: false // Don't care about text changes
  };
  
  // Start observing
  observer.observe(document.body, observerConfig);
  
  // Also handle initial scroll event and set up scroll listener
  handleScroll();
  window.addEventListener('scroll', debounce(handleScroll, 200));
  
  // Handle resize events
  window.addEventListener('resize', debounce(handleScroll, 200));
  
  return observer;
}

// Handle added DOM nodes
function handleAddedNodes(nodes) {
  nodes.forEach((node) => {
    // If this is an image node, handle it directly
    if (node.tagName === 'IMG') {
      queueImageForProcessing(node);
    }
    
    // If this is an element node, look for images inside it
    if (node.nodeType === Node.ELEMENT_NODE) {
      const images = node.querySelectorAll('img');
      images.forEach((img) => {
        queueImageForProcessing(img);
      });
    }
  });
}

// Handle image attribute changes
function handleImageAttributeChange(img) {
  queueImageForProcessing(img);
}

// Add an image to the processing queue
function queueImageForProcessing(img) {
  // Skip small images (icons, etc.)
  if (img.width < 50 || img.height < 50) {
    return;
  }
  
  // Skip images that already have TrustLens overlays
  if (img.parentElement && img.parentElement.classList.contains('trustlens-container')) {
    return;
  }
  
  // Skip images without a valid src
  if (!img.src || img.src === '') {
    return;
  }
  
  // Add to queue if not already in it
  if (!processingQueue.some(queuedImg => queuedImg === img)) {
    processingQueue.push(img);
    
    if (config.debug) {
      console.log("TrustLens: Queued new image for processing", img.src);
    }
  }
}

// Process the queue if enough time has passed since last processing
function processQueueIfReady() {
  const now = Date.now();
  
  // Check if we should process now
  if (!isProcessing && now - lastProcessingTime >= config.processingInterval && processingQueue.length > 0) {
    isProcessing = true;
    lastProcessingTime = now;
    
    // Sort queue to prioritize images in viewport if enabled
    if (config.prioritizeViewport) {
      processingQueue.sort((a, b) => {
        const aVisible = isInViewport(a);
        const bVisible = isInViewport(b);
        
        if (aVisible && !bVisible) return -1;
        if (!aVisible && bVisible) return 1;
        return 0;
      });
    }
    
    // Take a batch from the queue
    const batch = processingQueue.splice(0, config.batchSize);
    
    if (config.debug) {
      console.log(`TrustLens: Processing batch of ${batch.length} images`);
    }
    
    // Process each image in the batch
    batch.forEach((img, index) => {
      // Skip if the image was removed from DOM
      if (!document.body.contains(img)) {
        return;
      }
      
      // Process the image using the main content script's functionality
      if (typeof window.trustlensProcessImage === 'function') {
        window.trustlensProcessImage(img, index);
      } else {
        // Fallback if the main processing function isn't available
        // This will happen if this script loads before content.js
        // We'll add the image back to the queue for later processing
        processingQueue.push(img);
      }
    });
    
    isProcessing = false;
    
    // If we still have images in the queue, schedule the next batch
    if (processingQueue.length > 0) {
      setTimeout(processQueueIfReady, config.processingInterval);
    }
  }
}

// Handle scroll events to check for newly visible images
function handleScroll() {
  // Find all images without TrustLens overlays
  const unprocessedImages = document.querySelectorAll('img:not(.trustlens-processed)');
  
  // Filter for images that are now in the viewport
  unprocessedImages.forEach((img) => {
    if (isInViewport(img)) {
      queueImageForProcessing(img);
    }
  });
  
  // Process the queue if we have new images
  if (processingQueue.length > 0) {
    processQueueIfReady();
  }
}

// Check if an element is in the viewport
function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

// Utility function to debounce events
function debounce(func, wait) {
  let timeout;
  return function() {
    const context = this;
    const args = arguments;
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      func.apply(context, args);
    }, wait);
  };
}

// Export the dynamic content handler
window.trustlensDynamicContentHandler = {
  init: initDynamicContentHandler,
  queueImage: queueImageForProcessing,
  processQueue: processQueueIfReady,
  config: config
};

// Initialize when the script loads
document.addEventListener('DOMContentLoaded', () => {
  // Wait a short time to ensure content.js has loaded
  setTimeout(() => {
    initDynamicContentHandler();
  }, 500);
});