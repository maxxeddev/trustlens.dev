/**
 * Optimized Blockhash Implementation
 *
 * This is a simplified and optimized version of the blockhash-js library
 * specifically designed for browser environments and performance.
 */

// Fast bit counting lookup table
const BIT_COUNT = new Uint8Array(256);
for (let i = 0; i < 256; i++) {
  BIT_COUNT[i] =
    (i & 1) +
    ((i >> 1) & 1) +
    ((i >> 2) & 1) +
    ((i >> 3) & 1) +
    ((i >> 4) & 1) +
    ((i >> 5) & 1) +
    ((i >> 6) & 1) +
    ((i >> 7) & 1);
}

/**
 * Calculate Hamming distance between two hex strings
 */
function hammingDistance(hash1, hash2) {
  let distance = 0;

  for (let i = 0; i < hash1.length; i++) {
    const n1 = parseInt(hash1[i], 16);
    const n2 = parseInt(hash2[i], 16);
    distance += BIT_COUNT[n1 ^ n2];
  }

  return distance;
}

/**
 * Convert bit array to hex string
 */
function bitsToHexHash(bits) {
  const hex = [];
  for (let i = 0; i < bits.length; i += 4) {
    const nibble = bits.slice(i, i + 4);
    hex.push(parseInt(nibble.join(''), 2).toString(16));
  }
  return hex.join('');
}

/**
 * Compute median of values
 */
function median(data) {
  const values = data.slice(0);
  values.sort((a, b) => a - b);

  const mid = Math.floor(values.length / 2);
  return values.length % 2 === 0 ? (values[mid - 1] + values[mid]) / 2 : values[mid];
}

/**
 * Optimized perceptual hash implementation
 *
 * @param {HTMLCanvasElement|OffscreenCanvas} canvas - Canvas with image data
 * @param {number} bits - Number of bits (e.g., 8 for 64-bit hash)
 * @returns {string} Hex string hash
 */
function computeHash(canvas, bits) {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imgData.data;

  // Use Uint32Array for faster block summing
  const blockWidth = Math.floor(canvas.width / bits);
  const blockHeight = Math.floor(canvas.height / bits);

  // Pre-allocate result array
  const result = new Uint32Array(bits * bits);

  // Fast block summing with optimized loops
  for (let y = 0; y < bits; y++) {
    const yOffset = y * bits;
    const yBlock = y * blockHeight;

    for (let x = 0; x < bits; x++) {
      let sum = 0;
      const xBlock = x * blockWidth;

      // Sum pixel values in block
      for (let by = 0; by < blockHeight; by++) {
        const rowOffset = ((yBlock + by) * canvas.width + xBlock) * 4;

        for (let bx = 0; bx < blockWidth; bx++) {
          const idx = rowOffset + bx * 4;
          // Fast grayscale calculation (average of RGB)
          sum += (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
        }
      }

      result[yOffset + x] = sum;
    }
  }

  // Calculate medians for each quadrant
  const quadrantSize = (bits * bits) / 4;
  const medians = [
    median(Array.from(result.subarray(0, quadrantSize))),
    median(Array.from(result.subarray(quadrantSize, quadrantSize * 2))),
    median(Array.from(result.subarray(quadrantSize * 2, quadrantSize * 3))),
    median(Array.from(result.subarray(quadrantSize * 3, quadrantSize * 4))),
  ];

  // Convert to binary based on median comparison
  const bits_array = new Uint8Array(bits * bits);
  for (let i = 0; i < bits * bits; i++) {
    const quadrant = Math.floor(i / quadrantSize);
    bits_array[i] = result[i] < medians[quadrant] ? 0 : 1;
  }

  // Convert to hex
  return bitsToHexHash(Array.from(bits_array));
}

// Export functions
const blockhash = {
  hammingDistance,
  blockhashData: computeHash,
};

// Make it available in both browser and worker contexts
// This works in both browser and web worker contexts
self.blockhash = blockhash;
