/**
 * TrustLens Cache Manager
 *
 * This module provides:
 * 1. WebWorker management for off-main-thread image hash computation
 * 2. Session cache using chrome.storage.session
 * 3. Request batching with debounce mechanism
 * 4. Duplicate request suppression
 */

// Cache keys
const CACHE_PREFIX = 'trustlens:';
const BATCH_QUEUE_KEY = 'batch_queue';

// Batch processing configuration
const BATCH_SIZE = 8;
const BATCH_DELAY_MS = 250;

// WebWorker for image hash computation
let hashWorker = null;
let workerReady = false;
let pendingHashRequests = new Map();
let requestIdCounter = 0;

// Batch processing state
let batchTimer = null;
let batchQueue = [];
let processingBatch = false;

/**
 * Initialize the cache manager
 * @returns {Promise<void>}
 */
export async function initCacheManager() {
  console.log('Initializing TrustLens Cache Manager');

  // Initialize the WebWorker
  initHashWorker();

  // Load any existing batch queue from session storage
  try {
    const result = await chrome.storage.session.get(BATCH_QUEUE_KEY);
    if (result[BATCH_QUEUE_KEY]) {
      batchQueue = result[BATCH_QUEUE_KEY];
      console.log(`Restored ${batchQueue.length} items from previous batch queue`);
    }
  } catch (error) {
    console.error('Error loading batch queue from session storage:', error);
  }
}

/**
 * Initialize the hash worker
 */
function initHashWorker() {
  if (hashWorker) {
    hashWorker.terminate();
  }

  // Check if chrome.runtime is available before using it
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
    try {
      hashWorker = new Worker(chrome.runtime.getURL('hash-worker.js'));

      hashWorker.onmessage = e => {
        if (e.data.status === 'ready') {
          workerReady = true;
          console.log('Hash worker is ready');
          return;
        }

        const { id, result, error } = e.data;
        const pendingRequest = pendingHashRequests.get(id);

        if (pendingRequest) {
          pendingHashRequests.delete(id);

          if (error) {
            pendingRequest.reject(new Error(error));
          } else {
            pendingRequest.resolve(result);
          }
        }
      };

      hashWorker.onerror = error => {
        console.error('Hash worker error:', error);
        workerReady = false;

        // Reject all pending requests
        for (const [id, request] of pendingHashRequests.entries()) {
          request.reject(new Error('Hash worker error'));
        }
        pendingHashRequests.clear();

        // Try to reinitialize the worker after a delay
        setTimeout(() => initHashWorker(), 5000);
      };
    } catch (error) {
      console.error('Failed to initialize hash worker:', error);
      workerReady = false;
    }
  } else {
    console.warn(
      'TrustLens: Unable to initialize hash worker - chrome.runtime is not available in this context'
    );
    workerReady = false;
  }
}

/**
 * Compute image hashes using the WebWorker
 * @param {Blob|string} input - Image blob or URL
 * @returns {Promise<{phash: string, sha256: string}>}
 */
export async function hashImage(input) {
  if (!workerReady) {
    throw new Error('Hash worker is not ready');
  }

  const id = requestIdCounter++;

  return new Promise((resolve, reject) => {
    pendingHashRequests.set(id, { resolve, reject });

    // Send the image to the worker
    hashWorker.postMessage({
      id,
      action: 'hash',
      input,
    });
  });
}
