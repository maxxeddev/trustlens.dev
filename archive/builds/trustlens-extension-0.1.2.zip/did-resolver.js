// trustlens-extension/did-resolver.js

/**
 * TrustLens DID Resolver
 *
 * This module provides functionality to resolve content-hash based DIDs
 * through the TrustLens server, which acts as a caching DID resolver proxy.
 */

/**
 * Resolves a content-hash based DID through the TrustLens server.
 *
 * @param {string} did - The content-hash based DID to resolve (e.g., "did:cheqd:mainnet:hash123")
 * @returns {Promise<Object>} - A promise that resolves to the DID resolution result
 *   The result will have the following structure:
 *   - For FOUND status:
 *     {
 *       status: "FOUND",
 *       did: "did:cheqd:mainnet:hash123",
 *       indicators: {
 *         publicVcLikely: true,
 *         privateReportPossible: true
 *       }
 *     }
 *   - For NOT_FOUND status:
 *     {
 *       status: "NOT_FOUND",
 *       did: "did:cheqd:mainnet:hash123"
 *     }
 *   - For ERROR status:
 *     {
 *       status: "ERROR",
 *       did: "did:cheqd:mainnet:hash123",
 *       error: "ResolutionFailed",
 *       message: "..."
 *     }
 */
async function resolveDID(did) {
  if (!did) {
    console.error('No DID provided for resolution');
    return {
      status: 'ERROR',
      did: did || '',
      error: 'InvalidInput',
      message: 'No DID provided for resolution',
    };
  }

  try {
    // Get the server URL from storage
    const { verificationServer } = await chrome.storage.local.get('verificationServer');

    // Use the configured server URL or default to localhost
    const serverUrl = verificationServer || 'http://localhost:3001';

    // Construct the DID resolution endpoint URL
    const resolveUrl = `${serverUrl}/resolve/${encodeURIComponent(did)}`;

    console.log(`Resolving DID: ${did} via ${resolveUrl}`);

    // Send the GET request to the server
    const response = await fetch(resolveUrl, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
      },
    });

    // If the response is not ok (status code outside the range 200-299)
    if (!response.ok) {
      // Try to parse the error response as JSON
      let errorData;
      try {
        errorData = await response.json();
      } catch (e) {
        // If parsing fails, create a generic error object
        errorData = {
          status: 'ERROR',
          did: did,
          error: 'ServerError',
          message: `Server returned status ${response.status}`,
        };
      }

      return errorData;
    }

    // Parse the successful response
    const result = await response.json();

    // Ensure the result has the expected structure
    if (!result.status) {
      console.error('Invalid response format from DID resolution endpoint', result);
      return {
        status: 'ERROR',
        did: did,
        error: 'InvalidResponseFormat',
        message: 'Server response missing required fields',
      };
    }

    return result;
  } catch (error) {
    console.error('Error resolving DID:', error);
    return {
      status: 'ERROR',
      did: did,
      error: 'NetworkError',
      message: error.message || 'Failed to connect to DID resolution service',
    };
  }
}

/**
 * Creates a content-hash based DID from a hash.
 *
 * @param {string} hash - The content hash (SHA-256 hex string)
 * @param {string} network - The network to use (default: "mainnet")
 * @returns {string} - The content-hash based DID
 */
function createContentHashDID(hash, network = 'mainnet') {
  if (!hash) {
    console.error('No hash provided for DID creation');
    return null;
  }

  return `did:cheqd:${network}:${hash}`;
}

// Export the functions
export { resolveDID, createContentHashDID };
