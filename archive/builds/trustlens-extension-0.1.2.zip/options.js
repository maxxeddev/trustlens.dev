// Import the config module
import { saveConfig } from './src/config.js';

// Saves options to chrome.storage.local.
async function saveOptions() {
  const hfApiToken = document.getElementById('hfApiToken').value;
  const cheqdIssuerDid = document.getElementById('cheqdIssuerDid').value;
  const verificationServer = document.getElementById('serverUrl').value;
  const trustRegistryApi = document.getElementById('trustRegistryApi').value;
  const scanApiEndpoint = document.getElementById('scanApiEndpoint').value;
  const cheqdRpcEndpoint = document.getElementById('cheqdRpcEndpoint').value;

  // Split authorities by newline, trim whitespace, and filter out empty lines
  const authoritiesText = document.getElementById('detectionAuthorities').value;
  const detectionAuthorities = authoritiesText
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

  // Split trusted DIDs by newline, trim whitespace, and filter out empty lines
  const trustedDidsText = document.getElementById('trustedDids').value;
  const trustedDids = trustedDidsText
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

  // Get batch settings
  const batchSize = parseInt(document.getElementById('batchSize').value, 10) || 8;
  const batchDelayMs = parseInt(document.getElementById('batchDelayMs').value, 10) || 250;
  const cachePrefix = document.getElementById('cachePrefix').value;

  // Get feature flags
  const enableDebugLogging = document.getElementById('enableDebugLogging').checked;
  const enableOfflineMode = document.getElementById('enableOfflineMode').checked;

  // Save using both the old keys for backward compatibility and the new config system
  chrome.storage.local.set(
    {
      // Legacy keys
      hfApiToken: hfApiToken,
      cheqdIssuerDid: cheqdIssuerDid,
      detectionAuthorities: detectionAuthorities,
      serverUrl: verificationServer,

      // New config keys
      verificationServer: verificationServer,
      trustRegistryApi: trustRegistryApi,
      scanApiEndpoint: scanApiEndpoint,
      cheqdRpcEndpoint: cheqdRpcEndpoint,
      verifierDid: cheqdIssuerDid,
      trustedDids: trustedDids,
      cachePrefix: cachePrefix,
      batchSize: batchSize,
      batchDelayMs: batchDelayMs,
      enableDebugLogging: enableDebugLogging,
      enableOfflineMode: enableOfflineMode,
    },
    function () {
      // Update status to let user know options were saved.
      const status = document.getElementById('status');
      status.textContent = 'Options saved.';

      // Also update the config module's cached config
      try {
        saveConfig({
          VERIFICATION_SERVER: verificationServer,
          TRUST_REGISTRY_API: trustRegistryApi,
          SCAN_API_ENDPOINT: scanApiEndpoint,
          CHEQD_RPC_ENDPOINT: cheqdRpcEndpoint,
          VERIFIER_DID: cheqdIssuerDid,
          TRUSTED_DIDS: trustedDids,
          CACHE_PREFIX: cachePrefix,
          BATCH_SIZE: batchSize,
          BATCH_DELAY_MS: batchDelayMs,
          ENABLE_DEBUG_LOGGING: enableDebugLogging,
          ENABLE_OFFLINE_MODE: enableOfflineMode,
        });
      } catch (error) {
        console.error('Error updating config module:', error);
      }

      setTimeout(function () {
        status.textContent = '';
      }, 1500);
    }
  );
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restoreOptions() {
  // Use default values if not set
  chrome.storage.local.get(
    {
      // Legacy keys with defaults
      hfApiToken: '',
      cheqdIssuerDid: '',
      detectionAuthorities: [], // Default to empty array
      serverUrl: 'http://localhost:3001', // Default server URL

      // New config keys with defaults
      verificationServer: 'http://localhost:3001',
      trustRegistryApi: 'https://api.trust-registry.example/check?did=',
      scanApiEndpoint: 'https://api.scan.trustlens.xyz',
      cheqdRpcEndpoint: 'https://rpc.cheqd.network',
      verifierDid: '',
      trustedDids: [
        'did:cheqd:testnet:zF7rhDBfUt9d1gJPjx7s1JXfUY7oVWkY',
        'did:cheqd:mainnet:zF7rhDBfUt9d1gJPjx7s1JXfUY7oVWkY',
      ],
      cachePrefix: 'trustlens:',
      batchSize: 8,
      batchDelayMs: 250,
      enableDebugLogging: false,
      enableOfflineMode: false,
    },
    function (items) {
      // Set values for existing fields
      document.getElementById('hfApiToken').value = items.hfApiToken;
      document.getElementById('cheqdIssuerDid').value = items.cheqdIssuerDid || items.verifierDid;
      document.getElementById('serverUrl').value = items.serverUrl || items.verificationServer;
      document.getElementById('detectionAuthorities').value = items.detectionAuthorities.join('\n');

      // Set values for new fields
      document.getElementById('trustRegistryApi').value = items.trustRegistryApi;
      document.getElementById('scanApiEndpoint').value = items.scanApiEndpoint;
      document.getElementById('cheqdRpcEndpoint').value = items.cheqdRpcEndpoint;
      document.getElementById('trustedDids').value = items.trustedDids.join('\n');
      document.getElementById('cachePrefix').value = items.cachePrefix;
      document.getElementById('batchSize').value = items.batchSize;
      document.getElementById('batchDelayMs').value = items.batchDelayMs;
      document.getElementById('enableDebugLogging').checked = items.enableDebugLogging;
      document.getElementById('enableOfflineMode').checked = items.enableOfflineMode;
    }
  );
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
