/**
 * TrustLens Wallet Integration Module
 *
 * This module provides integration with blockchain wallets for the TrustLens extension.
 * It supports Leap wallet on Cheqd testnet for verification requests.
 */

import { LeapAdapter } from './wallet/LeapAdapter.js';

const adapters = [new LeapAdapter() /* , new CosmostationAdapter(), … */];

let active = null; // ⇢ current WalletAdapter
let address = null; // ⇢ bech32
let TRUSTLENS_SERVER_URL = `http://localhost:${process.env.SERVER_PORT || '3001'}`;

/**
 * Initialize the wallet integration with configuration
 *
 * @param {Object} config - Configuration object
 * @param {string} config.serverUrl - The TrustLens server URL
 */
async function initWalletIntegration(config = {}) {
  console.log('Initializing TrustLens wallet integration');

  // Set the server URL from config or use default
  TRUSTLENS_SERVER_URL = config.serverUrl || `http://localhost:${process.env.SERVER_PORT || '3001'}`;

  console.log(`TrustLens server URL set to: ${TRUSTLENS_SERVER_URL}`);

  // Check if wallet was previously connected
  try {
    const storedWallet = await chrome.storage.local.get([
      'connectedWallet',
      'walletAddress',
      'walletType',
    ]);

    if (storedWallet.connectedWallet && storedWallet.walletAddress) {
      console.log(
        `Restoring wallet connection: ${storedWallet.walletType} - ${storedWallet.walletAddress.substring(0, 8)}...`
      );

      connectedWallet = storedWallet.connectedWallet;
      walletAddress = storedWallet.walletAddress;
      walletType = storedWallet.walletType;

      return {
        success: true,
        address: walletAddress,
        type: walletType,
      };
    }
  } catch (error) {
    console.error('Error restoring wallet connection:', error);
  }

  return {
    success: false,
    error: 'No wallet connected',
  };
}

/**
 * Connect to a wallet by id ('leap', …)
 *
 * @returns {Promise<{success: boolean, address?: string, error?: string}>}
 */
async function connectWallet(id = 'leap') {
  const adapter = adapters.find(a => a.id === id);
  if (!adapter) return { success: false, error: `Adapter '${id}' not registered` };

  if (!adapter.isInstalled()) return { success: false, error: `${adapter.label} is not installed` };

  try {
    const CHAIN_ID = 'cheqd-testnet-6';
    const signer = await adapter.getSigner(CHAIN_ID);
    const [acct] = await signer.getAccounts();

    active = adapter;
    address = acct.address;

    await chrome.storage.local.set({
      connectedWallet: adapter.id,
      walletAddress: address,
    });
    return { success: true, address, type: adapter.id };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * Disconnect the currently connected wallet
 *
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function disconnectWallet() {
  try {
    // Clear global variables
    connectedWallet = null;
    walletAddress = null;
    walletType = null;

    // Clear wallet info from local storage
    await chrome.storage.local.remove(['connectedWallet', 'walletAddress', 'walletType']);

    console.log('Wallet disconnected');

    return {
      success: true,
    };
  } catch (error) {
    console.error('Error disconnecting wallet:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error disconnecting wallet',
    };
  }
}

/**
 * Check if a wallet is connected
 *
 * @returns {boolean}
 */
function isWalletConnected() {
  return !!connectedWallet && !!walletAddress;
}

/**
 * Get the connected wallet address
 *
 * @returns {string|null}
 */
function getWalletAddress() {
  return walletAddress;
}

/**
 * Get the connected wallet type
 *
 * @returns {string|null}
 */
function getWalletType() {
  return walletType;
}

/**
 * Get usage and reputation data for the connected wallet
 *
 * @returns {Promise<{usageMetrics: Object, reputation: Object, success: boolean, error?: string}>}
 */
async function getWalletUsageData() {
  try {
    // Check if wallet is connected
    if (!connectedWallet || !walletAddress) {
      return {
        usageMetrics: null,
        reputation: null,
        success: false,
        error: 'Wallet not connected',
      };
    }

    // Get the wallet DID from the connected wallet
    // In a real implementation, we would have a way to get the DID from the wallet address
    // For now, we'll use the wallet address as a proxy for the DID
    const walletDid = walletAddress;

    // Fetch usage data from the server
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/wallet/${walletDid}/usage`);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || 'Unknown error fetching wallet usage data');
    }

    return {
      usageMetrics: data.data.usageMetrics,
      reputation: data.data.reputation,
      success: true,
    };
  } catch (error) {
    console.error('Error getting wallet usage data:', error);
    return {
      usageMetrics: null,
      reputation: null,
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error getting wallet usage data',
    };
  }
}

/**
 * Get payment details for a verification request
 *
 * @returns {Promise<{success: boolean, amount: string, denom: string, recipient: string, memo: string, error?: string}>}
 */
async function getPaymentDetails() {
  try {
    // Fetch payment details from the server
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/payment/details`);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || 'Unknown error fetching payment details');
    }

    return {
      success: true,
      amount: data.amount,
      denom: data.denom,
      recipient: data.recipient,
      memo: data.memo,
    };
  } catch (error) {
    console.error('Error getting payment details:', error);
    return {
      success: false,
      amount: '0',
      denom: 'ncheq',
      recipient: '',
      memo: '',
      error: error instanceof Error ? error.message : 'Unknown error getting payment details',
    };
  }
}

/**
 * Request a payment from the connected wallet
 *
 * @param {Object} paymentDetails - Payment details
 * @param {string} paymentDetails.amount - Payment amount
 * @param {string} paymentDetails.denom - Payment denomination
 * @param {string} paymentDetails.recipient - Payment recipient
 * @param {string} paymentDetails.memo - Payment memo
 * @returns {Promise<{success: boolean, txHash?: string, error?: string}>}
 */
async function requestPayment(paymentDetails) {
  try {
    // Check if wallet is connected
    if (!connectedWallet || !walletAddress) {
      return {
        success: false,
        error: 'Wallet not connected',
      };
    }

    // Get the appropriate wallet object
    const wallet = window[connectedWallet];

    if (!wallet) {
      return {
        success: false,
        error: `${connectedWallet} wallet not found`,
      };
    }

    // The chain ID for Cheqd testnet
    const CHEQD_TESTNET_CHAIN_ID = 'cheqd-testnet-4';

    // Prepare the transaction
    const tx = {
      chainId: CHEQD_TESTNET_CHAIN_ID,
      msgs: [
        {
          typeUrl: '/cosmos.bank.v1beta1.MsgSend',
          value: {
            fromAddress: walletAddress,
            toAddress: paymentDetails.recipient,
            amount: [
              {
                denom: paymentDetails.denom,
                amount: paymentDetails.amount,
              },
            ],
          },
        },
      ],
      fee: {
        amount: [
          {
            denom: 'ncheq',
            amount: '5000',
          },
        ],
        gas: '200000',
      },
      memo: paymentDetails.memo,
    };

    // Sign and broadcast the transaction
    const result = await wallet.signAndBroadcast(tx);

    if (!result.success) {
      throw new Error(result.error || 'Transaction failed');
    }

    return {
      success: true,
      txHash: result.txHash,
    };
  } catch (error) {
    console.error('Error requesting payment:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error requesting payment',
    };
  }
}

/**
 * Send a verification request to the server
 *
 * @param {Object} verificationData - Verification data
 * @param {string} verificationData.contentHash - Content hash to verify
 * @param {string} verificationData.contentType - Content type (e.g., 'image', 'text')
 * @param {string} verificationData.paymentRequestId - Payment request ID (optional)
 * @returns {Promise<{success: boolean, jobId?: string, requestId?: string, error?: string}>}
 */
async function sendVerificationRequest(verificationData) {
  try {
    // Check if wallet is connected
    if (!connectedWallet || !walletAddress) {
      return {
        success: false,
        error: 'Wallet not connected',
      };
    }

    // Prepare the verification request
    const requestData = {
      contentHash: verificationData.contentHash,
      contentType: verificationData.contentType || 'hash',
      walletAddress: walletAddress,
      walletType: walletType,
      network: 'testnet',
    };

    // Add payment request ID if provided
    if (verificationData.paymentRequestId) {
      requestData.paymentRequestId = verificationData.paymentRequestId;
    }

    // Add signature if available
    if (verificationData.signature && verificationData.signedMessage) {
      requestData.signature = verificationData.signature;
      requestData.signedMessage = verificationData.signedMessage;
    }

    // Send the verification request to the new /verify endpoint
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    // Check if verification is in progress
    if (data.status === 'processing' && data.verificationInProgress) {
      return {
        success: true,
        jobId: data.jobId,
        requestId: data.requestId,
        trustScore: data.trustScore,
        status: 'processing',
      };
    }

    // Handle fallback response
    if (data.status === 'fallback') {
      return {
        success: true,
        trustScore: data.trustScore,
        status: 'fallback',
        message: data.message,
      };
    }

    // Handle error
    return {
      success: false,
      error: data.error || 'Unknown error sending verification request',
    };
  } catch (error) {
    console.error('Error sending verification request:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error sending verification request',
    };
  }
}

/**
 * Check the status of a verification request
 *
 * @param {string} requestId - Verification request ID
 * @returns {Promise<{success: boolean, status: string, result?: Object, error?: string}>}
 */
async function checkVerificationStatus(requestId) {
  try {
    // Fetch verification status from the server
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/verification/status/${requestId}`);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    return {
      success: true,
      status: data.status,
      result: data.result,
    };
  } catch (error) {
    console.error('Error checking verification status:', error);
    return {
      success: false,
      status: 'ERROR',
      error: error instanceof Error ? error.message : 'Unknown error checking verification status',
    };
  }
}

/**
 * Initiate the payment flow for a verification request
 *
 * @param {string} contentHash - Content hash to verify
 * @param {string} verificationType - Type of verification (e.g., 'ai', 'human')
 * @returns {Promise<{success: boolean, requestId?: string, error?: string}>}
 */
async function initiatePaymentFlow(contentHash, verificationType) {
  try {
    console.log(`Initiating payment flow for content hash: ${contentHash}`);

    // Check if wallet is connected
    if (!isWalletConnected()) {
      const res = await connectWallet('leap');
      if (!res.success) return { success: false, error: res.error };
    }

    // Get payment details
    const paymentDetails = await getPaymentDetails();

    if (!paymentDetails.success) {
      return {
        success: false,
        error: paymentDetails.error || 'Failed to get payment details',
      };
    }

    // Request payment
    const paymentResult = await requestPayment(paymentDetails);

    if (!paymentResult.success) {
      return {
        success: false,
        error: paymentResult.error || 'Payment failed',
      };
    }

    // Send verification request with payment info
    const verificationResult = await sendVerificationRequest({
      contentHash: contentHash,
      contentType: 'hash',
      paymentRequestId: paymentDetails.memo,
    });

    if (!verificationResult.success) {
      return {
        success: false,
        error: verificationResult.error || 'Verification request failed',
      };
    }

    return {
      success: true,
      requestId: verificationResult.requestId,
      jobId: verificationResult.jobId,
      status: verificationResult.status,
    };
  } catch (error) {
    console.error('Error initiating payment flow:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error initiating payment flow',
    };
  }
}

/**
 * Request a public verifiable credential
 *
 * @param {Object} vcData - VC request data
 * @param {string} vcData.contentHash - Content hash to include in the VC
 * @param {string} vcData.contentType - Content type (e.g., 'image', 'text')
 * @returns {Promise<{success: boolean, vc?: Object, error?: string}>}
 */
async function requestPublicVC(vcData) {
  try {
    // Check if wallet is connected
    if (!connectedWallet || !walletAddress) {
      return {
        success: false,
        error: 'Wallet not connected',
      };
    }

    // Prepare the VC request
    const requestData = {
      contentHash: vcData.contentHash,
      contentType: vcData.contentType || 'hash',
      walletAddress: walletAddress,
      walletType: walletType,
      network: 'testnet',
    };

    // Send the VC request to the server
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/issue-vc`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || 'Unknown error requesting public VC');
    }

    return {
      success: true,
      vc: data.vc,
    };
  } catch (error) {
    console.error('Error requesting public VC:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error requesting public VC',
    };
  }
}

/**
 * Fetch private report data from the server
 *
 * @param {string} requestId - Verification request ID
 * @param {string} token - Authorization token
 * @returns {Promise<{success: boolean, report?: Object, error?: string}>}
 */
async function fetchPrivateReportData(requestId, token) {
  try {
    // Fetch private report from the server
    const response = await fetch(`${TRUSTLENS_SERVER_URL}/api/verification/report/${requestId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Server returned ${response.status}: ${errorText}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || 'Unknown error fetching private report');
    }

    return {
      success: true,
      report: data.report,
    };
  } catch (error) {
    console.error('Error fetching private report:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error fetching private report',
    };
  }
}

// Expose the wallet integration functions to the window object
window.walletIntegration = {
  initWalletIntegration,
  connectWallet,
  getPaymentDetails,
  requestPayment,
  sendVerificationRequest,
  checkVerificationStatus,
  initiatePaymentFlow,
  requestPublicVC,
  disconnectWallet,
  isWalletConnected,
  getWalletAddress,
  getWalletType,
  getWalletUsageData,
  fetchPrivateReportData,
};
