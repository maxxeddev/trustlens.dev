// trustlens-extension/overlay-component.js
console.log('TrustLens Overlay Component Loaded');

// Import wallet integration module - safely with improved error handling and timeout
function loadWalletIntegration() {
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      // Add a small delay to ensure chrome.runtime is fully initialized
      setTimeout(() => {
        try {
          if (chrome.runtime.getURL) {
            const walletScript = document.createElement('script');
            walletScript.src = chrome.runtime.getURL('wallet-integration.js');
            walletScript.onload = function () {
              console.log('TrustLens Wallet Integration loaded');
            };
            walletScript.onerror = function (error) {
              console.error('Error loading wallet integration script:', error);
            };
            document.head.appendChild(walletScript);
          } else {
            console.warn('TrustLens: chrome.runtime.getURL is not available');
          }
        } catch (innerError) {
          console.error('TrustLens: Error accessing chrome.runtime.getURL:', innerError);
        }
      }, 100); // Small delay to ensure chrome API is ready
    } else {
      console.warn('TrustLens: chrome.runtime is not available in this context');
    }
  } catch (error) {
    console.error('TrustLens: Error in wallet integration loading:', error);
  }
}

// Call the function to load wallet integration
loadWalletIntegration();

// Import futuristic font
const fontImport = document.createElement('link');
fontImport.href = 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600&display=swap';
fontImport.rel = 'stylesheet';
document.head.appendChild(fontImport);

// Tailwind-like utility CSS for the new overlay component
const overlayStyles = `
  /* Base wrapper for positioning */
  .tl-wrapper {
    position: relative;
    display: inline-block;
  }

  /* Pill indicator styles */
  .tl-pill {
    position: absolute;
    top: -8px;
    right: -8px;
    padding: 2px 8px;
    border-radius: 9999px;
    font-size: 10px;
    font-weight: 600;
    font-family: 'Rajdhani', sans-serif;
    color: white;
    background-color: #475569; /* slate-700 */
    opacity: 0.8;
    transition: transform 0.2s ease;
    border: none;
    cursor: pointer;
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  /* Hover effect for pill */
  .tl-wrapper:hover .tl-pill {
    transform: scale(1.08);
  }

  /* Quick action icon */
  .tl-icon {
    position: absolute;
    top: 4px;
    right: 4px;
    display: none;
    background-color: rgba(0, 0, 0, 0.6);
    border-radius: 50%;
    padding: 4px;
    cursor: pointer;
    z-index: 1001;
    transition: opacity 0.2s ease;
  }

  /* Show icon on hover */
  .tl-wrapper:hover .tl-icon {
    display: flex;
  }
  
  /* Paid verification button */
  .tl-paid-verify {
    position: absolute;
    bottom: 4px;
    right: 4px;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 600;
    font-family: 'Rajdhani', sans-serif;
    color: white;
    background-color: #6366f1; /* indigo-500 */
    opacity: 0;
    transition: opacity 0.2s ease;
    border: none;
    cursor: pointer;
    z-index: 1001;
    display: flex;
    align-items: center;
    gap: 4px;
  }
  
  /* Show paid verification button on hover */
  .tl-wrapper:hover .tl-paid-verify {
    opacity: 0.9;
  }
  
  /* Hover effect for paid verification button */
  .tl-paid-verify:hover {
    opacity: 1;
    background-color: #4f46e5; /* indigo-600 */
  }

  /* Trust status colors */
  .tl-pending {
    background-color: #475569; /* slate-700 */
  }

  .tl-loading {
    background-color: #6366f1; /* indigo-500 */
    animation: pulse 1.5s infinite;
  }

  .tl-error {
    background-color: #dc2626; /* red-600 */
  }

  .tl-good {
    background-color: #10b981; /* emerald-500 (neon green) */
  }

  .tl-warn {
    background-color: #f59e0b; /* amber-500 */
  }

  .tl-bad {
    background-color: #ef4444; /* red-500 */
  }

  @keyframes pulse {
    0% { opacity: 0.7; }
    50% { opacity: 1; }
    100% { opacity: 0.7; }
  }

  /* SynthID states */
  .tl-synth-good  { background-color:#14b8a6; } /* teal-500 */
  .tl-synth-warn  { background-color:#facc15; } /* yellow-400 */
  .tl-synth-none  { background-color:#64748b; } /* slate-500 */

  /* Hidden utility class */
  .hidden {
    display: none;
  }

  /* Spinner animation for pending state */
  .tl-spinner {
    width: 10px;
    height: 10px;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: white;
    animation: tl-spin 1s linear infinite;
  }

  @keyframes tl-spin {
    to {
      transform: rotate(360deg);
    }
  }
`;

// Add styles to the document
function addOverlayStyles() {
  const styleEl = document.createElement('style');
  styleEl.textContent = overlayStyles;
  document.head.appendChild(styleEl);
}

// Function to determine trust class based on score
function getTrustClass(score, state) {
  // Handle special states first
  if (state === 'loading') {
    return 'tl-loading';
  } else if (state === 'error') {
    return 'tl-error';
  }

  // Handle score-based states
  if (score === null || score === undefined) {
    return 'tl-pending';
  } else if (score > 0.7) {
    return 'tl-good';
  } else if (score >= 0.4) {
    return 'tl-warn';
  } else {
    return 'tl-bad';
  }
}

// Function to create and apply the new overlay to an image
function applyNewOverlay(img, trustScore, imageHash, state, errorMessage) {
  // Skip if already processed with new overlay
  if (img.parentElement && img.parentElement.classList.contains('tl-wrapper')) {
    // If the image is already processed but we're updating its state, find the pill and update it
    if (state) {
      const existingPill = img.parentElement.querySelector('.tl-pill');
      if (existingPill) {
        updateOverlayState(img, trustScore, state, errorMessage);
      }
    }
    return;
  }

  // Create wrapper
  const wrapper = document.createElement('div');
  wrapper.className = 'tl-wrapper';

  // Insert wrapper before image and move image inside
  img.parentNode.insertBefore(wrapper, img);
  wrapper.appendChild(img);

  // Get trust class based on score and state
  const trustClass = getTrustClass(trustScore, state);

  // Create pill button
  const pill = document.createElement('button');
  pill.className = `tl-pill ${trustClass}`;
  pill.dataset.imageId = img.id || Math.random().toString(36).substring(2, 10);

  // Set pill content based on trust status
  const synth = img.dataset.synthid; // <- set later by content.js

  if (state === 'loading') {
    const spinner = document.createElement('div');
    spinner.className = 'tl-spinner';
    pill.appendChild(spinner);
    pill.appendChild(document.createTextNode('Scanning...'));
  } else if (state === 'error') {
    const errorIcon = document.createElement('span');
    errorIcon.textContent = '⚠️';
    errorIcon.style.marginRight = '4px';
    pill.appendChild(errorIcon);
    pill.appendChild(document.createTextNode('Error'));
    pill.title = errorMessage || 'An error occurred during verification';

    // Add retry functionality
    pill.addEventListener('click', e => {
      e.stopPropagation();
      // Send message to retry scanning this image
      chrome.runtime.sendMessage({
        cmd: 'retryScan',
        imageId: pill.dataset.imageId,
        src: img.src,
      });

      // Update to loading state
      updateOverlayState(img, null, 'loading');
    });
  } else if (trustClass === 'tl-pending') {
    const spinner = document.createElement('div');
    spinner.className = 'tl-spinner';
    pill.appendChild(spinner);
    pill.appendChild(document.createTextNode('Analyzing'));
  } else {
    const pct = document.createElement('span');
    pct.textContent = `${Math.round(trustScore * 100)}%`;

    if (synth) {
      const dot = document.createElement('span');
      dot.style.width = '8px';
      dot.style.height = '8px';
      dot.style.borderRadius = '50%';
      dot.style.marginLeft = '4px';
      dot.className =
        synth === 'present'
          ? 'tl-synth-good'
          : synth === 'weak'
            ? 'tl-synth-warn'
            : 'tl-synth-none';
      pill.appendChild(pct);
      pill.appendChild(dot);
    } else {
      pill.appendChild(pct);
    }
  }

  // Create quick-action icon
  const icon = document.createElement('div');
  icon.className = 'tl-icon hidden';
  icon.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
  </svg>`;

  // Create paid verification button
  const paidVerifyBtn = document.createElement('button');
  paidVerifyBtn.className = 'tl-paid-verify';
  paidVerifyBtn.innerHTML = `
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
    </svg>
    Paid Verify
  `;

  // Add click handlers
  pill.addEventListener('click', () => {
    if (imageHash) {
      chrome.runtime.sendMessage({
        cmd: 'openDrawer',
        hash: imageHash,
      });
    }
  });

  icon.addEventListener('click', () => {
    if (imageHash) {
      chrome.runtime.sendMessage({
        cmd: 'openDrawer',
        hash: imageHash,
      });
    }
  });

  // Add paid verification click handler
  paidVerifyBtn.addEventListener('click', async () => {
    if (imageHash) {
      // Get the content hash from the image hash
      const contentHash = imageHash.sha256 || imageHash;

      // Show loading state
      paidVerifyBtn.innerHTML = `
        <div class="tl-spinner"></div>
        Processing...
      `;
      paidVerifyBtn.disabled = true;

      try {
        // Check if window.initiatePaymentFlow is available (from wallet-integration.js)
        if (window.initiatePaymentFlow) {
          // Initiate payment flow
          const result = await window.initiatePaymentFlow(contentHash, 'ai');

          if (result.success) {
            paidVerifyBtn.innerHTML = `
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M20 6L9 17l-5-5"/>
              </svg>
              Verifying...
            `;

            // Notify the background script about the verification request
            chrome.runtime.sendMessage({
              cmd: 'paidVerificationRequested',
              requestId: result.requestId,
              contentHash: contentHash,
            });
          } else {
            paidVerifyBtn.innerHTML = `
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
              </svg>
              Paid Verify
            `;
            paidVerifyBtn.disabled = false;

            // Show error notification
            chrome.runtime.sendMessage({
              cmd: 'showNotification',
              type: 'error',
              message: result.error || 'Payment failed. Please try again.',
            });
          }
        } else {
          throw new Error('Wallet integration not loaded');
        }
      } catch (error) {
        console.error('Error initiating payment flow:', error);

        paidVerifyBtn.innerHTML = `
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
            <path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
          </svg>
          Paid Verify
        `;
        paidVerifyBtn.disabled = false;

        // Show error notification
        chrome.runtime.sendMessage({
          cmd: 'showNotification',
          type: 'error',
          message: error.message || 'Failed to initiate payment. Please try again.',
        });
      }
    }
  });

  // Add elements to wrapper
  wrapper.appendChild(pill);
  wrapper.appendChild(icon);
  wrapper.appendChild(paidVerifyBtn);

  // Mark the image as processed with new overlay
  img.classList.add('tl-processed-new');
}

// Function to update an existing overlay with new trust score
function updateOverlay(img, trustScore, message) {
  updateOverlayState(img, trustScore);
}

// Function to update an overlay's state (loading, error, or score-based)
function updateOverlayState(img, trustScore, state, errorMessage) {
  // Find the wrapper
  const wrapper = img.closest('.tl-wrapper');
  if (!wrapper) return;

  // Find the pill
  const pill = wrapper.querySelector('.tl-pill');
  if (!pill) return;

  // Update trust class based on state or score
  const trustClass = getTrustClass(trustScore, state);
  pill.className = `tl-pill ${trustClass}`;

  // Update content based on state
  pill.innerHTML = '';

  if (state === 'loading') {
    const spinner = document.createElement('div');
    spinner.className = 'tl-spinner';
    pill.appendChild(spinner);
    pill.appendChild(document.createTextNode('Scanning...'));
  } else if (state === 'error') {
    const errorIcon = document.createElement('span');
    errorIcon.textContent = '⚠️';
    errorIcon.style.marginRight = '4px';
    pill.appendChild(errorIcon);
    pill.appendChild(document.createTextNode('Error'));
    pill.title = errorMessage || 'An error occurred during verification';

    // Add retry functionality
    pill.onclick = e => {
      e.stopPropagation();
      // Send message to retry scanning this image
      chrome.runtime.sendMessage({
        cmd: 'retryScan',
        imageId: pill.dataset.imageId,
        src: img.src,
      });

      // Update to loading state
      updateOverlayState(img, null, 'loading');
    };
  } else {
    // Regular score-based update
    const synth = img.dataset.synthid;
    const pct = document.createElement('span');
    pct.textContent = `${Math.round(trustScore * 100)}%`;

    if (synth) {
      pill.appendChild(pct);

      const dot = document.createElement('span');
      dot.style.width = '8px';
      dot.style.height = '8px';
      dot.style.borderRadius = '50%';
      dot.style.marginLeft = '4px';
      dot.className =
        synth === 'present'
          ? 'tl-synth-good'
          : synth === 'weak'
            ? 'tl-synth-warn'
            : 'tl-synth-none';
      pill.appendChild(dot);
    } else {
      pill.appendChild(pct);
    }
  }
}

// Add styles to the document
addOverlayStyles();

// Export functions for use in content.js
window.TrustLensOverlay = {
  applyNewOverlay,
  updateOverlay,
  updateOverlayState,
  getTrustClass,
};

// Expose the initiatePaymentFlow function from wallet-integration.js to the window object
window.initiatePaymentFlow = async function (contentHash, verificationType) {
  // Check if the wallet integration module is loaded
  if (
    typeof window.walletIntegration !== 'undefined' &&
    typeof window.walletIntegration.initiatePaymentFlow === 'function'
  ) {
    return await window.walletIntegration.initiatePaymentFlow(contentHash, verificationType);
  } else {
    console.error('Wallet integration module not loaded');
    return {
      success: false,
      error: 'Wallet integration module not loaded',
    };
  }
};
