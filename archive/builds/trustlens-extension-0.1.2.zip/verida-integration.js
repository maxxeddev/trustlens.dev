/**
 * @fileoverview Integration layer for Verida SDK interactions within the TrustLens extension.
 * Handles initialization, connection, disconnection, and data storage/retrieval operations
 * with the Verida network, incorporating error handling and user feedback.
 */

// Import necessary Verida SDK components using ES module syntax
// Adjust imports based on the actual SDK structure and components used
import { Client } from '@verida/client-ts';
import { Network, Context } from '@verida/client-ts';
import { WebVaultAccount } from '@verida/account-web-vault'; // Or the appropriate account connector

// Global variable to hold the Verida context once connected
let context = null;
let veridaClient = null; // Assuming this might be used elsewhere, based on previous content glimpse
const CONTEXT_NAME = 'TrustLens Extension'; // Define context name centrally

// Default configuration (consider moving sensitive parts to environment variables or secure storage)
const DEFAULT_CONFIG = {
  client: {
    environment: 'testnet', // Or 'mainnet'
    didServerUrl: 'https://did.testnet.verida.io:5001', // Adjust for environment
    // Add other client configurations as needed (e.g., schema paths)
  },
  // Add other default settings if required
};

/**
 * Initializes the Verida SDK client.
 * Must be called before attempting to connect or interact with the network.
 *
 * @param {object} [config={}] - Optional configuration overrides.
 * @returns {Promise<object>} - Result object { success: boolean, error?: string, details?: any, message?: string }
 */
async function initVeridaSDK(config = {}) {
  const mergedConfig = { ...DEFAULT_CONFIG, ...config };

  // Basic validation
  if (!mergedConfig.client.environment) {
    console.error('Verida environment configuration is missing.');
    return { success: false, error: 'Missing Verida environment configuration.' };
  }

  if (veridaClient) {
    // Check if client instance exists
    console.warn('Verida SDK client already initialized.');
    // Consider if re-initialization should be allowed or handled differently
    return { success: true, message: 'Already initialized.' };
  }

  try {
    veridaClient = new Client(mergedConfig.client);
    console.log('Verida SDK Client Initialized successfully.');
    // Context is established upon connection, not initialization.
    return { success: true };
  } catch (error) {
    console.error('Error initializing Verida SDK Client:', error);
    veridaClient = null; // Ensure client is null if init fails
    context = null; // Also clear context just in case
    return { success: false, error: 'Failed to initialize Verida SDK Client', details: error };
  }
}

/**
 * Connects the user to the Verida network using the Web Vault.
 * Establishes the application context.
 *
 * @returns {Promise<object>} - Result object { success: boolean, did?: string, error?: string, details?: any, message?: string }
 */
async function connectVerida() {
  // Check if already connected using the established context
  if (context && (await isConnectedToVerida()).isConnected) {
    console.warn('Already connected to Verida.');
    try {
      const did = await context.getDid();
      return { success: true, did: did, message: 'Already connected.' };
    } catch (error) {
      console.error('Error getting DID from existing context:', error);
      // If getting DID fails, maybe the context is stale? Attempt reconnect.
      context = null; // Reset context to force reconnection attempt below
    }
  }

  // Ensure the client is initialized before attempting to connect
  if (!veridaClient) {
    console.error('Verida SDK client not initialized. Call initVeridaSDK first.');
    return { success: false, error: 'SDK client not initialized.' };
  }

  // Reset context before attempting connection
  context = null;

  try {
    // Use the WebVaultAccount connector
    const account = new WebVaultAccount({
      request: {
        logoUrl: 'https://assets.verida.io/verida_login_request_logo_170x170.png', // Optional: Your app's logo URL
        // Add other request parameters as needed
      },
    });

    // Initiate connection and open the application context
    context = await Network.connect({
      client: veridaClient, // Pass the initialized client instance
      account: account,
      context: {
        name: CONTEXT_NAME,
      },
      // Add other connection options if necessary
    });

    if (context && (await context.isConnected())) {
      const did = await context.getDid();
      console.log('Successfully connected to Verida and opened context. DID:', did);
      return { success: true, did: did };
    } else {
      // This case might be unlikely if connect() throws on failure, but included for safety
      console.error('Network.connect resolved but context is not connected or invalid.');
      context = null; // Ensure context is null
      return { success: false, error: 'Connection attempt failed post-resolution.' };
    }
  } catch (error) {
    console.error('Error connecting to Verida:', error);
    context = null; // Ensure context is null on error
    // Provide more specific error feedback if possible
    let errorMessage = 'Failed to connect to Verida.';
    if (error.message && error.message.includes('User cancelled')) {
      errorMessage = 'Connection cancelled by user.';
    } else if (error.message && error.message.includes('timeout')) {
      errorMessage = 'Connection timed out.';
    } else if (error.message && error.message.includes('already connected')) {
      // This might indicate a state mismatch, try to recover or inform user
      errorMessage = 'Connection state conflict detected.';
    }
    return { success: false, error: errorMessage, details: error };
  }
}

/**
 * Disconnects the user from the Verida network for this application context.
 *
 * @returns {Promise<object>} - Result object { success: boolean, error?: string, details?: any, message?: string }
 */
async function disconnectVerida() {
  // Use isConnectedToVerida to check status reliably
  const connectionStatus = await isConnectedToVerida();
  if (!connectionStatus.isConnected) {
    console.warn('Not connected to Verida, cannot disconnect.');
    context = null; // Ensure context is cleared even if disconnect wasn't needed
    return { success: true, message: 'Not connected.' };
  }

  try {
    // Disconnect the context
    await context.disconnect();
    console.log('Successfully disconnected from Verida context.');
    context = null; // Clear the global context
    // Perform any additional cleanup needed for the application state
    return { success: true };
  } catch (error) {
    console.error('Error disconnecting from Verida:', error);
    // Attempt to clear context even if disconnect throws an error
    context = null;
    return { success: false, error: 'Failed to disconnect from Verida', details: error };
  }
}

/**
 * Checks if the user is currently connected to Verida within this application context.
 *
 * @returns {Promise<object>} - Result object { success: boolean, isConnected: boolean, error?: string, details?: any }
 */
async function isConnectedToVerida() {
  // Check if the context object exists and seems valid
  if (
    context &&
    typeof context.isConnected === 'function' &&
    typeof context.getDid === 'function'
  ) {
    try {
      // Perform a lightweight check, like getting the DID, to confirm the context is active
      const did = await context.getDid();
      const connected = !!did; // Consider connected if DID is retrieved successfully
      // const connected = await context.isConnected(); // Or rely on isConnected if deemed reliable
      return { success: true, isConnected: connected };
    } catch (error) {
      console.warn('Error checking Verida connection status (context might be stale):', error);
      // If checking status fails, assume not connected for safety
      context = null; // Clear potentially stale context
      return {
        success: false,
        error: 'Failed to verify connection status',
        details: error,
        isConnected: false,
      };
    }
  } else {
    // Context doesn't exist or is invalid
    // console.log("Verida context not available or invalid, assuming not connected.");
    return { success: true, isConnected: false }; // Success is true (check performed), result is 'not connected'.
  }
}

/**
 * Retrieves the Verida DID (Decentralized Identifier) of the connected user.
 *
 * @returns {Promise<object>} - Result object { success: boolean, did?: string, error?: string, details?: any }
 */
async function getVeridaDid() {
  const connectionStatus = await isConnectedToVerida();
  if (connectionStatus.isConnected && context) {
    // Ensure context is still valid after check
    try {
      const did = await context.getDid();
      if (did) {
        return { success: true, did: did };
      } else {
        // This case might indicate an issue even if isConnected was true
        console.error('getDid() returned null or undefined despite connection check passing.');
        return { success: false, error: 'Failed to retrieve DID (unexpected null).' };
      }
    } catch (error) {
      console.error('Error getting Verida DID:', error);
      return { success: false, error: 'Failed to get Verida DID', details: error };
    }
  } else {
    // console.warn("Cannot get Verida DID: Not connected or context invalid.");
    return { success: false, error: connectionStatus.error || 'Not connected.' };
  }
}

/**
 * Gets the active Verida authentication context object.
 * Useful for operations requiring the context instance directly.
 *
 * @returns {Promise<object>} - Result object { success: boolean, context?: Context, error?: string, details?: any }
 */
async function getVeridaAuthContext() {
  const connectionStatus = await isConnectedToVerida();
  if (connectionStatus.isConnected && context) {
    // Ensure context is still valid
    // Return the validated context object
    return { success: true, context: context };
  } else {
    // console.warn("Cannot get Verida context: Not connected or context invalid.");
    return { success: false, error: connectionStatus.error || 'Not connected.' };
  }
}

/**
 * Gets the initialized Verida client instance.
 *
 * @returns {Promise<object>} - Result object { success: boolean, client?: Client, error?: string }
 */
async function getVeridaClient() {
  if (veridaClient) {
    return { success: true, client: veridaClient };
  } else {
    console.error('Verida client requested before initialization.');
    return { success: false, error: 'Verida client not initialized.' };
  }
}

/**
 * Stores private report data securely in the user's Verida datastore.
 *
 * @param {any} privateReportData - The data to store (should be serializable).
 * @param {string} contentHash - A unique identifier for the data (e.g., hash of the content it relates to).
 * @returns {Promise<object>} - Result object { success: boolean, result?: any, error?: string, details?: any }
 */
async function storePrivateReportData(privateReportData, contentHash) {
  const authContextResult = await getVeridaAuthContext();
  if (!authContextResult.success) {
    console.error('Cannot store data: Verida context unavailable or invalid.');
    return { success: false, error: authContextResult.error || 'Verida context unavailable.' };
  }
  const currentContext = authContextResult.context; // Use the validated context

  if (!privateReportData || !contentHash) {
    console.error('Missing private report data or content hash for storage.');
    return { success: false, error: 'Missing required data for storage.' };
  }

  try {
    // Define the database and schema
    const dbName = 'TrustLens_Private_Verification_Report';
    const schemaUrl = 'https://common.schemas.verida.io/health/records/generic/v0.1.0/schema.json'; // Example schema, replace with yours if available
    // const schemaUrl = 'schemas/privateReport.json'; // Or use a local schema path if defined in client config

    const privateReportsDb = await currentContext.openDatabase(dbName, {
      permissions: {
        read: 'owner',
        write: 'owner',
      },
      // encryptionMethod: 'symmetric', // Default usually sufficient
      // schema: schemaUrl, // Optional: Enforce schema validation
    });

    // Prepare the data object for storage
    const reportData = {
      _id: contentHash, // Use content hash as the document ID for uniqueness and easy lookup
      report: privateReportData, // The actual data payload
      storedAt: new Date().toISOString(),
      contentHash: contentHash, // Store hash within the document too if useful for querying
      schema: schemaUrl, // Include schema reference in the document
      // Add any other relevant metadata
    };

    // Attempt to save the data (insert or update)
    // The `save` method often handles both creation and update based on _id presence.
    const result = await privateReportsDb.save(reportData, { forceUpdate: true }); // forceUpdate ensures overwrite if _id exists

    if (result && result.ok) {
      console.log(`Private report data stored/updated successfully for hash: ${contentHash}`);
      return { success: true, result: result };
    } else {
      // Handle cases where save resolves but indicates failure (e.g., validation error if schema used)
      console.error(
        `Failed to store private report data (save result not ok) for hash: ${contentHash}`,
        result
      );
      return {
        success: false,
        error: 'Failed to store data in Verida database (result not ok).',
        details: result,
      };
    }
  } catch (error) {
    console.error(`Error storing private report data for hash ${contentHash}:`, error);
    // Handle specific errors if possible (e.g., network, permissions, quota, schema validation)
    let errorMessage = 'Failed to store data due to an unexpected error.';
    if (error.message) {
      if (error.message.includes('Network') || error.message.includes('Failed to fetch')) {
        errorMessage = 'Network error during storage.';
        // Consider suggesting retry here or letting caller handle it
      } else if (error.message.includes('permission') || error.message.includes('Unauthorized')) {
        errorMessage = 'Permission denied for database operation.';
      } else if (error.message.includes('quota')) {
        errorMessage = 'Storage quota exceeded.';
      } else if (error.message.includes('schema')) {
        errorMessage = 'Data does not conform to the required schema.';
      } else {
        errorMessage = `Storage error: ${error.message}`; // Include specific message if available
      }
    }
    return { success: false, error: errorMessage, details: error };
  }
}

/**
 * Retrieves and decrypts private report data from the user's Verida datastore.
 *
 * @param {string} contentHash - The content hash used as the key (_id) for the data.
 * @returns {Promise<object>} - Result object { success: boolean, data?: any, document?: any, error?: string, code?: string, details?: any }
 */
async function retrievePrivateReportData(contentHash) {
  const authContextResult = await getVeridaAuthContext();
  if (!authContextResult.success) {
    console.error('Cannot retrieve data: Verida context unavailable or invalid.');
    return { success: false, error: authContextResult.error || 'Verida context unavailable.' };
  }
  const currentContext = authContextResult.context; // Use the validated context

  if (!contentHash) {
    console.error('Missing content hash for retrieval.');
    return { success: false, error: 'Missing content hash.' };
  }

  try {
    // Open the same database used for storage
    const dbName = 'TrustLens_Private_Verification_Report';
    const privateReportsDb = await currentContext.openDatabase(dbName, {
      permissions: {
        read: 'owner', // Ensure read permission is set correctly
        write: 'owner', // Include write if needed, though typically only read is required here
      },
      // encryptionMethod: 'symmetric', // Ensure consistency with storage
    });

    // Retrieve the data using the content hash as the document ID (_id)
    // Use the `get()` method for direct lookup by ID.
    const reportDocument = await privateReportsDb.get(contentHash, {}); // Pass options if needed, e.g., { decrypt: true } (usually default)

    if (reportDocument) {
      // Data found
      console.log(`Private report data retrieved successfully for hash: ${contentHash}`);
      // Return the specific report data payload and optionally the full document
      return { success: true, data: reportDocument.report, document: reportDocument };
    } else {
      // Data not found for the given hash (get returns null/undefined)
      console.log(`No private report data found for hash: ${contentHash}`);
      return { success: false, error: 'Data not found.', code: 'NOT_FOUND' };
    }
  } catch (error) {
    console.error(`Error retrieving private report data for hash ${contentHash}:`, error);
    // Handle specific errors like decryption, network, permissions, or if get() throws on not found
    let errorMessage = 'Failed to retrieve data due to an unexpected error.';
    let errorCode = 'RETRIEVAL_FAILED';

    if (error.message) {
      if (error.message.includes('Network') || error.message.includes('Failed to fetch')) {
        errorMessage = 'Network error during retrieval.';
        errorCode = 'NETWORK_ERROR';
      } else if (error.message.includes('permission') || error.message.includes('Unauthorized')) {
        errorMessage = 'Permission denied for database read.';
        errorCode = 'PERMISSION_DENIED';
      } else if (error.message.includes('decrypt') || error.message.includes('MAC check failed')) {
        errorMessage = 'Failed to decrypt stored data.';
        errorCode = 'DECRYPTION_FAILED';
      } else if (error.message.includes('not found') || error.status === 404) {
        // Catch specific not found errors if thrown
        console.log(`No private report data found (error catch) for hash: ${contentHash}`);
        errorMessage = 'Data not found.';
        errorCode = 'NOT_FOUND';
      } else {
        errorMessage = `Retrieval error: ${error.message}`;
      }
    }

    // Return consistent error structure
    const returnError = { success: false, error: errorMessage, code: errorCode, details: error };
    // If the error code was NOT_FOUND, ensure the structure matches the non-error case
    if (errorCode === 'NOT_FOUND') {
      return { success: false, error: 'Data not found.', code: 'NOT_FOUND' };
    } else {
      return returnError;
    }
  }
}

// Make functions available in the global scope (e.g., for content scripts or popup)
// Consider using message passing (chrome.runtime.sendMessage) for better security and structure
// if these functions are called from different extension parts (like content scripts).
window.veridaIntegration = {
  initVeridaSDK,
  connectVerida,
  disconnectVerida,
  isConnectedToVerida,
  getVeridaDid,
  getVeridaAuthContext,
  getVeridaClient, // Expose client getter if needed
  storePrivateReportData,
  retrievePrivateReportData,
};

// Export functions as ES modules
export {
  storePrivateReportData,
  retrievePrivateReportData,
  initVeridaSDK,
  connectVerida,
  disconnectVerida,
  isConnectedToVerida,
  getVeridaDid,
  getVeridaAuthContext,
  getVeridaClient,
};

console.log('verida-integration.js loaded'); // Log script load
