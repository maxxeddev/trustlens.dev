// trustlens-extension/content.js
console.log('TrustLens Content Script Running');

// Function to safely load extension resources
function loadExtensionResource(resourceName, onloadCallback) {
  // Check if chrome.runtime is available
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(resourceName);
    script.onload = onloadCallback;
    document.head.appendChild(script);
    return true;
  } else {
    console.warn(
      `TrustLens: Unable to load ${resourceName} - chrome.runtime is not available in this context`
    );
    return false;
  }
}

// Import overlay component script
loadExtensionResource('overlay-component.js', function () {
  console.log('TrustLens Overlay Component loaded');
});

// Import wallet integration script
const walletLoaded = loadExtensionResource('wallet-integration.js', function () {
  console.log('TrustLens Wallet Integration loaded');

  // Initialize wallet integration with server URL from storage
  if (typeof chrome !== 'undefined' && chrome.storage) {
    chrome.storage.local.get(['serverUrl'], function (result) {
      const serverUrl = result.serverUrl || 'http://localhost:3001';
      if (
        window.walletIntegration &&
        typeof window.walletIntegration.initWalletIntegration === 'function'
      ) {
        window.walletIntegration.initWalletIntegration({ serverUrl });
      }
    });
  }
});

// Import Verida integration script
loadExtensionResource('verida-integration.js', function () {
  console.log('TrustLens Verida Integration loaded');

  // Initialize Verida SDK
  if (window.veridaIntegration && typeof window.veridaIntegration.initVeridaSDK === 'function') {
    window.veridaIntegration.initVeridaSDK().then(result => {
      console.log('Verida SDK initialization result:', result);

      // Check if user is already connected
      window.veridaIntegration.isConnectedToVerida().then(connectionStatus => {
        console.log('Verida connection status:', connectionStatus);
      });
    });
  }
});

// Import futuristic font
const fontImport = document.createElement('link');
fontImport.href = 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;600&display=swap';
fontImport.rel = 'stylesheet';
document.head.appendChild(fontImport);

// Enhanced CSS for futuristic visual indicators
const overlayStyles = `
  .trustlens-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    opacity: 0.4;
    transition: all 0.3s ease;
    z-index: 1000;
    backdrop-filter: blur(2px);
    border: 2px solid;
    box-shadow: 0 0 15px;
  }
  
  .trustlens-overlay.high-trust {
    border-color: #00ff9d;
    box-shadow: 0 0 15px #00ff9d80;
    background: linear-gradient(45deg, #00000080, #00302080);
  }
  
  .trustlens-overlay.medium-trust {
    border-color: #ffdd00;
    box-shadow: 0 0 15px #ffdd0080;
    background: linear-gradient(45deg, #00000080, #302a0080);
  }
  
  .trustlens-overlay.low-trust {
    border-color: #ff2d55;
    box-shadow: 0 0 15px #ff2d5580;
    background: linear-gradient(45deg, #00000080, #300a1080);
  }
  
  .trustlens-container {
    position: relative;
    display: inline-block;
  }
  
  .trustlens-container:hover .trustlens-overlay {
    opacity: 0.6;
  }
  
  .trustlens-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 5px 10px;
    border-radius: 20px;
    color: white;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    font-size: 14px;
    z-index: 1001;
    pointer-events: none;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid;
    box-shadow: 0 0 10px;
    backdrop-filter: blur(5px);
    transition: all 0.3s ease;
    text-shadow: 0 0 5px currentColor;
  }

  /* --- START: DID Status Badge Styles --- */
  .trustlens-did-badge {
    position: absolute;
    top: 10px; /* Align with trust badge */
    right: 60px; /* Position next to trust badge (adjust as needed) */
    padding: 3px 6px;
    border-radius: 10px;
    color: white;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    font-size: 10px; /* Smaller than main badge */
    z-index: 1001;
    pointer-events: none;
    border: 1px solid;
    box-shadow: 0 0 5px;
    backdrop-filter: blur(3px);
    text-shadow: 0 0 3px currentColor;
  }

  .trustlens-did-badge.did-found {
    background-color: rgba(0, 40, 20, 0.7);
    border-color: #00ff9d;
    box-shadow: 0 0 5px #00ff9d80;
  }

  .trustlens-did-badge.did-not-found {
    background-color: rgba(40, 0, 10, 0.7);
    border-color: #ff2d55;
    box-shadow: 0 0 5px #ff2d5580;
  }

  .trustlens-did-badge.did-error {
    background-color: rgba(40, 40, 0, 0.7);
    border-color: #ffdd00;
    box-shadow: 0 0 5px #ffdd0080;
  }

  .trustlens-did-badge.did-unknown {
     background-color: rgba(30, 30, 40, 0.7);
     border-color: #a0a0b8;
     box-shadow: 0 0 5px #a0a0b880;
  }
  /* --- END: DID Status Badge Styles --- */
  
  .trustlens-badge.high-trust {
    background-color: rgba(0, 40, 20, 0.7);
    border-color: #00ff9d;
    box-shadow: 0 0 10px #00ff9d80;
  }
  
  .trustlens-badge.medium-trust {
    background-color: rgba(40, 40, 0, 0.7);
    border-color: #ffdd00;
    box-shadow: 0 0 10px #ffdd0080;
  }
  
  .trustlens-badge.low-trust {
    background-color: rgba(40, 0, 10, 0.7);
    border-color: #ff2d55;
    box-shadow: 0 0 10px #ff2d5580;
    animation: pulse 2s infinite;
  }
  
  @keyframes pulse {
    0% {
      opacity: 0.8;
      transform: scale(1);
    }
    50% {
      opacity: 1;
      transform: scale(1.05);
    }
    100% {
      opacity: 0.8;
      transform: scale(1);
    }
  }
  
  .trustlens-detail-panel {
    position: absolute;
    top: 45px;
    right: 10px;
    width: 200px;
    background-color: rgba(10, 10, 20, 0.9);
    border-radius: 10px;
    padding: 10px;
    color: white;
    font-family: 'Rajdhani', sans-serif;
    z-index: 1002;
    backdrop-filter: blur(10px);
    border: 1px solid #ffffff30;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
    pointer-events: none;
  }
  
  .trustlens-badge:hover + .trustlens-detail-panel,
  .trustlens-detail-panel:hover {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
  }
  
  .trustlens-detail-panel h3 {
    margin: 0 0 10px 0;
    font-size: 16px;
    text-align: center;
    color: white;
  }
  
  .trust-meter {
    height: 6px;
    background-color: rgba(255, 255, 255, 0.2);
    border-radius: 3px;
    margin-bottom: 10px;
    overflow: hidden;
  }
  
  .meter-fill {
    height: 100%;
    transition: width 0.5s ease;
  }
  
  .high-trust .meter-fill {
    background-color: #00ff9d;
    box-shadow: 0 0 10px #00ff9d;
  }
  
  .medium-trust .meter-fill {
    background-color: #ffdd00;
    box-shadow: 0 0 10px #ffdd00;
  }
  
  .low-trust .meter-fill {
    background-color: #ff2d55;
    box-shadow: 0 0 10px #ff2d55;
  }
  
  .trust-source {
    font-size: 12px;
    text-align: center;
    opacity: 0.8;
  }

  /* --- START: DID Indicators in Detail Panel --- */
  .trust-did-indicators {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  }
  .trust-did-indicators h4 {
    font-size: 12px;
    margin: 0 0 5px 0;
    color: #a0a0b8;
    text-transform: uppercase;
  }
  .trust-did-indicator {
    display: flex;
    justify-content: space-between;
    font-size: 11px;
    margin-bottom: 3px;
  }
  .trust-did-indicator .label {
    opacity: 0.7;
  }
  .trust-did-indicator .value {
    font-weight: 600;
  }
  .trust-did-indicator .value.positive {
    color: #00ff9d;
  }
  .trust-did-indicator .value.negative {
    color: #ff2d55;
  }
  /* --- END: DID Indicators in Detail Panel --- */
  
  .trustlens-processed {
    /* Marker class for processed images */
  }
`;

// Add styles to the document
function addStyles() {
  const styleEl = document.createElement('style');
  styleEl.textContent = overlayStyles;
  document.head.appendChild(styleEl);
}

// Function to determine trust class based on score
function getTrustClass(score) {
  if (score > 0.7) {
    return 'high-trust';
  } else if (score >= 0.4) {
    return 'medium-trust';
  } else {
    return 'low-trust';
  }
}

// Function to create and apply overlay to an image
function applyOverlay(img, trustScore, message, imageHashes, didResolution) {
  // Added didResolution
  // Create container if the image isn't already wrapped
  let container = img.parentElement;
  if (!container.classList.contains('trustlens-container')) {
    container = document.createElement('div');
    container.className = 'trustlens-container';
    img.parentNode.insertBefore(container, img);
    container.appendChild(img);
  }

  // Get trust class based on score
  const trustClass = getTrustClass(trustScore);

  // Create overlay
  const overlay = document.createElement('div');
  overlay.className = `trustlens-overlay ${trustClass}`;

  // Create badge with score percentage
  const badge = document.createElement('div');
  badge.className = `trustlens-badge ${trustClass}`;
  badge.textContent = `${Math.round(trustScore * 100)}%`;

  // --- START: Create DID Status Badge ---
  let didBadge = null;
  if (didResolution && didResolution.status) {
    didBadge = document.createElement('div');
    let didStatusText = '';
    let didStatusClass = '';

    switch (didResolution.status) {
      case 'FOUND':
        didStatusText = 'DID ✓';
        didStatusClass = 'did-found';
        break;
      case 'NOT_FOUND':
        didStatusText = 'DID ✗';
        didStatusClass = 'did-not-found';
        break;
      case 'ERROR':
        didStatusText = 'DID Err';
        didStatusClass = 'did-error';
        break;
      default:
        didStatusText = 'DID ?';
        didStatusClass = 'did-unknown';
    }
    didBadge.className = `trustlens-did-badge ${didStatusClass}`;
    didBadge.textContent = didStatusText;
    didBadge.title = `DID Resolution: ${didResolution.status}`;
  }
  // --- END: Create DID Status Badge ---

  // Create detail panel
  const detailPanel = document.createElement('div');
  detailPanel.className = `trustlens-detail-panel ${trustClass}`;
  let hashesHtml = '';
  if (imageHashes) {
    hashesHtml = `
    <div class="trust-hashes" style="font-size: 10px; margin-top: 8px; overflow: hidden; text-overflow: ellipsis;">
      <div title="${imageHashes.phash}">PHash: ${imageHashes.phash.substring(0, 8)}...</div>
      <div title="${imageHashes.sha256}">SHA256: ${imageHashes.sha256.substring(0, 8)}...</div>
    </div>`;
  }

  detailPanel.innerHTML = `
    <h3>Trust Analysis</h3>
    <div class="trust-meter">
      <div class="meter-fill" style="width: ${trustScore * 100}%"></div>
    </div>
    <div class="trust-source">
      ${message || (trustScore > 0.7 ? 'Verified content' : trustScore >= 0.4 ? 'Uncertain content' : 'Suspicious content')}
    </div>
    ${hashesHtml}
    ${generateDidIndicatorsHtml(didResolution)}
  `;

  // Add overlay, badge, DID badge (if exists), and detail panel to container
  container.appendChild(overlay);
  container.appendChild(badge);
  if (didBadge) {
    container.appendChild(didBadge); // Add the DID badge
  }
  container.appendChild(detailPanel);

  // Mark the image as processed
  img.classList.add('trustlens-processed');
}

// Helper function to generate HTML for DID indicators in the detail panel
function generateDidIndicatorsHtml(didResolution) {
  if (
    !didResolution ||
    !didResolution.indicators ||
    Object.keys(didResolution.indicators).length === 0
  ) {
    return '';
  }

  let indicatorsHtml = '<div class="trust-did-indicators"><h4>DID Indicators</h4>';
  const indicators = didResolution.indicators;

  if (indicators.publicVcLikely !== undefined) {
    const valueClass = indicators.publicVcLikely ? 'positive' : 'negative';
    indicatorsHtml += `
      <div class="trust-did-indicator">
        <div class="tooltip-container">
          <span class="label">Public VC Likely:</span>
          <span class="value ${valueClass}">${indicators.publicVcLikely ? 'Yes' : 'No'}</span>
          <span class="tooltip">Indicates if a public Verifiable Credential associated with this image is likely available.</span>
        </div>
      </div>`;
  }
  if (indicators.privateReportPossible !== undefined) {
    const valueClass = indicators.privateReportPossible ? 'positive' : 'negative';
    indicatorsHtml += `
      <div class="trust-did-indicator">
        <div class="tooltip-container">
          <span class="label">Private Report Possible:</span>
          <span class="value ${valueClass}">${indicators.privateReportPossible ? 'Yes' : 'No'}</span>
          <span class="tooltip">Indicates if a private, detailed report might be obtainable for this image.</span>
        </div>
      </div>`;
  }

  // Add Verified Verifier badge and signature status if available
  if (indicators.verifierDid !== undefined) {
    const verifierDidShort = indicators.verifierDid.split(':').pop().substring(0, 8) + '...';
    const signatureStatus =
      indicators.verifierSignatureValid !== undefined
        ? indicators.verifierSignatureValid
          ? 'Valid'
          : 'Invalid'
        : 'Unknown';
    const signatureClass = indicators.verifierSignatureValid
      ? 'positive'
      : indicators.verifierSignatureValid === false
        ? 'negative'
        : 'neutral';

    indicatorsHtml += `
      <div class="trust-did-indicator">
        <div class="tooltip-container">
          <span class="label">
            <span class="verified-verifier-badge" style="background-color: #4f46e5; color: white; padding: 2px 4px; border-radius: 4px; font-size: 9px; margin-right: 4px;">Verified Verifier</span>
            Verifier DID:
          </span>
          <span class="value" title="${indicators.verifierDid}">${verifierDidShort}</span>
          <span class="tooltip">The AI verifier that analyzed this content has a verified identity.</span>
        </div>
      </div>
      <div class="trust-did-indicator">
        <div class="tooltip-container">
          <span class="label">Verifier Signature:</span>
          <span class="value ${signatureClass}">${signatureStatus}</span>
          <span class="tooltip">The signature status of the Verifier's Verifiable Credential.</span>
        </div>
      </div>`;
  }

  indicatorsHtml += '</div>';
  return indicatorsHtml;
}
// Function to process a single image
function processImage(img, index) {
  // Skip if already processed
  if (img.classList.contains('trustlens-processed') || img.classList.contains('tl-processed-new')) {
    return;
  }

  // Skip small images (icons, etc.)
  if (img.width < 50 || img.height < 50) {
    return;
  }

  console.log(`Processing image ${index + 1}:`, img.src);

  // Extract VCs from the page if not already done
  if (!window.extractedVCs) {
    window.extractedVCs = { metadataVCs: [], imageVCs: [] };
    if (window.trustlensVCExtractor) {
      window.extractedVCs = window.trustlensVCExtractor.extractAllVCs();
      console.log('Extracted VCs:', window.extractedVCs);
    }
  }

  // Find VC for this specific image if available
  let imageVC = null;

  // First check data-vc attribute directly
  imageVC = img.dataset.vc || img.getAttribute('data-vc');

  // If not found, check if we have a VC from the extractor
  if (!imageVC && window.extractedVCs.imageVCs) {
    window.extractedVCs.imageVCs.forEach(vc => {
      if (vc.src === img.src) {
        imageVC = vc.jwt;
      }
    });
  }

  // If no specific VC for this image, use page-level VCs
  if (!imageVC && window.extractedVCs.metadataVCs && window.extractedVCs.metadataVCs.length > 0) {
    imageVC = window.extractedVCs.metadataVCs[0];
  }

  // Generate a unique ID for this image
  const imgId = `img_${Date.now()}_${index}`;

  // Apply the new lightweight overlay in pending state
  if (window.TrustLensOverlay) {
    window.TrustLensOverlay.applyNewOverlay(img, null);
  } else {
    // Fall back to the original overlay if the new component isn't loaded yet
    console.log('TrustLens Overlay Component not loaded yet, using legacy overlay');
  }

  // Set a timeout to apply a default overlay if no response is received
  setTimeout(() => {
    // Check if the image has been processed already with a trust score
    if (
      !img.classList.contains('trustlens-processed') &&
      (!img.parentElement || !img.parentElement.querySelector('.tl-good, .tl-warn, .tl-bad'))
    ) {
      console.log(`Timeout reached for image ${index + 1}. Applying default overlay.`);

      if (window.TrustLensOverlay) {
        window.TrustLensOverlay.updateOverlay(
          img,
          0.5,
          'Analysis timeout - check extension configuration'
        );
      } else {
        applyOverlay(img, 0.5, 'Analysis timeout - check extension configuration', null);
      }
    }
  }, 5000); // 5 second timeout

  // Request analysis from background script
  chrome.runtime.sendMessage({
    cmd: 'analyzeImage',
    id: imgId,
    src: img.src,
    vc: imageVC,
    requestPublicVC: !imageVC, // Request a public VC if no VC is available
  });

  return img;
}

// Function to detect images and request analysis
function detectAndAnalyzeImages() {
  const images = document.querySelectorAll('img:not(.trustlens-processed)');
  console.log('Detected images count:', images.length);

  // Set the detectedCount variable on the window object for testing
  window.detectedCount = images.length;

  // Extract VCs from the page
  window.extractedVCs = { metadataVCs: [], imageVCs: [] };
  if (window.trustlensVCExtractor) {
    window.extractedVCs = window.trustlensVCExtractor.extractAllVCs();
    console.log('Extracted VCs:', window.extractedVCs);
  }

  // Process each image
  images.forEach((img, index) => processImage(img, index));

  // Return the count for validation
  return images.length;
}

// Store image hash information for later lookup
const processedImageHashes = new Map();

// Listen for results from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.cmd === 'imageResult') {
    // Find the image by ID
    const imgId = message.id;
    const imgIndex = parseInt(imgId.split('_')[2]);
    const images = document.querySelectorAll('img');

    if (imgIndex < images.length) {
      const img = images[imgIndex];
      // Extract DID resolution data from the message
      const didResolution = message.didResolution;
      console.log(
        `Applying overlay to image ${imgIndex + 1} with trust score:`,
        message.trustScore,
        'DID Status:',
        didResolution?.status
      );

      // Store the hash information for this image if available
      if (message.imageHashes && message.imageHashes.sha256) {
        processedImageHashes.set(message.imageHashes.sha256, img);
      }

      // Use the new overlay component if available
      if (
        window.TrustLensOverlay &&
        img.parentElement &&
        img.parentElement.classList.contains('tl-wrapper')
      ) {
        window.TrustLensOverlay.updateOverlay(img, message.trustScore, message.message);
      } else {
        // Fall back to the original overlay, passing didResolution
        applyOverlay(img, message.trustScore, message.message, message.imageHashes, didResolution);
      }

      // Set img.dataset.synthid based on verification result
      img.dataset.synthid = message.synthID
        ? message.synthID.confidence > 0.9
          ? 'present'
          : message.synthID.confidence > 0.5
            ? 'weak'
            : 'none'
        : 'none';
    }
  } else if (message.cmd === 'updateImageTrust') {
    // This message comes from batch verification completion
    // Extract DID resolution data as well
    const { sha256, trustScore, message: trustMessage, didResolution } = message;

    // Check if we have an image with this hash
    const img = processedImageHashes.get(sha256);
    if (img) {
      console.log(
        `Updating overlay for image with hash ${sha256.substring(0, 8)}... to trust score:`,
        trustScore
      );

      // Check if using new overlay
      if (
        window.TrustLensOverlay &&
        img.parentElement &&
        img.parentElement.classList.contains('tl-wrapper')
      ) {
        window.TrustLensOverlay.updateOverlay(
          img,
          trustScore,
          trustMessage || 'Updated via batch verification'
        );
      } else {
        // Using original overlay
        const container = img.parentElement;
        if (container && container.classList.contains('trustlens-container')) {
          // Remove existing overlay elements
          const existingOverlay = container.querySelector('.trustlens-overlay');
          const existingBadge = container.querySelector('.trustlens-badge');
          const existingPanel = container.querySelector('.trustlens-detail-panel');

          if (existingOverlay) existingOverlay.remove();
          if (existingBadge) existingBadge.remove();
          if (existingPanel) existingPanel.remove();

          // Apply new overlay with updated trust score and DID info
          applyOverlay(
            img,
            trustScore,
            trustMessage || 'Updated via batch verification',
            { sha256 },
            didResolution
          );
        }
      }
    }
  } else if (message.cmd === 'configError') {
    console.error('TrustLens configuration error:', message.message);
  } else if (message.cmd === 'checkVeridaConnection') {
    // Check Verida connection status
    if (
      window.veridaIntegration &&
      typeof window.veridaIntegration.isConnectedToVerida === 'function'
    ) {
      window.veridaIntegration.isConnectedToVerida().then(result => {
        console.log('Verida connection status:', result);
        chrome.runtime.sendMessage({
          cmd: 'veridaConnectionStatus',
          success: result.success,
          connected: result.connected,
          did: result.did,
        });

        sendResponse({
          success: result.success,
          connected: result.connected,
          did: result.did,
        });
      });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Verida integration not available');
      chrome.runtime.sendMessage({
        cmd: 'veridaConnectionStatus',
        success: false,
        connected: false,
        message: 'Verida integration not available',
      });

      sendResponse({
        success: false,
        connected: false,
        message: 'Verida integration not available',
      });
    }
  } else if (message.cmd === 'connectToVerida') {
    // Connect to Verida
    if (window.veridaIntegration && typeof window.veridaIntegration.connectVerida === 'function') {
      window.veridaIntegration.connectVerida().then(result => {
        console.log('Verida connection result:', result);
        chrome.runtime.sendMessage({
          cmd: 'veridaConnectionResult',
          success: result.success,
          message: result.message,
          did: result.did,
        });

        sendResponse({
          success: result.success,
          message: result.message,
          did: result.did,
        });
      });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Verida integration not available');
      chrome.runtime.sendMessage({
        cmd: 'veridaConnectionResult',
        success: false,
        message: 'Verida integration not available',
      });

      sendResponse({
        success: false,
        message: 'Verida integration not available',
      });
    }
  } else if (message.cmd === 'disconnectFromVerida') {
    // Disconnect from Verida
    if (
      window.veridaIntegration &&
      typeof window.veridaIntegration.disconnectVerida === 'function'
    ) {
      window.veridaIntegration.disconnectVerida().then(result => {
        console.log('Verida disconnection result:', result);
        chrome.runtime.sendMessage({
          cmd: 'veridaDisconnectionResult',
          success: result.success,
          message: result.message,
        });

        sendResponse({
          success: result.success,
          message: result.message,
        });
      });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Verida integration not available');
      chrome.runtime.sendMessage({
        cmd: 'veridaDisconnectionResult',
        success: false,
        message: 'Verida integration not available',
      });

      sendResponse({
        success: false,
        message: 'Verida integration not available',
      });
    }
  } else if (message.cmd === 'retrievePrivateReport') {
    // Retrieve private report data from Verida
  } else if (message.cmd === 'sendVerificationRequest') {
    // Send verification request using wallet integration
    if (
      window.walletIntegration &&
      typeof window.walletIntegration.sendVerificationRequest === 'function'
    ) {
      const { contentHash, contentType } = message;

      console.log(
        `Sending verification request for content hash: ${contentHash}, type: ${contentType}`
      );

      window.walletIntegration
        .sendVerificationRequest({
          contentHash,
          contentType: contentType || 'hash',
        })
        .then(result => {
          console.log('Verification request result:', result);

          // Send response back to popup
          sendResponse({
            success: result.success,
            jobId: result.jobId,
            requestId: result.requestId,
            trustScore: result.trustScore,
            status: result.status,
            message: result.message,
            error: result.error,
          });

          // Also send a message to the popup with the verification response
          chrome.runtime.sendMessage({
            cmd: 'verificationResponse',
            result: result,
          });
        })
        .catch(error => {
          console.error('Error sending verification request:', error);
          sendResponse({
            success: false,
            error: error.message || 'Unknown error sending verification request',
          });
        });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error(
        'Wallet integration not available or sendVerificationRequest function not found'
      );
      sendResponse({
        success: false,
        error: 'Wallet integration not available or sendVerificationRequest function not found',
      });
    }
  } else if (message.cmd === 'checkWalletConnectionStatus') {
    // Check wallet connection status
    if (
      window.walletIntegration &&
      typeof window.walletIntegration.isWalletConnected === 'function'
    ) {
      const isConnected = window.walletIntegration.isWalletConnected();
      const address = window.walletIntegration.getWalletAddress();
      const type = window.walletIntegration.getWalletType();

      console.log('Wallet connection status:', { isConnected, address, type });

      chrome.runtime.sendMessage({
        cmd: 'walletConnectionStatus',
        success: true,
        connected: isConnected,
        address: address,
        type: type,
      });

      sendResponse({
        success: true,
        connected: isConnected,
        address: address,
        type: type,
      });
    } else {
      console.error('Wallet integration not available');
      chrome.runtime.sendMessage({
        cmd: 'walletConnectionStatus',
        success: false,
        connected: false,
        message: 'Wallet integration not available',
      });

      sendResponse({
        success: false,
        connected: false,
        message: 'Wallet integration not available',
      });
    }
  } else if (message.cmd === 'connectLeapWallet') {
    // Connect to Leap wallet
    if (window.walletIntegration && typeof window.walletIntegration.connectLeap === 'function') {
      window.walletIntegration
        .connectLeap()
        .then(result => {
          console.log('Leap wallet connection result:', result);
          chrome.runtime.sendMessage({
            cmd: 'walletConnectionResult',
            success: result.success,
            message: result.error,
            address: result.address,
            type: result.type,
          });

          sendResponse({
            success: result.success,
            message: result.error,
            address: result.address,
            type: result.type,
          });
        })
        .catch(error => {
          console.error('Error connecting to Leap wallet:', error);
          chrome.runtime.sendMessage({
            cmd: 'walletConnectionResult',
            success: false,
            message: error.message || 'Unknown error connecting to Leap wallet',
          });

          sendResponse({
            success: false,
            message: error.message || 'Unknown error connecting to Leap wallet',
          });
        });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Wallet integration not available');
      chrome.runtime.sendMessage({
        cmd: 'walletConnectionResult',
        success: false,
        message: 'Wallet integration not available',
      });

      sendResponse({
        success: false,
        message: 'Wallet integration not available',
      });
    }
  } else if (message.cmd === 'connectKeplrWallet') {
    // Connect to Keplr wallet
    if (window.walletIntegration && typeof window.walletIntegration.connectKeplr === 'function') {
      window.walletIntegration
        .connectKeplr()
        .then(result => {
          console.log('Keplr wallet connection result:', result);
          chrome.runtime.sendMessage({
            cmd: 'walletConnectionResult',
            success: result.success,
            message: result.error,
            address: result.address,
            type: result.type,
          });

          sendResponse({
            success: result.success,
            message: result.error,
            address: result.address,
            type: result.type,
          });
        })
        .catch(error => {
          console.error('Error connecting to Keplr wallet:', error);
          chrome.runtime.sendMessage({
            cmd: 'walletConnectionResult',
            success: false,
            message: error.message || 'Unknown error connecting to Keplr wallet',
          });

          sendResponse({
            success: false,
            message: error.message || 'Unknown error connecting to Keplr wallet',
          });
        });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Wallet integration not available');
      chrome.runtime.sendMessage({
        cmd: 'walletConnectionResult',
        success: false,
        message: 'Wallet integration not available',
      });

      sendResponse({
        success: false,
        message: 'Wallet integration not available',
      });
    }
  } else if (message.cmd === 'disconnectWallet') {
    // Disconnect wallet
    if (
      window.walletIntegration &&
      typeof window.walletIntegration.disconnectWallet === 'function'
    ) {
      window.walletIntegration
        .disconnectWallet()
        .then(result => {
          console.log('Wallet disconnection result:', result);
          chrome.runtime.sendMessage({
            cmd: 'walletDisconnectionResult',
            success: result.success,
            message: result.error,
          });

          sendResponse({
            success: result.success,
            message: result.error,
          });
        })
        .catch(error => {
          console.error('Error disconnecting wallet:', error);
          chrome.runtime.sendMessage({
            cmd: 'walletDisconnectionResult',
            success: false,
            message: error.message || 'Unknown error disconnecting wallet',
          });

          sendResponse({
            success: false,
            message: error.message || 'Unknown error disconnecting wallet',
          });
        });

      // Return true to indicate that sendResponse will be called asynchronously
      return true;
    } else {
      console.error('Wallet integration not available');
      chrome.runtime.sendMessage({
        cmd: 'walletDisconnectionResult',
        success: false,
        message: 'Wallet integration not available',
      });

      sendResponse({
        success: false,
        message: 'Wallet integration not available',
      });
    }
    if (
      window.veridaIntegration &&
      typeof window.veridaIntegration.retrievePrivateReportData === 'function'
    ) {
      window.veridaIntegration
        .retrievePrivateReportData(message.contentHash)
        .then(result => {
          console.log('Verida private report retrieval result:', result);
          chrome.runtime.sendMessage({
            cmd: 'privateReportRetrieved',
            contentHash: message.contentHash,
            success: result.success,
            message: result.message,
            reportData: result.reportData,
            timestamp: result.timestamp,
            recordId: result.recordId,
          });
        })
        .catch(error => {
          console.error('Error retrieving private report from Verida:', error);
          chrome.runtime.sendMessage({
            cmd: 'privateReportRetrieved',
            contentHash: message.contentHash,
            success: false,
            message: error.message || 'Error retrieving private report data',
          });
        });
    } else {
      console.error(
        'Verida integration not available or retrievePrivateReportData function not found'
      );
      chrome.runtime.sendMessage({
        cmd: 'privateReportRetrieved',
        contentHash: message.contentHash,
        success: false,
        message: 'Verida integration not available or retrievePrivateReportData function not found',
      });
    }
  }
});

// Add styles to the document
addStyles();

// Run detection immediately and log results
const detectedCount = detectAndAnalyzeImages();

// Expose the processImage function for the dynamic content handler
window.trustlensProcessImage = processImage;

// Add validation for test page (optional)
if (window.location.href.includes('test-page.html')) {
  const expectedImageCount = 4; // Number of images on the test page
  if (detectedCount === expectedImageCount) {
    console.log('✅ Image detection test passed!');

    // For test page, apply mock overlays with different trust scores
    const images = document.querySelectorAll('img');
    if (images.length >= 4) {
      // Apply different trust scores for testing visual indicators
      setTimeout(() => {
        applyOverlay(images[0], 0.9, 'High trust score (90%)', null);
        applyOverlay(images[1], 0.6, 'Medium trust score (60%)', null);
        applyOverlay(images[2], 0.3, 'Low trust score (30%)', null);
        applyOverlay(images[3], 0.0, 'Zero trust score (0%)', null);
        console.log('✅ Applied test overlays with different trust scores');
      }, 500);
    }
  } else {
    console.error(
      '❌ Image detection test failed! Expected:',
      expectedImageCount,
      'Got:',
      detectedCount
    );
  }
}

// Add validation for VC test page
if (window.location.href.includes('test-vc-embedded.html')) {
  console.log('VC Test Page detected. Run testPassiveVCVerification() to test VC extraction.');

  // For test page, apply mock overlays with different trust scores
  const images = document.querySelectorAll('img');
  if (images.length > 0) {
    // Apply different trust scores based on data-vc attributes
    setTimeout(() => {
      images.forEach((img, index) => {
        // Default trust score
        let trustScore = 0.5;
        let message = 'Default trust score (50%)';

        // Check if image has data-vc attribute
        if (img.dataset.vc || img.getAttribute('data-vc')) {
          // Extract trust score from VC if possible
          try {
            const vcData = img.getAttribute('data-vc');
            // For demo purposes, use simple pattern matching
            if (vcData.includes('trustScore":0.95')) {
              trustScore = 0.95;
              message = 'High trust score from VC (95%)';
            } else if (vcData.includes('trustScore":0.85')) {
              trustScore = 0.85;
              message = 'High trust score from VC (85%)';
            } else if (vcData.includes('trustScore":0.6')) {
              trustScore = 0.6;
              message = 'Medium trust score from VC (60%)';
            } else if (vcData.includes('trustScore":0.2')) {
              trustScore = 0.2;
              message = 'Low trust score from VC (20%)';
            }
          } catch (error) {
            console.error('Error parsing VC:', error);
          }
        }

        applyOverlay(img, trustScore, message, null);
      });
      console.log('✅ Applied test overlays based on VCs');
    }, 500);
  }
}
