// TrustLens Content Verifier JavaScript

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function () {
  console.log('Content Verifier page loaded');

  // Get references to DOM elements
  const emailInput = document.getElementById('email');
  const notifyBtn = document.getElementById('notifyBtn');
  const backBtn = document.getElementById('backBtn');
  const emailSignupDiv = document.querySelector('.email-signup');

  // Email validation function - more robust than just checking for @
  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Create success message element (hidden initially)
  const successMessage = document.createElement('div');
  successMessage.className = 'success-message';
  successMessage.style.display = 'none';
  successMessage.style.backgroundColor = 'rgba(0, 255, 157, 0.1)';
  successMessage.style.border = '1px solid var(--accent-high)';
  successMessage.style.borderRadius = '4px';
  successMessage.style.padding = '15px';
  successMessage.style.marginTop = '20px';
  successMessage.style.textAlign = 'center';
  successMessage.style.color = 'var(--accent-high)';
  successMessage.style.boxShadow = '0 0 10px var(--glow-high)';
  successMessage.innerHTML = `
    <h3 style="margin-top: 0;">Thank You!</h3>
    <p>Your email has been registered. We'll notify you when the Content Verifier program launches.</p>
  `;

  // Add success message to the DOM (but keep it hidden)
  emailSignupDiv.appendChild(successMessage);

  // Add event listener for the notify button
  notifyBtn.addEventListener('click', function () {
    const email = emailInput.value.trim();

    // Validate email
    if (!validateEmail(email)) {
      // Show error message
      alert('Please enter a valid email address.');
      emailInput.focus();
      return;
    }

    // Store the email in chrome.storage.local
    if (chrome && chrome.storage && chrome.storage.local) {
      // Get existing emails array or create a new one
      chrome.storage.local.get(['contentVerifierEmails'], function (result) {
        let emails = result.contentVerifierEmails || [];

        // Add new email if it doesn't already exist
        if (!emails.includes(email)) {
          emails.push(email);

          // Save updated emails array
          chrome.storage.local.set({ contentVerifierEmails: emails }, function () {
            console.log('Email saved:', email);
            showSuccessMessage();
          });
        } else {
          console.log('Email already registered:', email);
          showSuccessMessage();
        }
      });
    } else {
      // Fallback for when chrome.storage is not available (e.g., when testing locally)
      console.log('Chrome storage not available, simulating email storage:', email);
      showSuccessMessage();
    }
  });

  // Function to show success message and hide the form
  function showSuccessMessage() {
    // Clear the input field
    emailInput.value = '';

    // Hide the form elements
    emailInput.style.display = 'none';
    notifyBtn.style.display = 'none';
    document.querySelector('label[for="email"]').style.display = 'none';

    // Show success message
    successMessage.style.display = 'block';

    // After 5 seconds, reset the form for potential additional submissions
    setTimeout(function () {
      // Hide success message
      successMessage.style.display = 'none';

      // Show form elements again
      emailInput.style.display = 'block';
      notifyBtn.style.display = 'block';
      document.querySelector('label[for="email"]').style.display = 'block';
    }, 5000);
  }

  // Back button functionality (already implemented in HTML, but adding here for completeness)
  backBtn.addEventListener('click', function (e) {
    e.preventDefault();
    window.history.back();
  });
});
