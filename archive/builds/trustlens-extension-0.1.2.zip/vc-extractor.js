/**
 * TrustLens VC Extractor
 * Extracts Verifiable Credentials from various sources in a webpage
 */

// Extract VCs from HTML metadata
function extractVCsFromMetadata() {
  // Look for meta tags with specific names/properties
  const metaTags = document.querySelectorAll(
    'meta[name="content-credential"], meta[property="content-credential"]'
  );
  const vcs = [];

  metaTags.forEach(meta => {
    try {
      const content = meta.getAttribute('content');
      if (content) {
        const data = JSON.parse(content);
        if (data.jwt) {
          vcs.push(data.jwt);
        }
      }
    } catch (error) {
      console.error('Error parsing VC from metadata:', error);
    }
  });

  return vcs;
}

// Extract VCs from image data attributes
function extractVCsFromImageAttributes() {
  const images = document.querySelectorAll('img[data-vc]');
  const vcs = [];

  images.forEach(img => {
    const vc = img.getAttribute('data-vc');
    if (vc) {
      vcs.push({
        jwt: vc,
        src: img.src,
      });
    }
  });

  return vcs;
}

// Extract VCs from HTTP headers (requires background script)
function extractVCsFromHeaders(headers) {
  const vcs = [];

  // Check for Content-Credential header
  if (headers['content-credential']) {
    try {
      const data = JSON.parse(headers['content-credential']);
      if (data.jwt) {
        vcs.push(data.jwt);
      }
    } catch (error) {
      console.error('Error parsing VC from header:', error);
    }
  }

  return vcs;
}

// Main extraction function
function extractAllVCs() {
  const metadataVCs = extractVCsFromMetadata();
  const imageVCs = extractVCsFromImageAttributes();

  // We'll need to handle header VCs differently since content scripts
  // don't have access to response headers directly

  return {
    metadataVCs,
    imageVCs,
  };
}

// Export functions
window.trustlensVCExtractor = {
  extractAllVCs,
  extractVCsFromMetadata,
  extractVCsFromImageAttributes,
  extractVCsFromHeaders,
};

console.log('TrustLens VC Extractor loaded');
