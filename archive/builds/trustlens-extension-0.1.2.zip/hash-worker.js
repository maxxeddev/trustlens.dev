// trustlens-extension/hash-worker.js

/**
 * Canonicalizes text content according to TrustLens rules.
 * Rules: Normalize line endings to LF -> Trim whitespace -> Remove BOM.
 * @param {string} text The input text content.
 * @returns {string} The canonicalized text.
 */
function canonicalizeText(text) {
  if (typeof text !== 'string') {
    // Handle non-string input if necessary, or throw error
    console.error('Input must be a string for canonicalization.');
    return ''; // Or throw an error
  }

  // 1. Normalize line endings to LF (\n)
  let canonical = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // 2. Trim leading/trailing whitespace
  canonical = canonical.trim();

  // 3. Remove UTF-8 BOM (Byte Order Mark) if present
  if (canonical.startsWith('\uFEFF')) {
    canonical = canonical.substring(1);
  }

  return canonical;
}

/**
 * Calculates the SHA-256 hash of the input data (ArrayBuffer).
 * @param {ArrayBuffer} buffer The data to hash.
 * @returns {Promise<ArrayBuffer>} A promise that resolves with the hash ArrayBuffer.
 */
async function sha256(buffer) {
  return await crypto.subtle.digest('SHA-256', buffer);
}

/**
 * Converts an ArrayBuffer to a lowercase hexadecimal string.
 * @param {ArrayBuffer} buffer The ArrayBuffer to convert.
 * @returns {string} The lowercase hexadecimal representation.
 */
function bufferToHex(buffer) {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Listen for messages from the main thread
self.onmessage = async event => {
  const { textContent } = event.data;

  if (textContent === undefined) {
    self.postMessage({ error: 'No textContent provided in message.' });
    return;
  }

  try {
    // 1. Canonicalize the text
    const canonicalText = canonicalizeText(textContent);

    // 2. Encode the canonicalized text to UTF-8 bytes
    const encoder = new TextEncoder(); // Defaults to UTF-8
    const encodedData = encoder.encode(canonicalText);

    // 3. Calculate the SHA-256 hash of the bytes
    const hashBuffer = await sha256(encodedData);

    // 4. Convert the hash buffer to a lowercase hexadecimal string
    const hashHex = bufferToHex(hashBuffer);

    // 5. Send the hash back to the main thread
    self.postMessage({ hash: hashHex });
  } catch (error) {
    console.error('Error hashing content in worker:', error);
    self.postMessage({ error: `Hashing failed: ${error.message}` });
  }
};

// Signal that the worker is ready
self.postMessage({ status: 'ready' });
