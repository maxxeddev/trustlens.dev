// TrustLens Popup Script

// Error handling and UI feedback utilities
const UIFeedback = {
  // Operation status types
  STATUS: {
    LOADING: 'loading',
    SUCCESS: 'success',
    ERROR: 'error',
  },

  // Show operation status in a section
  showOperationStatus: function (elementId, type, message, autoHide = true) {
    const statusElement = document.getElementById(elementId);
    if (!statusElement) return;

    // Clear existing classes and add the appropriate one
    statusElement.className = 'operation-status visible ' + type;

    // Update message
    const messageElement = statusElement.querySelector('span');
    if (messageElement) {
      messageElement.textContent = message;
    }

    // Auto-hide after 3 seconds if requested
    if (autoHide && type !== this.STATUS.LOADING) {
      setTimeout(() => {
        statusElement.className = 'operation-status';
      }, 3000);
    }
  },

  // Hide operation status
  hideOperationStatus: function (elementId) {
    const statusElement = document.getElementById(elementId);
    if (statusElement) {
      statusElement.className = 'operation-status';
    }
  },

  // Show error message with retry option
  showError: function (
    containerId,
    messageId,
    codeId,
    buttonId,
    message,
    errorCode,
    retryCallback
  ) {
    const container = document.getElementById(containerId);
    const messageElement = document.getElementById(messageId);
    const codeElement = document.getElementById(codeId);
    const buttonElement = document.getElementById(buttonId);

    if (!container || !messageElement) return;

    // Set error message
    messageElement.textContent = message || 'An error occurred.';

    // Set error code if available
    if (codeElement && errorCode) {
      codeElement.textContent = `Error code: ${errorCode}`;
      codeElement.style.display = 'block';
    } else if (codeElement) {
      codeElement.style.display = 'none';
    }

    // Set up retry button if callback provided
    if (buttonElement && retryCallback) {
      buttonElement.onclick = retryCallback;
      buttonElement.style.display = 'block';
    } else if (buttonElement) {
      buttonElement.style.display = 'none';
    }

    // Show the error container
    container.style.display = 'flex';
  },

  // Hide error message
  hideError: function (containerId) {
    const container = document.getElementById(containerId);
    if (container) {
      container.style.display = 'none';
    }
  },

  // Update loading status
  updateLoadingStatus: function (message) {
    const statusElement = document.getElementById('loadingStatus');
    if (statusElement) {
      statusElement.textContent = message;
      statusElement.style.display = message ? 'block' : 'none';
    }
  },
};

// Function to determine trust class based on score
function getTrustClass(score) {
  if (score > 0.7) {
    return 'high-trust';
  } else if (score >= 0.4) {
    return 'medium-trust';
  } else {
    return 'low-trust';
  }
}

// Function to format timestamp
function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Function to truncate URL
function truncateUrl(url, maxLength = 40) {
  if (url.length <= maxLength) return url;
  return url.substring(0, maxLength) + '...';
}

// Function to render results
function renderResults(logEntries) {
  console.log('Rendering results with', logEntries.length, 'entries');

  const resultsBody = document.getElementById('resultsBody');
  const imageCountElement = document.getElementById('imageCount');
  const loadingElement = document.getElementById('loading');
  const noResultsElement = document.getElementById('noResults');
  const scanErrorElement = document.getElementById('scanError');

  try {
    // Update image count
    imageCountElement.textContent = logEntries.length;

    // Hide loading indicator and error message
    loadingElement.style.display = 'none';
    UIFeedback.hideError('scanError');

    // Clear previous results
    resultsBody.innerHTML = '';

    // Check if there are any results
    if (logEntries.length === 0) {
      console.log('No entries to render');
      noResultsElement.style.display = 'block';
      return;
    }

    noResultsElement.style.display = 'none';

    // Render each log entry as a card
    logEntries.forEach((entry, index) => {
      console.log(`Rendering entry ${index}:`, entry.src);

      try {
        // Get trust score from either trust or trustScore property
        const trustScore =
          entry.trustScore !== undefined
            ? entry.trustScore
            : entry.trust !== undefined
              ? entry.trust
              : 0;
        console.log(`Entry ${index} trust score:`, trustScore);

        const trustClass = getTrustClass(trustScore);
        const hasVC = entry.vc ? true : false;
        const hasHashes = entry.imageHashes ? true : false;
        const hasLabels = entry.labels && entry.labels.length > 0;
        const hasSignals = entry.signals && Object.keys(entry.signals).length > 0;

        // Create card element
        const card = document.createElement('div');
        card.className = `cyber-card ${trustClass}`;
        card.dataset.trustScore = trustScore;
        card.dataset.hasVc = hasVC;
        card.dataset.hasHashes = hasHashes;

        // Create card header
        const cardHeader = document.createElement('div');
        cardHeader.className = 'card-header';

        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = formatTimestamp(entry.timestamp);

        const trustBadge = document.createElement('div');
        trustBadge.className = `trust-badge ${trustClass}`;
        trustBadge.textContent = `${Math.round(trustScore * 100)}%`;

        cardHeader.appendChild(timestamp);
        cardHeader.appendChild(trustBadge);

        // Create card content
        const cardContent = document.createElement('div');
        cardContent.className = 'card-content';

        // Image preview
        const imagePreview = document.createElement('img');
        imagePreview.className = 'image-preview';
        imagePreview.src = entry.src;
        imagePreview.alt = 'Image preview';

        // Content details
        const contentDetails = document.createElement('div');
        contentDetails.className = 'content-details';

        const imageSrc = document.createElement('div');
        imageSrc.className = 'image-src';
        imageSrc.textContent = truncateUrl(entry.src);
        imageSrc.title = entry.src;

        const status = document.createElement('div');
        status.className = 'status';

        // Add badges
        if (hasVC) {
          const vcBadge = document.createElement('span');
          vcBadge.className = 'badge badge-vc';
          vcBadge.textContent = 'VC';
          status.appendChild(vcBadge);
        }

        const aiBadge = document.createElement('span');
        aiBadge.className = 'badge badge-ai';
        aiBadge.textContent = 'AI';
        status.appendChild(aiBadge);

        // --- START: Add DID Status Badge ---
        if (entry.didResolution && entry.didResolution.status) {
          const didBadge = document.createElement('span');
          didBadge.className = 'badge'; // Base class
          let didStatusText = '';
          let didStatusClass = '';

          switch (entry.didResolution.status) {
            case 'FOUND':
              didStatusText = 'DID ✓';
              didStatusClass = 'badge-did-found';
              break;
            case 'NOT_FOUND':
              didStatusText = 'DID ✗';
              didStatusClass = 'badge-did-not-found';
              break;
            case 'ERROR':
              didStatusText = 'DID Err';
              didStatusClass = 'badge-did-error';
              break;
            default:
              didStatusText = 'DID ?';
              didStatusClass = 'badge-did-unknown';
          }
          didBadge.textContent = didStatusText;
          didBadge.classList.add(didStatusClass);
          didBadge.title = `DID Resolution Status: ${entry.didResolution.status}`;
          status.appendChild(didBadge);
        }
        // --- END: Add DID Status Badge ---

        // Add status message
        const statusText = document.createElement('span');
        statusText.textContent = entry.message || getTrustMessage(trustScore);
        status.appendChild(statusText);

        // Add issuer info if available
        if (hasVC && entry.issuer) {
          const issuer = document.createElement('div');
          issuer.className = 'issuer';
          issuer.innerHTML = `Verified by: <strong>${entry.issuer}</strong>`;
          contentDetails.appendChild(issuer);
        }

        contentDetails.appendChild(imageSrc);
        contentDetails.appendChild(status);

        cardContent.appendChild(imagePreview);
        cardContent.appendChild(contentDetails);

        // Create card actions
        const cardActions = document.createElement('div');
        cardActions.className = 'card-actions';

        // Add upvote/downvote buttons (for demo)
        const upvoteBtn = document.createElement('button');
        upvoteBtn.className = 'cyber-button';
        upvoteBtn.innerHTML = `<span class="icon">▲</span><span class="count">${Math.floor(Math.random() * 20)}</span>`;
        upvoteBtn.title = 'Upvote this analysis';

        const downvoteBtn = document.createElement('button');
        downvoteBtn.className = 'cyber-button';
        downvoteBtn.innerHTML = `<span class="icon">▼</span><span class="count">${Math.floor(Math.random() * 5)}</span>`;
        downvoteBtn.title = 'Downvote this analysis';

        const commentBtn = document.createElement('button');
        commentBtn.className = 'cyber-button';
        commentBtn.innerHTML = `<span class="icon">💬</span><span class="count">${Math.floor(Math.random() * 10)}</span>`;
        commentBtn.title = 'View comments';

        // Add details button
        const detailsBtn = document.createElement('button');
        detailsBtn.className = 'details-btn';
        detailsBtn.textContent = 'Details';
        detailsBtn.dataset.index = index;
        detailsBtn.addEventListener('click', toggleDetails);

        cardActions.appendChild(upvoteBtn);
        cardActions.appendChild(downvoteBtn);
        cardActions.appendChild(commentBtn);
        cardActions.appendChild(detailsBtn);

        // Create details content (hidden by default)
        const detailsContent = document.createElement('div');
        detailsContent.className = 'details-content';
        detailsContent.id = `details-${index}`;

        // Add trust meter
        const trustMeterSection = document.createElement('div');
        trustMeterSection.className = 'details-section';

        const trustMeterTitle = document.createElement('h4');
        trustMeterTitle.textContent = 'Trust Analysis';

        const trustMeter = document.createElement('div');
        trustMeter.className = 'trust-meter';

        const meterFill = document.createElement('div');
        meterFill.className = `meter-fill ${trustClass}`;
        meterFill.style.width = `${trustScore * 100}%`;

        trustMeter.appendChild(meterFill);
        trustMeterSection.appendChild(trustMeterTitle);
        trustMeterSection.appendChild(trustMeter);

        // Add AI detection details
        const aiSection = document.createElement('div');
        aiSection.className = 'details-section';

        const aiTitle = document.createElement('h4');
        aiTitle.textContent = 'AI Detection Results';

        const aiDetails = document.createElement('div');
        aiDetails.className = 'details-items';

        // Add some mock AI detection results
        const aiScores = [
          { label: 'Generated Image', value: (Math.random() * 0.5 + 0.5).toFixed(2) },
          { label: 'Manipulated Photo', value: (Math.random() * 0.3 + 0.2).toFixed(2) },
          { label: 'Authentic Photo', value: (Math.random() * 0.3).toFixed(2) },
        ];

        aiScores.forEach(score => {
          const item = document.createElement('div');
          item.className = 'details-item';

          const label = document.createElement('span');
          label.className = 'details-label';
          label.textContent = score.label;

          const value = document.createElement('span');
          value.className = 'details-value';
          value.textContent = score.value;

          item.appendChild(label);
          item.appendChild(value);
          aiDetails.appendChild(item);
        });

        // Add Confidence Score if available
        if (entry.confidenceScore !== undefined) {
          const confidenceItem = document.createElement('div');
          confidenceItem.className = 'details-item';

          const confidenceLabel = document.createElement('span');
          confidenceLabel.className = 'details-label';
          confidenceLabel.textContent = 'Confidence Score:';
          confidenceItem.appendChild(confidenceLabel);

          const confidenceValue = document.createElement('span');
          confidenceValue.className = 'details-value';
          confidenceValue.textContent = entry.confidenceScore.toFixed(2); // Format to 2 decimal places
          confidenceItem.appendChild(confidenceValue);

          aiDetails.appendChild(confidenceItem);
        }

        // Add Reasoning if available
        if (entry.reasoning !== undefined) {
          const reasoningItem = document.createElement('div');
          reasoningItem.className = 'details-item';

          const reasoningLabel = document.createElement('span');
          reasoningLabel.className = 'details-label';
          reasoningLabel.textContent = 'Reasoning:';
          reasoningItem.appendChild(reasoningLabel);

          const reasoningValue = document.createElement('span');
          reasoningValue.className = 'details-value';
          reasoningValue.textContent = entry.reasoning;
          reasoningItem.appendChild(reasoningValue);

          aiDetails.appendChild(reasoningItem);
        }

        aiSection.appendChild(aiTitle);
        aiSection.appendChild(aiDetails);

        // Add Labels section if available
        if (hasLabels) {
          const labelsSection = document.createElement('div');
          labelsSection.className = 'details-section';

          const labelsTitle = document.createElement('h4');
          labelsTitle.textContent = 'Image Labels';

          const labelsDetails = document.createElement('div');
          labelsDetails.className = 'details-items';

          // Add labels
          entry.labels.forEach(label => {
            const item = document.createElement('div');
            item.className = 'details-item';

            const labelText = document.createElement('span');
            labelText.className = 'details-label';
            labelText.textContent = label;

            item.appendChild(labelText);
            labelsDetails.appendChild(item);
          });

          labelsSection.appendChild(labelsTitle);
          labelsSection.appendChild(labelsDetails);
          detailsContent.appendChild(labelsSection);
        }

        // Add Signals section if available
        if (hasSignals) {
          const signalsSection = document.createElement('div');
          signalsSection.className = 'details-section';

          const signalsTitle = document.createElement('h4');
          signalsTitle.textContent = 'Trust Signals';

          const signalsDetails = document.createElement('div');
          signalsDetails.className = 'details-items';

          // Add signals
          Object.entries(entry.signals).forEach(([key, value]) => {
            const item = document.createElement('div');
            item.className = 'details-item';

            const signalLabel = document.createElement('span');
            signalLabel.className = 'details-label';
            signalLabel.textContent = key
              .replace(/([A-Z])/g, ' $1')
              .replace(/^./, str => str.toUpperCase());

            const signalValue = document.createElement('span');
            signalValue.className = 'details-value';

            // Format the value based on type
            if (typeof value === 'boolean') {
              signalValue.textContent = value ? '✓' : '✗';
              signalValue.className += value ? ' signal-positive' : ' signal-negative';
            } else if (value === null) {
              signalValue.textContent = 'None';
            } else if (typeof value === 'object') {
              signalValue.textContent = Object.entries(value)
                .map(([k, v]) => `${k}: ${v}`)
                .join(', ');
            } else {
              signalValue.textContent = value.toString();
            }

            item.appendChild(signalLabel);
            item.appendChild(signalValue);
            signalsDetails.appendChild(item);
          });

          signalsSection.appendChild(signalsTitle);
          signalsSection.appendChild(signalsDetails);
          detailsContent.appendChild(signalsSection);
        }

        // Add Image Hashes section if available
        if (hasHashes) {
          const hashesSection = document.createElement('div');
          hashesSection.className = 'details-section';

          const hashesTitle = document.createElement('h4');
          hashesTitle.textContent = 'Image Hashes';

          const hashesDetails = document.createElement('div');
          hashesDetails.className = 'details-items';

          // Add hash details
          const hashInfo = [
            {
              label: 'Perceptual Hash',
              value: entry.imageHashes?.phash || 'Not available',
              tooltip:
                'Perceptual hash identifies visually similar images even after modifications',
            },
            {
              label: 'SHA-256',
              value: entry.imageHashes?.sha256 || 'Not available',
              tooltip: 'Cryptographic hash uniquely identifies this exact image file',
            },
          ];

          hashInfo.forEach(info => {
            const item = document.createElement('div');
            item.className = 'details-item hash-item';

            const label = document.createElement('span');
            label.className = 'details-label';
            label.textContent = info.label;
            label.title = info.tooltip;

            const value = document.createElement('div');
            value.className = 'details-value hash-value';

            // Create hash display with copy button
            const hashText = document.createElement('span');
            hashText.className = 'hash-text';
            hashText.textContent =
              info.value.length > 16
                ? `${info.value.substring(0, 8)}...${info.value.substring(info.value.length - 8)}`
                : info.value;
            hashText.title = info.value;

            const copyBtn = document.createElement('button');
            copyBtn.className = 'copy-btn';
            copyBtn.innerHTML = '📋';
            copyBtn.title = 'Copy to clipboard';
            copyBtn.dataset.hash = info.value;
            copyBtn.addEventListener('click', function (e) {
              e.stopPropagation();
              navigator.clipboard
                .writeText(this.dataset.hash)
                .then(() => {
                  this.innerHTML = '✓';
                  setTimeout(() => {
                    this.innerHTML = '📋';
                  }, 1500);
                })
                .catch(err => console.error('Failed to copy: ', err));
            });

            value.appendChild(hashText);
            value.appendChild(copyBtn);

            item.appendChild(label);
            item.appendChild(value);
            hashesDetails.appendChild(item);
          });

          hashesSection.appendChild(hashesTitle);
          hashesSection.appendChild(hashesDetails);
          detailsContent.appendChild(hashesSection);
        }

        // --- START: Add DID Resolution Indicators Section ---
        if (entry.didResolution && entry.didResolution.indicators) {
          const didSection = document.createElement('div');
          didSection.className = 'details-section';

          const didTitle = document.createElement('h4');
          didTitle.textContent = 'DID Resolution Indicators';

          const didDetails = document.createElement('div');
          didDetails.className = 'details-items';

          const indicators = entry.didResolution.indicators;
          const indicatorInfo = [
            {
              label: 'Public VC Likely',
              value: indicators.publicVcLikely,
              tooltip:
                'Indicates if a public Verifiable Credential associated with this image is likely available.',
            },
            {
              label: 'Private Report Possible',
              value: indicators.privateReportPossible,
              tooltip:
                'Indicates if a private, detailed report might be obtainable for this image.',
              contentHash: entry.imageHashes?.sha256, // Store the content hash for retrieval
            },
          ];

          indicatorInfo.forEach(info => {
            if (info.value !== undefined) {
              // Only show if the indicator exists
              const item = document.createElement('div');
              item.className = 'details-item';

              const label = document.createElement('span');
              label.className = 'details-label';
              label.textContent = info.label;
              label.title = info.tooltip;

              const value = document.createElement('span');
              value.className = 'details-value';
              if (info.label === 'Private Report Possible' && info.value) {
                // Create a button to retrieve the private report
                const retrieveButton = document.createElement('button');
                retrieveButton.className = 'retrieve-report-btn';
                retrieveButton.textContent = 'Retrieve Report';
                retrieveButton.dataset.contentHash = info.contentHash;
                retrieveButton.addEventListener('click', retrievePrivateReport);

                value.textContent = 'Yes ';
                value.classList.add('signal-positive');
                value.appendChild(retrieveButton);
              } else {
                value.textContent = info.value ? 'Yes' : 'No'; // Assuming boolean values
                value.classList.add(info.value ? 'signal-positive' : 'signal-negative');
              }

              item.appendChild(label);
              item.appendChild(value);
              didDetails.appendChild(item);
            }
          });

          // Only add the section if there are indicators to show
          if (didDetails.hasChildNodes()) {
            didSection.appendChild(didTitle);
            didSection.appendChild(didDetails);
            detailsContent.appendChild(didSection);
          }
        }
        // --- END: Add DID Resolution Indicators Section ---

        // --- START: Add Report Disclosure Toggle Section ---
        if (
          entry.didResolution &&
          entry.didResolution.indicators &&
          entry.didResolution.indicators.privateReportPossible
        ) {
          const disclosureSection = document.createElement('div');
          disclosureSection.className = 'details-section';
          disclosureSection.id = `disclosure-section-${index}`;

          const disclosureTitle = document.createElement('h4');
          disclosureTitle.textContent = 'Report Disclosure Settings';

          const disclosureDescription = document.createElement('div');
          disclosureDescription.className = 'section-description';
          disclosureDescription.textContent = 'Choose how you want to store your scan report';

          // Create toggle container
          const toggleContainer = document.createElement('div');
          toggleContainer.className = 'disclosure-toggle-container';

          // Create private option
          const privateOption = document.createElement('div');
          privateOption.className = 'disclosure-option';

          const privateRadio = document.createElement('input');
          privateRadio.type = 'radio';
          privateRadio.name = `disclosure-${index}`;
          privateRadio.id = `private-${index}`;
          privateRadio.value = 'private';
          privateRadio.checked = true; // Default option

          const privateLabel = document.createElement('label');
          privateLabel.htmlFor = `private-${index}`;
          privateLabel.textContent = 'Store privately in Verida';

          privateOption.appendChild(privateRadio);
          privateOption.appendChild(privateLabel);

          // Create public option
          const publicOption = document.createElement('div');
          publicOption.className = 'disclosure-option';

          const publicRadio = document.createElement('input');
          publicRadio.type = 'radio';
          publicRadio.name = `disclosure-${index}`;
          publicRadio.id = `public-${index}`;
          publicRadio.value = 'public';

          const publicLabel = document.createElement('label');
          publicLabel.htmlFor = `public-${index}`;
          publicLabel.textContent = 'Make scan public (signed)';

          publicOption.appendChild(publicRadio);
          publicOption.appendChild(publicLabel);

          // Add options to container
          toggleContainer.appendChild(privateOption);
          toggleContainer.appendChild(publicOption);

          // Add event listeners for the radio buttons
          privateRadio.addEventListener('change', function () {
            console.log(`Report disclosure set to private for image ${index}`);
            // This is just UI implementation, actual storage logic would be implemented later
          });

          publicRadio.addEventListener('change', function () {
            console.log(`Report disclosure set to public for image ${index}`);
            // This is just UI implementation, actual storage logic would be implemented later
          });

          // Assemble the section
          disclosureSection.appendChild(disclosureTitle);
          disclosureSection.appendChild(disclosureDescription);
          disclosureSection.appendChild(toggleContainer);

          // Add to details content
          detailsContent.appendChild(disclosureSection);
        }
        // --- END: Add Report Disclosure Toggle Section ---

        // Add VC details if available
        if (hasVC) {
          const vcSection = document.createElement('div');
          vcSection.className = 'details-section';

          const vcTitle = document.createElement('h4');
          vcTitle.textContent = 'Verifiable Credential';

          const vcDetails = document.createElement('div');
          vcDetails.className = 'details-items';

          // Add VC details
          const vcInfo = [
            { label: 'Issuer', value: entry.issuer || 'did:cheqd:testnet:123456' },
            { label: 'Issued Date', value: new Date().toLocaleDateString() },
            { label: 'Credential ID', value: `vc-${Math.random().toString(36).substring(2, 10)}` },
          ];

          vcInfo.forEach(info => {
            const item = document.createElement('div');
            item.className = 'details-item';

            const label = document.createElement('span');
            label.className = 'details-label';
            label.textContent = info.label;

            const value = document.createElement('span');
            value.className = 'details-value';
            value.textContent = info.value;

            item.appendChild(label);
            item.appendChild(value);
            vcDetails.appendChild(item);
          });

          vcSection.appendChild(vcTitle);
          vcSection.appendChild(vcDetails);
          detailsContent.appendChild(vcSection);
        }

        // Add Developer tab with raw provenance data
        const developerSection = document.createElement('div');
        developerSection.className = 'details-section';

        const developerTitle = document.createElement('h4');
        developerTitle.textContent = 'Developer (Raw Provenance Data)';

        const developerDetails = document.createElement('div');
        developerDetails.className = 'details-items';

        // Collect raw provenance data
        const provenanceData = [
          {
            label: 'Content Hash',
            value: entry.imageHashes?.sha256 || 'Not available',
            tooltip: 'Hash of the input content',
          },
        ];

        // Add data from processedVcs if available
        if (entry.processedVcs && entry.processedVcs.length > 0) {
          // Find a verified VC
          const verifiedVc = entry.processedVcs.find(vc => vc.verified && vc.issuerTrusted);

          if (verifiedVc) {
            // Add model identifier if available
            if (verifiedVc.modelIdentifier) {
              provenanceData.push({
                label: 'Model Identifier',
                value: verifiedVc.modelIdentifier,
                tooltip: 'Identifier of the model used for verification',
              });
            }

            // Add model version if available
            if (verifiedVc.modelVersion) {
              provenanceData.push({
                label: 'Model Version',
                value:
                  typeof verifiedVc.modelVersion === 'object'
                    ? `${verifiedVc.modelVersion.semantic || 'N/A'} (${verifiedVc.modelVersion.hash || 'N/A'})`
                    : verifiedVc.modelVersion,
                tooltip: 'Version of the model used for verification',
              });
            }

            // Add confidence score if available
            if (verifiedVc.confidenceScore !== undefined) {
              provenanceData.push({
                label: 'Confidence Score',
                value:
                  typeof verifiedVc.confidenceScore === 'number'
                    ? verifiedVc.confidenceScore.toFixed(4)
                    : verifiedVc.confidenceScore,
                tooltip: 'Confidence score of the verification result',
              });
            }

            // Add runtime parameters if available
            if (verifiedVc.runtimeParameters) {
              const paramsStr =
                typeof verifiedVc.runtimeParameters === 'object'
                  ? Object.entries(verifiedVc.runtimeParameters)
                      .map(([k, v]) => `${k}: ${v}`)
                      .join(', ')
                  : verifiedVc.runtimeParameters;

              provenanceData.push({
                label: 'Runtime Parameters',
                value: paramsStr,
                tooltip: 'Parameters used during verification',
              });
            }
          }
        }

        // Add signals data if available
        if (entry.signals) {
          // Add any additional provenance data from signals
          if (
            entry.signals.modelIdentifier &&
            !provenanceData.some(item => item.label === 'Model Identifier')
          ) {
            provenanceData.push({
              label: 'Model Identifier',
              value: entry.signals.modelIdentifier,
              tooltip: 'Identifier of the model used for verification',
            });
          }

          if (
            entry.signals.modelVersion &&
            !provenanceData.some(item => item.label === 'Model Version')
          ) {
            provenanceData.push({
              label: 'Model Version',
              value:
                typeof entry.signals.modelVersion === 'object'
                  ? `${entry.signals.modelVersion.semantic || 'N/A'} (${entry.signals.modelVersion.hash || 'N/A'})`
                  : entry.signals.modelVersion,
              tooltip: 'Version of the model used for verification',
            });
          }

          if (
            entry.signals.confidenceScore !== undefined &&
            !provenanceData.some(item => item.label === 'Confidence Score')
          ) {
            provenanceData.push({
              label: 'Confidence Score',
              value:
                typeof entry.signals.confidenceScore === 'number'
                  ? entry.signals.confidenceScore.toFixed(4)
                  : entry.signals.confidenceScore,
              tooltip: 'Confidence score of the verification result',
            });
          }

          if (
            entry.signals.runtimeParameters &&
            !provenanceData.some(item => item.label === 'Runtime Parameters')
          ) {
            const paramsStr =
              typeof entry.signals.runtimeParameters === 'object'
                ? Object.entries(entry.signals.runtimeParameters)
                    .map(([k, v]) => `${k}: ${v}`)
                    .join(', ')
                : entry.signals.runtimeParameters;

            provenanceData.push({
              label: 'Runtime Parameters',
              value: paramsStr,
              tooltip: 'Parameters used during verification',
            });
          }
        }

        // Add items to the developer details section
        provenanceData.forEach(info => {
          const item = document.createElement('div');
          item.className = 'details-item';

          const label = document.createElement('span');
          label.className = 'details-label';
          label.textContent = info.label;
          if (info.tooltip) {
            label.title = info.tooltip;
          }

          const value = document.createElement('div');
          value.className = 'details-value';

          // Create text display with copy button for hash values
          if (info.label === 'Content Hash' && info.value !== 'Not available') {
            const hashText = document.createElement('span');
            hashText.className = 'hash-text';
            hashText.textContent =
              info.value.length > 16
                ? `${info.value.substring(0, 8)}...${info.value.substring(info.value.length - 8)}`
                : info.value;
            hashText.title = info.value;

            const copyBtn = document.createElement('button');
            copyBtn.className = 'copy-btn';
            copyBtn.innerHTML = '📋';
            copyBtn.title = 'Copy to clipboard';
            copyBtn.dataset.hash = info.value;
            copyBtn.addEventListener('click', function (e) {
              e.stopPropagation();
              navigator.clipboard
                .writeText(this.dataset.hash)
                .then(() => {
                  this.innerHTML = '✓';
                  setTimeout(() => {
                    this.innerHTML = '📋';
                  }, 1500);
                })
                .catch(err => console.error('Failed to copy: ', err));
            });

            value.appendChild(hashText);
            value.appendChild(copyBtn);
          } else {
            value.textContent = info.value;
          }

          item.appendChild(label);
          item.appendChild(value);
          developerDetails.appendChild(item);
        });

        developerSection.appendChild(developerTitle);
        developerSection.appendChild(developerDetails);
        detailsContent.appendChild(developerSection);

        detailsContent.appendChild(trustMeterSection);
        detailsContent.appendChild(aiSection);

        // Assemble the card
        card.appendChild(cardHeader);
        card.appendChild(cardContent);
        card.appendChild(cardActions);
        card.appendChild(detailsContent);

        // Add the card to the results
        resultsBody.appendChild(card);
      } catch (entryError) {
        console.error(`Error rendering entry ${index}:`, entryError);
        console.log(`Problematic entry:`, JSON.stringify(entry).substring(0, 200));
      }
    });
  } catch (error) {
    console.error('Error in renderResults:', error);
    loadingElement.style.display = 'none';
    noResultsElement.style.display = 'block';
    noResultsElement.textContent = 'Error rendering results: ' + error.message;
  }

  const wmPill = document.getElementById('watermarkPill');
  let wmPresent = 0;

  logEntries.forEach(entry => {
    if (entry.synthID) {
      // backend will send this boolean
      if (entry.synthID.present) wmPresent++;
    }
  });

  wmPill.style.display = 'inline-flex';
  wmPill.className = `trust-badge ${synthClass(wmPresent, logEntries.length)}`;
  wmPill.textContent = `Watermarks - ${wmPresent}/${logEntries.length}`;
}

// Function to toggle details view
function toggleDetails(event) {
  const index = event.target.dataset.index;
  const detailsContent = document.getElementById(`details-${index}`);

  if (detailsContent.classList.contains('active')) {
    detailsContent.classList.remove('active');
    event.target.textContent = 'Details';
  } else {
    detailsContent.classList.add('active');
    event.target.textContent = 'Hide Details';
  }
}

// Function to get trust message based on score
function getTrustMessage(score) {
  if (score > 0.7) {
    return 'High confidence in authenticity';
  } else if (score >= 0.4) {
    return 'Medium confidence in authenticity';
  } else {
    return 'Low confidence in authenticity';
  }
}

// Function to filter results
function filterResults() {
  const filterValue = document.getElementById('filterSelect').value;
  const cards = document.querySelectorAll('.cyber-card');
  let visibleCount = 0;

  cards.forEach(card => {
    const trustScore = parseFloat(card.dataset.trustScore);
    const hasVc = card.dataset.hasVc === 'true';

    let visible = false;

    switch (filterValue) {
      case 'high':
        visible = trustScore > 0.7;
        break;
      case 'medium':
        visible = trustScore >= 0.4 && trustScore <= 0.7;
        break;
      case 'low':
        visible = trustScore < 0.4;
        break;
      case 'vc':
        visible = hasVc;
        break;
      default:
        visible = true;
    }

    card.style.display = visible ? 'block' : 'none';
    if (visible) visibleCount++;
  });

  // Show/hide no results message
  document.getElementById('noResults').style.display = visibleCount === 0 ? 'block' : 'none';
}

// Function to refresh results
// Function to retrieve private report data
function retrievePrivateReport(event) {
  const contentHash = event.currentTarget.dataset.contentHash;
  const button = event.currentTarget;

  // Update button state
  button.textContent = 'Retrieving...';
  button.disabled = true;

  // Send message to background script to retrieve private report
  chrome.runtime.sendMessage({
    cmd: 'retrievePrivateReport',
    contentHash: contentHash,
  });
}

// Function to display private report data
function displayPrivateReport(data) {
  // Find the card with the matching content hash
  const cards = document.querySelectorAll('.cyber-card');
  let targetCard = null;

  for (const card of cards) {
    const retrieveButton = card.querySelector(
      `.retrieve-report-btn[data-content-hash="${data.contentHash}"]`
    );
    if (retrieveButton) {
      targetCard = card;

      // Update button state
      retrieveButton.textContent = 'Retrieved';
      retrieveButton.disabled = true;
      break;
    }
  }

  if (!targetCard) {
    console.error('Could not find card for content hash:', data.contentHash);
    return;
  }

  // Create or update private report section
  let reportSection = targetCard.querySelector('.private-report-section');

  if (!reportSection) {
    // Create new section
    const detailsContent = targetCard.querySelector('.details-content');

    reportSection = document.createElement('div');
    reportSection.className = 'details-section private-report-section';

    const reportTitle = document.createElement('h4');
    reportTitle.textContent = 'Private Verification Report';

    const reportDetails = document.createElement('div');
    reportDetails.className = 'details-items';

    reportSection.appendChild(reportTitle);
    reportSection.appendChild(reportDetails);

    if (detailsContent) {
      detailsContent.appendChild(reportSection);
    }
  }

  // Update report content
  const reportDetails = reportSection.querySelector('.details-items');
  reportDetails.innerHTML = ''; // Clear existing content

  if (data.success && data.privateReportData) {
    // Add timestamp
    const timestampItem = document.createElement('div');
    timestampItem.className = 'details-item';

    const timestampLabel = document.createElement('span');
    timestampLabel.className = 'details-label';
    timestampLabel.textContent = 'Report Date';

    const timestampValue = document.createElement('span');
    timestampValue.className = 'details-value';
    timestampValue.textContent = formatTimestamp(data.timestamp);

    timestampItem.appendChild(timestampLabel);
    timestampItem.appendChild(timestampValue);
    reportDetails.appendChild(timestampItem);

    // Add report data
    for (const [key, value] of Object.entries(data.privateReportData)) {
      const item = document.createElement('div');
      item.className = 'details-item';

      const label = document.createElement('span');
      label.className = 'details-label';
      label.textContent = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()); // Format camelCase to Title Case

      const valueElement = document.createElement('span');
      valueElement.className = 'details-value';

      // Format value based on type
      if (typeof value === 'boolean') {
        valueElement.textContent = value ? 'Yes' : 'No';
        valueElement.classList.add(value ? 'signal-positive' : 'signal-negative');
      } else if (typeof value === 'object' && value !== null) {
        valueElement.textContent = JSON.stringify(value, null, 2);
        valueElement.style.whiteSpace = 'pre-wrap';
      } else {
        valueElement.textContent = value;
      }

      item.appendChild(label);
      item.appendChild(valueElement);
      reportDetails.appendChild(item);
    }
  } else {
    // Show error message
    const errorItem = document.createElement('div');
    errorItem.className = 'details-item';

    const errorLabel = document.createElement('span');
    errorLabel.className = 'details-label';
    errorLabel.textContent = 'Error';

    const errorValue = document.createElement('span');
    errorValue.className = 'details-value error-message';
    errorValue.textContent = data.message || 'Failed to retrieve private report data';

    errorItem.appendChild(errorLabel);
    errorItem.appendChild(errorValue);
    reportDetails.appendChild(errorItem);
  }

  // Expand details if collapsed
  const detailsToggle = targetCard.querySelector('.details-toggle');
  const detailsContent = targetCard.querySelector('.details-content');

  if (detailsToggle && detailsContent && detailsContent.style.display === 'none') {
    detailsToggle.click(); // Expand details
  }
}

function refreshResults() {
  const loadingElement = document.getElementById('loading');
  loadingElement.style.display = 'flex';
  document.getElementById('resultsBody').innerHTML = '';
  document.getElementById('noResults').style.display = 'none';
  UIFeedback.hideError('scanError');

  // Update loading status
  UIFeedback.updateLoadingStatus('Fetching data from storage...');

  console.log('Refreshing results from chrome.storage.local...');
  console.log('Current time:', new Date().toISOString());

  // Check if we're in a test environment where chrome API might not be fully available
  if (!chrome || !chrome.storage || !chrome.storage.local) {
    console.log('Chrome storage API not available, loading mock data instead');
    loadMockData();
    return;
  }

  // Check if chrome.tabs exists (it might not in test environments)
  if (chrome.tabs && typeof chrome.tabs.query === 'function') {
    // Get the active tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      console.log('Active tab query completed:', tabs ? tabs.length : 0, 'tabs found');
      processStorageData(tabs);
    });
  } else {
    console.log('chrome.tabs.query not available, proceeding without tab filtering');
    processStorageData(null);
  }

  function processStorageData(tabs) {
    try {
      // Read directly from chrome.storage.local instead of using messaging
      chrome.storage.local.get(['scanned'], function (result) {
        console.log('Retrieved data from storage:', result);
        console.log('Storage has scanned data:', !!result.scanned);
        console.log('Scanned is array:', Array.isArray(result.scanned));
        console.log('Scanned length:', result.scanned ? result.scanned.length : 0);

        // Debug: Log the first item in scanned if it exists
        if (result.scanned && result.scanned.length > 0) {
          console.log(
            'First scanned item:',
            JSON.stringify(result.scanned[0]).substring(0, 200) + '...'
          );
        }

        if (result.scanned && Array.isArray(result.scanned) && result.scanned.length > 0) {
          // Filter entries for the current tab if tabId is available
          let logEntries = result.scanned;
          console.log('Initial entries count:', logEntries.length);

          if (tabs && tabs.length > 0) {
            const currentTabId = tabs[0].id;
            console.log('Current tab ID:', currentTabId);
            // Optional: Filter by tab ID if your data structure includes tabId
            // logEntries = logEntries.filter(entry => entry.tabId === currentTabId);
          }

          // Filter out invalid entries
          const validEntries = logEntries.filter(
            entry => entry && typeof entry === 'object' && entry.src
          );
          console.log('Valid entries after filtering:', validEntries.length);
          console.log('Filtered out:', logEntries.length - validEntries.length, 'invalid entries');

          // Debug: Log any invalid entries
          if (validEntries.length < logEntries.length) {
            const invalidEntries = logEntries.filter(
              entry => !(entry && typeof entry === 'object' && entry.src)
            );
            console.log('Invalid entries:', invalidEntries);
          }

          logEntries = validEntries;

          if (logEntries.length === 0) {
            console.log('No valid entries after filtering');
            document.getElementById('loading').style.display = 'none';
            document.getElementById('noResults').style.display = 'block';
            return;
          }

          // Ensure each entry has required properties
          logEntries = logEntries.map(entry => {
            // Make a copy to avoid modifying the original data in storage
            const processedEntry = { ...entry };

            // Debug: Log the entry being processed
            console.log('Processing entry:', processedEntry.src);

            // Ensure timestamp exists
            if (!processedEntry.timestamp) {
              console.log('Adding missing timestamp');
              processedEntry.timestamp = Date.now();
            }

            // Ensure trust/trustScore exists
            if (processedEntry.trust === undefined && processedEntry.trustScore === undefined) {
              console.log('Adding missing trust score');
              processedEntry.trustScore = 0.5; // Default to medium trust if not specified
            } else {
              // Use trust if trustScore is not available
              if (processedEntry.trust !== undefined && processedEntry.trustScore === undefined) {
                processedEntry.trustScore = processedEntry.trust;
                console.log('Using trust value for trustScore:', processedEntry.trustScore);
              }
            }

            // Map processedVcs to vc property if needed
            if (
              !processedEntry.vc &&
              processedEntry.processedVcs &&
              processedEntry.processedVcs.length > 0
            ) {
              console.log('Setting vc flag from processedVcs');
              processedEntry.vc = true;

              // If there's issuer information in processedVcs, use it
              const verifiedVc = processedEntry.processedVcs.find(
                vc => vc.verified && vc.issuerTrusted
              );
              if (verifiedVc) {
                console.log('Found verified VC with issuer:', verifiedVc.issuer);
                processedEntry.issuer = verifiedVc.issuer;
              }
            }

            return processedEntry;
          });

          console.log('Processed entries:', logEntries.length);
          console.log('First processed entry:', logEntries[0]);

          // Call renderResults with the processed entries
          renderResults(logEntries);
          filterResults();
        } else {
          console.log('No data found in storage or data is invalid');

          // Check if we should retry
          if (!window.refreshAttempts) {
            window.refreshAttempts = 1;
            console.log('First attempt failed, retrying in 1 second...');
            UIFeedback.updateLoadingStatus('First attempt failed, retrying...');
            setTimeout(refreshResults, 1000);
          } else if (window.refreshAttempts < 3) {
            window.refreshAttempts++;
            console.log(`Attempt ${window.refreshAttempts} failed, retrying in 1 second...`);
            UIFeedback.updateLoadingStatus(`Attempt ${window.refreshAttempts} failed, retrying...`);
            setTimeout(refreshResults, 1000);
          } else {
            console.log('All retry attempts failed');
            document.getElementById('loading').style.display = 'none';

            // Show error message with retry button
            UIFeedback.showError(
              'scanError',
              'scanErrorMessage',
              'scanErrorCode',
              'retryScanButton',
              'No scan data found after multiple attempts.',
              'DATA_NOT_FOUND',
              function () {
                // Retry function
                window.refreshAttempts = 0;
                UIFeedback.hideError('scanError');
                refreshResults();
              }
            );

            // For debugging: Try loading mock data if all retries fail
            console.log('Loading mock data for debugging...');
            loadMockData();
          }
        }
      });
    } catch (error) {
      console.error('Error in refreshResults:', error);
      document.getElementById('loading').style.display = 'none';
      document.getElementById('noResults').style.display = 'none';

      // Show error message with retry button
      UIFeedback.showError(
        'scanError',
        'scanErrorMessage',
        'scanErrorCode',
        'retryScanButton',
        'Error loading results: ' + error.message,
        error.code || 'LOAD_ERROR',
        function () {
          // Retry function
          window.refreshAttempts = 0;
          UIFeedback.hideError('scanError');
          refreshResults();
        }
      );
    }
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function () {
  console.log('DOM content loaded, initializing popup...');

  // Initialize filter
  document.getElementById('filterSelect').addEventListener('change', filterResults);

  // Initialize refresh button
  document.getElementById('refreshBtn').addEventListener('click', function () {
    console.log('Refresh button clicked');
    // Reset refresh attempts counter
    window.refreshAttempts = 0;
    refreshResults();
  });

  // Add event listener for "Become a Content Verifier" button
  document.getElementById('becomeVerifierBtn').addEventListener('click', function () {
    console.log('Become a Content Verifier button clicked');
    // Open the content verifier page in a new tab
    chrome.tabs.create({ url: 'content-verifier.html' });
  });

  // Initialize Verida authentication
  initVeridaAuth();

  // Add debug button for testing only in development mode
  if (process.env.NODE_ENV === 'development') {
    const debugBtn = document.createElement('button');
    debugBtn.textContent = 'Load Test Data';
    debugBtn.className = 'refresh-btn';
    debugBtn.style.marginLeft = '10px';
    debugBtn.addEventListener('click', function () {
      console.log('Debug button clicked, loading mock data');
      loadMockData();
    });
    document.querySelector('.controls').appendChild(debugBtn);
  }

  // Initial load
  console.log('Performing initial load...');
  refreshResults();

  // Add some animation to the header
  const header = document.querySelector('.cyber-header h1');
  header.innerHTML = header.textContent
    .split('')
    .map(
      char =>
        `<span style="animation: glow 1.5s ${Math.random()}s infinite alternate;">${char}</span>`
    )
    .join('');

  // Add animation style
  const style = document.createElement('style');
  style.textContent = `
    @keyframes glow {
      0% {
        text-shadow: 0 0 5px rgba(0, 255, 157, 0.5);
      }
      100% {
        text-shadow: 0 0 15px rgba(0, 255, 157, 0.8), 0 0 20px rgba(0, 255, 157, 0.5);
      }
    }
    
    .hash-item {
      margin-bottom: 8px;
    }
    
    .hash-value {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-family: monospace;
      background: rgba(0, 0, 0, 0.2);
      padding: 2px 5px;
      border-radius: 3px;
      max-width: 100%;
      overflow: hidden;
    }
    
    .hash-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .copy-btn {
      background: none;
      border: none;
      color: #00ff9d;
      cursor: pointer;
      font-size: 12px;
      padding: 2px 5px;
      margin-left: 5px;
      border-radius: 3px;
      transition: all 0.2s ease;
    }
    
    .copy-btn:hover {
      background: rgba(0, 255, 157, 0.2);
    }
    
    .signal-positive {
      color: #00ff9d;
      font-weight: bold;
    }
    
    .signal-negative {
      color: #ff5a5a;
      font-weight: bold;
    }
  `;
  document.head.appendChild(style);

  // Add message listener for Verida responses
  chrome.runtime.onMessage.addListener(function (message) {
    if (message.cmd === 'veridaConnectionStatus') {
      console.log('Received Verida connection status:', message);
      updateVeridaUI(message.connected, message.did);
    } else if (message.cmd === 'veridaConnectionResult') {
      console.log('Received Verida connection result:', message);
      if (message.success) {
        updateVeridaUI(true, message.did);
      } else {
        updateVeridaUI(false);
        alert('Failed to connect to Verida: ' + message.message);
      }
    } else if (message.cmd === 'veridaDisconnectionResult') {
      console.log('Received Verida disconnection result:', message);
      if (message.success) {
        updateVeridaUI(false);
      } else {
        alert('Failed to disconnect from Verida: ' + message.message);
      }
    }
  });
});

// Listen for privateReportRetrieved events
chrome.runtime.onMessage.addListener(message => {
  if (message.cmd === 'privateReportRetrieved') {
    console.log('Private report data received:', message);
    displayPrivateReport(message);
  }
});

// Verida Authentication Functions
// Function to initialize Verida authentication
function initVeridaAuth() {
  console.log('Initializing Verida authentication...');

  // Get UI elements
  const connectBtn = document.getElementById('connectVeridaBtn');
  const disconnectBtn = document.getElementById('disconnectVeridaBtn');
  const statusIndicator = document.getElementById('veridaStatusIndicator');
  const statusText = document.getElementById('veridaStatusText');
  const userInfo = document.getElementById('veridaUserInfo');
  const userDid = document.getElementById('veridaUserDid');

  // Add event listeners for connect and disconnect buttons
  connectBtn.addEventListener('click', connectToVerida);
  disconnectBtn.addEventListener('click', disconnectFromVerida);

  // Check if user is already connected
  checkVeridaConnectionStatus();
}

// Function to check Verida connection status
async function checkVeridaConnectionStatus() {
  console.log('Checking Verida connection status...');

  // Get UI elements
  const connectBtn = document.getElementById('connectVeridaBtn');
  const disconnectBtn = document.getElementById('disconnectVeridaBtn');
  const statusIndicator = document.getElementById('veridaStatusIndicator');
  const statusText = document.getElementById('veridaStatusText');
  const userInfo = document.getElementById('veridaUserInfo');
  const userDid = document.getElementById('veridaUserDid');

  try {
    // Send message to content script to check connection status
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(
        tabs[0].id,
        {
          cmd: 'checkVeridaConnection',
        },
        function (response) {
          if (chrome.runtime.lastError) {
            console.error('Error sending message:', chrome.runtime.lastError);
            updateVeridaUI(false);
            return;
          }

          if (response && response.success) {
            console.log('Verida connection status:', response);
            updateVeridaUI(response.connected, response.did);
          } else {
            console.log('No response or unsuccessful response from content script');
            updateVeridaUI(false);
          }
        }
      );
    });

    // Also check local storage for saved DID
    chrome.storage.local.get(['veridaDid'], function (result) {
      if (result.veridaDid) {
        console.log('Found Verida DID in storage:', result.veridaDid);
        updateVeridaUI(true, result.veridaDid);
      }
    });
  } catch (error) {
    console.error('Error checking Verida connection status:', error);
    updateVeridaUI(false);
  }
}

// Function to connect to Verida
function connectToVerida() {
  console.log('Connecting to Verida...');

  // Show operation status
  UIFeedback.showOperationStatus(
    'veridaOperationStatus',
    UIFeedback.STATUS.LOADING,
    'Connecting to Verida...',
    false
  );

  // Update UI to show connecting state
  const statusIndicator = document.getElementById('veridaStatusIndicator');
  const statusText = document.getElementById('veridaStatusText');

  statusIndicator.className = 'status-indicator connecting';
  statusText.textContent = 'Connecting...';

  // Send message to content script to connect to Verida
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      {
        cmd: 'connectToVerida',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          updateVeridaUI(false);

          // Show error status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Connection error: ' + chrome.runtime.lastError.message
          );
          return;
        }

        if (response && response.success) {
          console.log('Connected to Verida:', response);
          useAuthStore.setState({ user: response, token: response.did });
          updateWalletUI();

          // Show success status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.SUCCESS,
            'Connected successfully!'
          );
        } else {
          console.error('Failed to connect to Verida:', response);
          updateVeridaUI(false);

          // Show error status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Connection failed: ' + (response ? response.error || 'Unknown error' : 'No response')
          );
        }
      }
    );
  });
}

// Function to disconnect from Verida
function disconnectFromVerida() {
  console.log('Disconnecting from Verida...');

  // Show operation status
  UIFeedback.showOperationStatus(
    'veridaOperationStatus',
    UIFeedback.STATUS.LOADING,
    'Disconnecting from Verida...',
    false
  );

  // Send message to content script to disconnect from Verida
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      {
        cmd: 'disconnectFromVerida',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);

          // Show error status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Disconnection error: ' + chrome.runtime.lastError.message
          );
          return;
        }

        if (response && response.success) {
          console.log('Disconnected from Verida:', response);
          updateWalletUI();

          // Show success status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.SUCCESS,
            'Disconnected successfully!'
          );
        } else {
          console.error('Failed to disconnect from Verida:', response);

          // Show error status
          UIFeedback.showOperationStatus(
            'veridaOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Disconnection failed: ' +
              (response ? response.error || 'Unknown error' : 'No response')
          );
        }
      }
    );
  });

  // Also remove from local storage
  chrome.storage.local.remove('veridaDid', function () {
    console.log('Removed Verida DID from storage');
  });
}

// Function to update the Verida UI based on connection status
function updateVeridaUI(connected, did = null) {
  console.log('Updating Verida UI:', connected, did);

  // Get UI elements
  const connectBtn = document.getElementById('connectVeridaBtn');
  const disconnectBtn = document.getElementById('disconnectVeridaBtn');
  const statusIndicator = document.getElementById('veridaStatusIndicator');
  const statusText = document.getElementById('veridaStatusText');
  const userInfo = document.getElementById('veridaUserInfo');
  const userDid = document.getElementById('veridaUserDid');

  if (connected) {
    // Update status indicator and text
    statusIndicator.className = 'status-indicator connected';
    statusText.innerHTML =
      '<span style="color: #00ff9d; font-weight: 600; text-shadow: 0 0 5px rgba(0, 255, 157, 0.5);">Connected</span>';

    // Show disconnect button and hide connect button
    connectBtn.style.display = 'none';
    disconnectBtn.style.display = 'block';

    // Show user info
    userInfo.style.display = 'block';

    // Update user DID
    if (did) {
      userDid.textContent = did;
    }
  } else {
    // Update status indicator and text
    statusIndicator.className = 'status-indicator not-connected';
    statusText.innerHTML =
      '<span style="color: #ff2d55; font-weight: 600; text-shadow: 0 0 5px rgba(255, 45, 85, 0.5);">Not connected</span>';

    // Show connect button and hide disconnect button
    connectBtn.style.display = 'block';
    disconnectBtn.style.display = 'none';

    // Hide user info
    userInfo.style.display = 'none';
  }
}

// Mock data for testing
function loadMockData() {
  const mockEntries = [
    {
      src: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538',
      trustScore: 0.95,
      message: 'High trust score from VC (95%)',
      timestamp: Date.now() - 60000,
      vc: true,
      issuer: 'did:cheqd:testnet:z6MkrBdNdwUPnXDVD1DCxf9Ldfw',
      imageHashes: {
        phash: 'f8e0c0f0f0e0c0f0',
        sha256: 'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2',
      },
    },
    {
      src: 'https://images.unsplash.com/photo-1682695796954-bad0d0f59ff1',
      trustScore: 0.6,
      message: 'Medium trust score from VC (60%)',
      timestamp: Date.now() - 120000,
      vc: true,
      issuer: 'did:cheqd:testnet:z6MkrJVSYjNqZDHHNUFi5qGC8jF',
    },
    {
      src: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538',
      trustScore: 0.2,
      message: 'Low trust score from VC (20%)',
      timestamp: Date.now() - 180000,
      vc: true,
      issuer: 'did:cheqd:testnet:z6MkrWjHvGxKPj82NM7ZB1sgXM7',
    },
    {
      src: 'https://images.unsplash.com/photo-1682695797221-8164ff1fafc9',
      trustScore: 0.1,
      message: 'AI-generated image detected',
      timestamp: Date.now() - 240000,
      vc: false,
    },
  ];

  console.log('Loading mock data...');

  // Check if chrome.storage is available
  if (chrome && chrome.storage && chrome.storage.local) {
    console.log('Saving mock data to storage...');

    // Store mock data in chrome.storage.local
    chrome.storage.local.set({ scanned: mockEntries }, function () {
      console.log('✅ Mock data saved to storage');

      // Verify data was saved correctly
      chrome.storage.local.get(['scanned'], function (result) {
        console.log('Verification - retrieved from storage:', result);
        if (result.scanned && result.scanned.length === mockEntries.length) {
          console.log('✅ Storage verification successful - mock data was saved correctly');
        } else {
          console.error('❌ Storage verification failed - mock data was not saved correctly');
        }

        // Reset refresh attempts counter
        window.refreshAttempts = 0;

        // Refresh the UI to load data from storage
        refreshResults();
      });
    });
  } else {
    console.log('Chrome storage not available, rendering mock data directly');

    // Render mock data directly
    renderResults(mockEntries);

    // Reset refresh attempts counter
    window.refreshAttempts = 0;
  }
}

// For testing purposes, uncomment to use mock data
// setTimeout(loadMockData, 1000);

// Test Wallet Integration Functions
function initTestSection() {
  console.log('Initializing test section...');

  // Get UI elements
  const testVerifyBtn = document.getElementById('testVerifyBtn');
  const testContentHash = document.getElementById('testContentHash');
  const testContentType = document.getElementById('testContentType');
  const testResults = document.getElementById('testResults');
  const testResultsContent = document.getElementById('testResultsContent');

  // Add event listener for test verify button
  testVerifyBtn.addEventListener('click', async () => {
    console.log('Test verify button clicked');

    // Get test data
    const contentHash = testContentHash.value.trim();
    const contentType = testContentType.value;

    if (!contentHash) {
      alert('Please enter a content hash');
      return;
    }

    // Show loading state
    document.getElementById('testResultsLoading').style.display = 'flex';
    document.getElementById('testResultsContent').textContent = '';
    document.getElementById('testResultsError').style.display = 'none';
    document.getElementById('testResults').style.display = 'block';

    // Check if wallet is connected
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(
        tabs[0].id,
        {
          cmd: 'checkWalletConnectionStatus',
        },
        async function (response) {
          if (chrome.runtime.lastError) {
            console.error('Error sending message:', chrome.runtime.lastError);
            document.getElementById('testResultsLoading').style.display = 'none';

            // Show error message with retry button
            UIFeedback.showError(
              'testResultsError',
              'testErrorMessage',
              'testErrorCode',
              'retryVerificationButton',
              'Error checking wallet status: ' + chrome.runtime.lastError.message,
              'WALLET_CHECK_ERROR',
              function () {
                // Retry function
                document.getElementById('testVerifyBtn').click();
              }
            );
            return;
          }

          if (response && response.success && response.connected) {
            // Wallet is connected, send verification request
            document.getElementById('testResultsContent').textContent =
              'Sending verification request...';

            // Send message to content script to send verification request
            chrome.tabs.sendMessage(
              tabs[0].id,
              {
                cmd: 'sendVerificationRequest',
                contentHash: contentHash,
                contentType: contentType,
              },
              function (verifyResponse) {
                // Hide loading indicator
                document.getElementById('testResultsLoading').style.display = 'none';

                if (chrome.runtime.lastError) {
                  console.error('Error sending verification request:', chrome.runtime.lastError);

                  // Show error message with retry button
                  UIFeedback.showError(
                    'testResultsError',
                    'testErrorMessage',
                    'testErrorCode',
                    'retryVerificationButton',
                    'Error sending verification request: ' + chrome.runtime.lastError.message,
                    'VERIFICATION_REQUEST_ERROR',
                    function () {
                      // Retry function
                      document.getElementById('testVerifyBtn').click();
                    }
                  );
                  return;
                }

                if (verifyResponse && verifyResponse.success) {
                  console.log('Verification request sent:', verifyResponse);
                  document.getElementById('testResultsContent').textContent = JSON.stringify(
                    verifyResponse,
                    null,
                    2
                  );
                } else {
                  console.error('Failed to send verification request:', verifyResponse);

                  // Show error message with retry button
                  UIFeedback.showError(
                    'testResultsError',
                    'testErrorMessage',
                    'testErrorCode',
                    'retryVerificationButton',
                    'Failed to send verification request: ' +
                      (verifyResponse ? verifyResponse.error || 'Unknown error' : 'No response'),
                    'VERIFICATION_FAILED',
                    function () {
                      // Retry function
                      document.getElementById('testVerifyBtn').click();
                    }
                  );
                }
              }
            );
          } else {
            // Wallet is not connected, show connect wallet message
            testResultsContent.textContent =
              'Please connect a wallet first using the Wallet Integration section above.';
            testResults.style.display = 'block';
          }
        }
      );
    });
  });
}

// Add message handler for verification response
chrome.runtime.onMessage.addListener(function (message) {
  if (message.cmd === 'verificationResponse') {
    console.log('Received verification response:', message);

    // Get UI elements
    const testResults = document.getElementById('testResults');
    const testResultsContent = document.getElementById('testResultsContent');

    // Display verification response
    testResultsContent.textContent = JSON.stringify(message.result, null, 2);
    testResults.style.display = 'block';
  }
});

// Initialize test section when the document is loaded
document.addEventListener('DOMContentLoaded', function () {
  initTestSection();
});

// Wallet Integration Functions
// Function to initialize wallet integration
function initWalletIntegration() {
  console.log('Initializing wallet integration...');

  // Get UI elements
  const connectLeapBtn = document.getElementById('connectLeapBtn');
  const connectKeplrBtn = document.getElementById('connectKeplrBtn');
  const disconnectBtn = document.getElementById('disconnectWalletBtn');
  const statusIndicator = document.getElementById('walletStatusIndicator');
  const statusText = document.getElementById('walletStatusText');
  const userInfo = document.getElementById('walletUserInfo');
  const userAddress = document.getElementById('walletUserAddress');
  const userType = document.getElementById('walletUserType');

  // Add event listeners for connect and disconnect buttons
  connectLeapBtn.addEventListener('click', connectLeapWallet);
  connectKeplrBtn.addEventListener('click', connectKeplrWallet);
  disconnectBtn.addEventListener('click', disconnectWallet);

  // Check if user is already connected
  checkWalletConnectionStatus();
}

// Function to check wallet connection status
async function checkWalletConnectionStatus() {
  console.log('Checking wallet connection status...');

  // Get UI elements
  const connectLeapBtn = document.getElementById('connectLeapBtn');
  const connectKeplrBtn = document.getElementById('connectKeplrBtn');
  const disconnectBtn = document.getElementById('disconnectWalletBtn');
  const statusIndicator = document.getElementById('walletStatusIndicator');
  const statusText = document.getElementById('walletStatusText');
  const userInfo = document.getElementById('walletUserInfo');
  const userAddress = document.getElementById('walletUserAddress');
  const userType = document.getElementById('walletUserType');

  try {
    // Send message to content script to check connection status
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(
        tabs[0].id,
        {
          cmd: 'checkWalletConnectionStatus',
        },
        function (response) {
          if (chrome.runtime.lastError) {
            console.error('Error sending message:', chrome.runtime.lastError);
            return;
          }

          if (response && response.success) {
            console.log('Wallet connection status:', response);
            updateWalletUI(response.connected, response.address, response.type);
          } else {
            console.error('Failed to check wallet connection status:', response);
            updateWalletUI(false);
          }
        }
      );
    });

    // Also check local storage for saved wallet info
    chrome.storage.local.get(['walletAddress', 'walletType'], function (result) {
      if (result.walletAddress && result.walletType) {
        console.log('Found wallet info in storage:', result.walletAddress, result.walletType);
        updateWalletUI(true, result.walletAddress, result.walletType);
      }
    });
  } catch (error) {
    console.error('Error checking wallet connection status:', error);
    updateWalletUI(false);
  }
}

// Function to connect to Leap wallet
function connectLeapWallet() {
  console.log('Connecting to Leap wallet...');

  // Show operation status
  UIFeedback.showOperationStatus(
    'walletOperationStatus',
    UIFeedback.STATUS.LOADING,
    'Connecting to Leap wallet...',
    false
  );

  // Update UI to show connecting state
  const statusIndicator = document.getElementById('walletStatusIndicator');
  const statusText = document.getElementById('walletStatusText');

  statusIndicator.className = 'status-indicator connecting';
  statusText.textContent = 'Connecting...';

  // Send message to content script to connect to Leap wallet
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      {
        cmd: 'connectLeapWallet',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          updateWalletUI(false);

          // Show error status
          UIFeedback.showOperationStatus(
            'walletOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Connection error: ' + chrome.runtime.lastError.message
          );
          return;
        }

        if (response && response.success) {
          console.log('Connected to Leap wallet:', response);
          updateWalletUI(true, response.address, response.type);

          // Show success status
          UIFeedback.showOperationStatus(
            'walletOperationStatus',
            UIFeedback.STATUS.SUCCESS,
            'Connected successfully!'
          );
        } else {
          console.error('Failed to connect to Leap wallet:', response);
          updateWalletUI(false);

          // Show error status
          UIFeedback.showOperationStatus(
            'walletOperationStatus',
            UIFeedback.STATUS.ERROR,
            'Connection failed: ' + (response ? response.error || 'Unknown error' : 'No response')
          );
        }
      }
    );
  });
}

// Function to connect to Keplr wallet
function connectKeplrWallet() {
  console.log('Connecting to Keplr wallet...');

  // Update UI to show connecting state
  const statusIndicator = document.getElementById('walletStatusIndicator');
  const statusText = document.getElementById('walletStatusText');

  statusIndicator.className = 'status-indicator connecting';
  statusText.textContent = 'Connecting...';

  // Send message to content script to connect to Keplr wallet
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      {
        cmd: 'connectKeplrWallet',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          updateWalletUI(false);
          return;
        }

        if (response && response.success) {
          console.log('Connected to Keplr wallet:', response);
          updateWalletUI(true, response.address, response.type);
        } else {
          console.error('Failed to connect to Keplr wallet:', response);
          updateWalletUI(false);
          alert(
            'Failed to connect to Keplr wallet: ' + (response ? response.error : 'Unknown error')
          );
        }
      }
    );
  });
}

// Function to disconnect from wallet
function disconnectWallet() {
  console.log('Disconnecting wallet...');

  // Send message to content script to disconnect wallet
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(
      tabs[0].id,
      {
        cmd: 'disconnectWallet',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          return;
        }

        if (response && response.success) {
          console.log('Disconnected wallet:', response);
          updateWalletUI(false);
        } else {
          console.error('Failed to disconnect wallet:', response);
          alert('Failed to disconnect wallet: ' + (response ? response.error : 'Unknown error'));
        }
      }
    );
  });

  // Also remove from local storage
  chrome.storage.local.remove(['walletAddress', 'walletType'], function () {
    console.log('Removed wallet info from storage');
  });
}

// Function to update the wallet UI based on connection status
function updateWalletUI() {
  console.log('Updating wallet UI from store...');

  // Get UI elements
  const connectLeapBtn = document.getElementById('connectLeapBtn');
  const connectKeplrBtn = document.getElementById('connectKeplrBtn');
  const disconnectBtn = document.getElementById('disconnectWalletBtn');
  const statusIndicator = document.getElementById('walletStatusIndicator');
  const statusText = document.getElementById('walletStatusText');
  const userInfo = document.getElementById('walletUserInfo');
  const userAddress = document.getElementById('walletUserAddress');
  const userType = document.getElementById('walletUserType');

  const { user, token, loading, error } = useAuthStore();

  if (user && token) {
    // Update status indicator and text
    statusIndicator.className = 'status-indicator connected';
    statusText.innerHTML =
      '<span style="color: #00ff9d; font-weight: 600; text-shadow: 0 0 5px rgba(0, 255, 157, 0.5);">Connected</span>';

    // Show disconnect button and hide connect buttons
    connectLeapBtn.style.display = 'none';
    connectKeplrBtn.style.display = 'none';
    disconnectBtn.style.display = 'block';

    // Show user info
    userInfo.style.display = 'block';

    // Format address for display (truncate if too long)
    const displayAddress =
      user.address.length > 20
        ? user.address.substring(0, 10) + '...' + user.address.substring(user.address.length - 10)
        : user.address;

    userAddress.textContent = displayAddress;
    userType.textContent = user.type || 'Unknown';
  } else {
    // Update status indicator and text
    statusIndicator.className = 'status-indicator not-connected';
    statusText.innerHTML =
      '<span style="color: #ff2d55; font-weight: 600; text-shadow: 0 0 5px rgba(255, 45, 85, 0.5);">Not connected</span>';

    // Show connect buttons and hide disconnect button
    connectLeapBtn.style.display = 'block';
    connectKeplrBtn.style.display = 'block';
    disconnectBtn.style.display = 'none';

    // Hide user info
    userInfo.style.display = 'none';
  }
}

// Add event listener for wallet connection status updates
chrome.runtime.onMessage.addListener(function (message) {
  if (message.cmd === 'walletConnectionStatus') {
    console.log('Received wallet connection status:', message);
    updateWalletUI(message.connected, message.address, message.type);
  } else if (message.cmd === 'walletConnectionResult') {
    console.log('Received wallet connection result:', message);
    if (message.success) {
      updateWalletUI(true, message.address, message.type);
    } else {
      updateWalletUI(false);
      alert('Failed to connect wallet: ' + message.message);
    }
  } else if (message.cmd === 'walletDisconnectionResult') {
    console.log('Received wallet disconnection result:', message);
    if (message.success) {
      updateWalletUI(false);
    } else {
      alert('Failed to disconnect wallet: ' + message.message);
    }
  }
});

// Initialize wallet integration when the document is loaded
document.addEventListener('DOMContentLoaded', function () {
  initWalletIntegration();
});

function synthClass(present, total) {
  if (total === 0) return 'medium-trust';
  const ratio = present / total;
  return ratio > 0.7 ? 'high-trust' : ratio >= 0.4 ? 'medium-trust' : 'low-trust';
}
async function connectWalletUI() {
  const btn = document.getElementById('connectWalletBtn');
  btn.textContent = 'Connecting…';
  const res = await window.walletIntegration.connectWallet('leap');
  btn.textContent = res.success ? truncateAddr(res.address) : 'Connect Wallet';
  if (!res.success) alert(res.error);
}

document.getElementById('connectWalletBtn').addEventListener('click', connectWalletUI);
